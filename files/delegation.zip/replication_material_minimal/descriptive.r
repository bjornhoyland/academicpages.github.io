### decriptive data
library(tidyverse);library(lubridate)
library(parallel);library(xtable);library(reshape2)
library(enc)
load("x_out.RData")


x_out <-x_out[,c("rapporteur","loyalty","loyalty_short", "loyalty_long",
         "com_experience","ep_experience", "prev_reports","age","participate",
         "participate_short", "participate_long","switcher","final_year")] 
x_out %>% 
  melt() %>%
  group_by(variable) %>%
  summarise_all(funs(Mean = mean, SD = sd,
                     Min = min,quan25 = quantile(.,probs = .25),
                     quan75 = quantile(., probs = .75), 
                     Max = max),na.rm = TRUE) -> out
out <- as.data.frame(out)
out$variable <- c("Rapporteur", "Loyalty (current term)","Loyalty (last 365 days)", "Loyalty (current and last term)",
                  "Committee expertise","EP seniority", "Previous reports","Age","Participation in votes (current term)", 
                  "Participation (last 365 days)", "Participation (current and last term)", "Group switcher","Final year")
colnames(out) <- c(" ","Mean", "SD", "Min", "25 quantile", "75 quantile", "Max")

print(xtable(out,
             digits = 3, caption = "Table of descriptive statistics.",label ="tab:desc"),
      file = "figs_tables/desc.tex", include.rownames = FALSE, size = "footnotesize")
