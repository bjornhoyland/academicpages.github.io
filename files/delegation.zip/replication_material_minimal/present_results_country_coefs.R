# post-estimation
# loyalty squared interacted with expertise
# coefs vary by country
library(rstanarm);library(tidybayes);library(tidyverse)
library(modelr);library(xtable)
#######
load("null_mod3_base.RData")# working directory must be "replication material" use setwd() and getwd() to verify
print(null_mod3,digits = 3)
round(ranef(null_mod3)$country,3)

print(
xtable(round(ranef(null_mod3)$country,3), digits = 3, caption = "Country specific effects", label = "tab:county_effects"),
file="figs_tables/country_effects.tex", floating.environment = 'sidewaystable'
)


null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
    `b[(Intercept) country:Austria]`, `b[loyalty country:Austria]`,
               `b[com_experience country:Austria]`,`b[I(com_experience^2) country:Austria]`,
               `b[loyalty:com_experience country:Austria]`, 
               `b[loyalty:I(com_experience^2) country:Austria]`) %>% 
  transmute(intercept = `b[(Intercept) country:Austria]`,
            loyalty = loyalty + `b[loyalty country:Austria]`,
            com_experience = com_experience + `b[com_experience country:Austria]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Austria]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Austria]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Austria]`,
            country = "Austria") -> Austria

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Belgium]`, `b[loyalty country:Belgium]`,
               `b[com_experience country:Belgium]`,`b[I(com_experience^2) country:Belgium]`,
               `b[loyalty:com_experience country:Belgium]`, 
               `b[loyalty:I(com_experience^2) country:Belgium]`) %>% 
  transmute(intercept = `b[(Intercept) country:Belgium]`,
            loyalty = loyalty + `b[loyalty country:Belgium]`,
            com_experience = com_experience + `b[com_experience country:Belgium]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Belgium]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Belgium]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Belgium]`,
            country = "Belgium") -> Belgium

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Bulgaria]`, `b[loyalty country:Bulgaria]`,
               `b[com_experience country:Bulgaria]`,`b[I(com_experience^2) country:Bulgaria]`,
               `b[loyalty:com_experience country:Bulgaria]`, 
               `b[loyalty:I(com_experience^2) country:Bulgaria]`) %>% 
  transmute(intercept = `b[(Intercept) country:Bulgaria]`,
            loyalty = loyalty + `b[loyalty country:Bulgaria]`,
            com_experience = com_experience + `b[com_experience country:Bulgaria]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Bulgaria]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Bulgaria]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Bulgaria]`,
            country = "Bulgaria") -> Bulgaria

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Croatia]`, `b[loyalty country:Croatia]`,
               `b[com_experience country:Croatia]`,`b[I(com_experience^2) country:Croatia]`,
               `b[loyalty:com_experience country:Croatia]`, 
               `b[loyalty:I(com_experience^2) country:Croatia]`) %>% 
  transmute(intercept = `b[(Intercept) country:Croatia]`,
            loyalty = loyalty + `b[loyalty country:Croatia]`,
            com_experience = com_experience + `b[com_experience country:Croatia]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Croatia]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Croatia]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Croatia]`,
            country = "Croatia") -> Croatia

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Cyprus]`, `b[loyalty country:Cyprus]`,
               `b[com_experience country:Cyprus]`,`b[I(com_experience^2) country:Cyprus]`,
               `b[loyalty:com_experience country:Cyprus]`, 
               `b[loyalty:I(com_experience^2) country:Cyprus]`) %>% 
  transmute(intercept = `b[(Intercept) country:Cyprus]`,
            loyalty = loyalty + `b[loyalty country:Cyprus]`,
            com_experience = com_experience + `b[com_experience country:Cyprus]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Cyprus]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Cyprus]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Cyprus]`,
            country = "Cyprus") -> Cyprus

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Czech_Republic]`, `b[loyalty country:Czech_Republic]`,
               `b[com_experience country:Czech_Republic]`,`b[I(com_experience^2) country:Czech_Republic]`,
               `b[loyalty:com_experience country:Czech_Republic]`, 
               `b[loyalty:I(com_experience^2) country:Czech_Republic]`) %>% 
  transmute(intercept = `b[(Intercept) country:Czech_Republic]`,
            loyalty = loyalty + `b[loyalty country:Czech_Republic]`,
            com_experience = com_experience + `b[com_experience country:Czech_Republic]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Czech_Republic]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Czech_Republic]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Czech_Republic]`,
            country = "Czech Republic") -> Czech_Republic

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Denmark]`, `b[loyalty country:Denmark]`,
               `b[com_experience country:Denmark]`,`b[I(com_experience^2) country:Denmark]`,
               `b[loyalty:com_experience country:Denmark]`, 
               `b[loyalty:I(com_experience^2) country:Denmark]`) %>% 
  transmute(intercept = `b[(Intercept) country:Denmark]`,
            loyalty = loyalty + `b[loyalty country:Denmark]`,
            com_experience = com_experience + `b[com_experience country:Denmark]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Denmark]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Denmark]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Denmark]`,
            country = "Denmark") -> Denmark

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Estonia]`, `b[loyalty country:Estonia]`,
               `b[com_experience country:Estonia]`,`b[I(com_experience^2) country:Estonia]`,
               `b[loyalty:com_experience country:Estonia]`, 
               `b[loyalty:I(com_experience^2) country:Estonia]`) %>% 
  transmute(intercept = `b[(Intercept) country:Estonia]`,
            loyalty = loyalty + `b[loyalty country:Estonia]`,
            com_experience = com_experience + `b[com_experience country:Estonia]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Estonia]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Estonia]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Estonia]`,
            country = "Estonia") -> Estonia

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Finland]`, `b[loyalty country:Finland]`,
               `b[com_experience country:Finland]`,`b[I(com_experience^2) country:Finland]`,
               `b[loyalty:com_experience country:Finland]`, 
               `b[loyalty:I(com_experience^2) country:Finland]`) %>% 
  transmute(intercept = `b[(Intercept) country:Finland]`,
            loyalty = loyalty + `b[loyalty country:Finland]`,
            com_experience = com_experience + `b[com_experience country:Finland]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Finland]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Finland]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Finland]`,
            country = "Finland") -> Finland

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:France]`, `b[loyalty country:France]`,
               `b[com_experience country:France]`,`b[I(com_experience^2) country:France]`,
               `b[loyalty:com_experience country:France]`, 
               `b[loyalty:I(com_experience^2) country:France]`) %>% 
  transmute(intercept = `b[(Intercept) country:France]`,
            loyalty = loyalty + `b[loyalty country:France]`,
            com_experience = com_experience + `b[com_experience country:France]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:France]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:France]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:France]`,
            country = "France") -> France

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Germany]`, `b[loyalty country:Germany]`,
               `b[com_experience country:Germany]`,`b[I(com_experience^2) country:Germany]`,
               `b[loyalty:com_experience country:Germany]`, 
               `b[loyalty:I(com_experience^2) country:Germany]`) %>% 
  transmute(intercept = `b[(Intercept) country:Germany]`,
            loyalty = loyalty + `b[loyalty country:Germany]`,
            com_experience = com_experience + `b[com_experience country:Germany]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Germany]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Germany]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Germany]`,
            country = "Germany") -> Germany

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Greece]`, `b[loyalty country:Greece]`,
               `b[com_experience country:Greece]`,`b[I(com_experience^2) country:Greece]`,
               `b[loyalty:com_experience country:Greece]`, 
               `b[loyalty:I(com_experience^2) country:Greece]`) %>% 
  transmute(intercept = `b[(Intercept) country:Greece]`,
            loyalty = loyalty + `b[loyalty country:Greece]`,
            com_experience = com_experience + `b[com_experience country:Greece]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Greece]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Greece]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Greece]`,
            country = "Greece") -> Greece

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Hungary]`, `b[loyalty country:Hungary]`,
               `b[com_experience country:Hungary]`,`b[I(com_experience^2) country:Hungary]`,
               `b[loyalty:com_experience country:Hungary]`, 
               `b[loyalty:I(com_experience^2) country:Hungary]`) %>% 
  transmute(intercept = `b[(Intercept) country:Hungary]`,
            loyalty = loyalty + `b[loyalty country:Hungary]`,
            com_experience = com_experience + `b[com_experience country:Hungary]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Hungary]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Hungary]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Hungary]`,
            country = "Hungary") -> Hungary

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Ireland]`, `b[loyalty country:Ireland]`,
               `b[com_experience country:Ireland]`,`b[I(com_experience^2) country:Ireland]`,
               `b[loyalty:com_experience country:Ireland]`, 
               `b[loyalty:I(com_experience^2) country:Ireland]`) %>% 
  transmute(intercept = `b[(Intercept) country:Ireland]`,
            loyalty = loyalty + `b[loyalty country:Ireland]`,
            com_experience = com_experience + `b[com_experience country:Ireland]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Ireland]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Ireland]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Ireland]`,
            country = "Ireland") -> Ireland

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Italy]`, `b[loyalty country:Italy]`,
               `b[com_experience country:Italy]`,`b[I(com_experience^2) country:Italy]`,
               `b[loyalty:com_experience country:Italy]`, 
               `b[loyalty:I(com_experience^2) country:Italy]`) %>% 
  transmute(intercept = `b[(Intercept) country:Italy]`,
            loyalty = loyalty + `b[loyalty country:Italy]`,
            com_experience = com_experience + `b[com_experience country:Italy]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Italy]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Italy]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Italy]`,
            country = "Italy") -> Italy

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Latvia]`, `b[loyalty country:Latvia]`,
               `b[com_experience country:Latvia]`,`b[I(com_experience^2) country:Latvia]`,
               `b[loyalty:com_experience country:Latvia]`, 
               `b[loyalty:I(com_experience^2) country:Latvia]`) %>% 
  transmute(intercept = `b[(Intercept) country:Latvia]`,
            loyalty = loyalty + `b[loyalty country:Latvia]`,
            com_experience = com_experience + `b[com_experience country:Latvia]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Latvia]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Latvia]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Latvia]`,
            country = "Latvia") -> Latvia

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Lithuania]`, `b[loyalty country:Lithuania]`,
               `b[com_experience country:Lithuania]`,`b[I(com_experience^2) country:Lithuania]`,
               `b[loyalty:com_experience country:Lithuania]`, 
               `b[loyalty:I(com_experience^2) country:Lithuania]`) %>% 
  transmute(intercept = `b[(Intercept) country:Lithuania]`,
            loyalty = loyalty + `b[loyalty country:Lithuania]`,
            com_experience = com_experience + `b[com_experience country:Lithuania]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Lithuania]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Lithuania]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Lithuania]`,
            country = "Lithuania") -> Lithuania

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Luxembourg]`, `b[loyalty country:Luxembourg]`,
               `b[com_experience country:Luxembourg]`,`b[I(com_experience^2) country:Luxembourg]`,
               `b[loyalty:com_experience country:Luxembourg]`, 
               `b[loyalty:I(com_experience^2) country:Luxembourg]`) %>% 
  transmute(intercept = `b[(Intercept) country:Luxembourg]`,
            loyalty = loyalty + `b[loyalty country:Luxembourg]`,
            com_experience = com_experience + `b[com_experience country:Luxembourg]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Luxembourg]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Luxembourg]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Luxembourg]`,
            country = "Luxembourg") -> Luxembourg

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Malta]`, `b[loyalty country:Malta]`,
               `b[com_experience country:Malta]`,`b[I(com_experience^2) country:Malta]`,
               `b[loyalty:com_experience country:Malta]`, 
               `b[loyalty:I(com_experience^2) country:Malta]`) %>% 
  transmute(intercept = `b[(Intercept) country:Malta]`,
            loyalty = loyalty + `b[loyalty country:Malta]`,
            com_experience = com_experience + `b[com_experience country:Malta]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Malta]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Malta]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Malta]`,
            country = "Malta") -> Malta

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Netherlands]`, `b[loyalty country:Netherlands]`,
               `b[com_experience country:Netherlands]`,`b[I(com_experience^2) country:Netherlands]`,
               `b[loyalty:com_experience country:Netherlands]`, 
               `b[loyalty:I(com_experience^2) country:Netherlands]`) %>% 
  transmute(intercept = `b[(Intercept) country:Netherlands]`,
            loyalty = loyalty + `b[loyalty country:Netherlands]`,
            com_experience = com_experience + `b[com_experience country:Netherlands]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Netherlands]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Netherlands]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Netherlands]`,
            country = "Netherlands") -> Netherlands

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Poland]`, `b[loyalty country:Poland]`,
               `b[com_experience country:Poland]`,`b[I(com_experience^2) country:Poland]`,
               `b[loyalty:com_experience country:Poland]`, 
               `b[loyalty:I(com_experience^2) country:Poland]`) %>% 
  transmute(intercept = `b[(Intercept) country:Poland]`,
            loyalty = loyalty + `b[loyalty country:Poland]`,
            com_experience = com_experience + `b[com_experience country:Poland]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Poland]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Poland]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Poland]`,
            country = "Poland") -> Poland

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Portugal]`, `b[loyalty country:Portugal]`,
               `b[com_experience country:Portugal]`,`b[I(com_experience^2) country:Portugal]`,
               `b[loyalty:com_experience country:Portugal]`, 
               `b[loyalty:I(com_experience^2) country:Portugal]`) %>% 
  transmute(intercept = `b[(Intercept) country:Portugal]`,
            loyalty = loyalty + `b[loyalty country:Portugal]`,
            com_experience = com_experience + `b[com_experience country:Portugal]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Portugal]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Portugal]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Portugal]`,
            country = "Portugal") -> Portugal

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Romania]`, `b[loyalty country:Romania]`,
               `b[com_experience country:Romania]`,`b[I(com_experience^2) country:Romania]`,
               `b[loyalty:com_experience country:Romania]`, 
               `b[loyalty:I(com_experience^2) country:Romania]`) %>% 
  transmute(intercept = `b[(Intercept) country:Romania]`,
            loyalty = loyalty + `b[loyalty country:Romania]`,
            com_experience = com_experience + `b[com_experience country:Romania]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Romania]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Romania]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Romania]`,
            country = "Romania") -> Romania

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Slovakia]`, `b[loyalty country:Slovakia]`,
               `b[com_experience country:Slovakia]`,`b[I(com_experience^2) country:Slovakia]`,
               `b[loyalty:com_experience country:Slovakia]`, 
               `b[loyalty:I(com_experience^2) country:Slovakia]`) %>% 
  transmute(intercept = `b[(Intercept) country:Slovakia]`,
            loyalty = loyalty + `b[loyalty country:Slovakia]`,
            com_experience = com_experience + `b[com_experience country:Slovakia]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Slovakia]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Slovakia]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Slovakia]`,
            country = "Slovakia") -> Slovakia

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Slovenia]`, `b[loyalty country:Slovenia]`,
               `b[com_experience country:Slovenia]`,`b[I(com_experience^2) country:Slovenia]`,
               `b[loyalty:com_experience country:Slovenia]`, 
               `b[loyalty:I(com_experience^2) country:Slovenia]`) %>% 
  transmute(intercept = `b[(Intercept) country:Slovenia]`,
            loyalty = loyalty + `b[loyalty country:Slovenia]`,
            com_experience = com_experience + `b[com_experience country:Slovenia]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Slovenia]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Slovenia]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Slovenia]`,
            country = "Slovenia") -> Slovenia

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Spain]`, `b[loyalty country:Spain]`,
               `b[com_experience country:Spain]`,`b[I(com_experience^2) country:Spain]`,
               `b[loyalty:com_experience country:Spain]`, 
               `b[loyalty:I(com_experience^2) country:Spain]`) %>% 
  transmute(intercept = `b[(Intercept) country:Spain]`,
            loyalty = loyalty + `b[loyalty country:Spain]`,
            com_experience = com_experience + `b[com_experience country:Spain]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Spain]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Spain]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Spain]`,
            country = "Spain") -> Spain

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:Sweden]`, `b[loyalty country:Sweden]`,
               `b[com_experience country:Sweden]`,`b[I(com_experience^2) country:Sweden]`,
               `b[loyalty:com_experience country:Sweden]`, 
               `b[loyalty:I(com_experience^2) country:Sweden]`) %>% 
  transmute(intercept = `b[(Intercept) country:Sweden]`,
            loyalty = loyalty + `b[loyalty country:Sweden]`,
            com_experience = com_experience + `b[com_experience country:Sweden]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:Sweden]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:Sweden]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:Sweden]`,
            country = "Sweden") -> Sweden

null_mod3 %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[(Intercept) country:United_Kingdom]`, `b[loyalty country:United_Kingdom]`,
               `b[com_experience country:United_Kingdom]`,`b[I(com_experience^2) country:United_Kingdom]`,
               `b[loyalty:com_experience country:United_Kingdom]`, 
               `b[loyalty:I(com_experience^2) country:United_Kingdom]`) %>% 
  transmute(intercept = `b[(Intercept) country:United_Kingdom]`,
            loyalty = loyalty + `b[loyalty country:United_Kingdom]`,
            com_experience = com_experience + `b[com_experience country:United_Kingdom]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) country:United_Kingdom]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience country:United_Kingdom]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) country:United_Kingdom]`,
            country = "United Kingdom") -> United_Kingdom

countries <- bind_rows(Austria, Belgium, Bulgaria, Croatia,Cyprus, 
               Czech_Republic, Denmark, Estonia, Finland, France,
               Germany, Greece, Hungary, Ireland, Italy,Latvia,
               Lithuania, Luxembourg, Malta, Netherlands, Poland,
               Portugal, Slovakia, Slovenia, Spain, Sweden, United_Kingdom) %>% 
  as.data.frame()

countries %>% 
  ggplot(aes(y = fct_rev(country), x = intercept)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) -> gg_intercept

countries %>% 
  ggplot(aes(y = fct_rev(country), x = loyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Loyalty") -> gg_loyal

countries %>% 
  ggplot(aes(y = fct_rev(country), x = com_experience)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-.5,4.5) +
  xlab("Committee expertise") -> gg_com_experience

countries %>% 
  ggplot(aes(y = fct_rev(country), x = com_experience2)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-2.7,.5) +
  xlab("Committee expertise^2") -> gg_com_experience2

countries %>% 
  ggplot(aes(y = fct_rev(country), x = com_experienceXloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise x Loyalty") -> gg_com_experience_loyalty

countries %>% 
  ggplot(aes(y = fct_rev(country), x = com_Experience2Xloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise^2 x Loyalty") -> gg_com_experience2_loyalty  

country_plots <- gridExtra::grid.arrange(gg_intercept,gg_loyal,gg_com_experience,
                        gg_com_experience2,gg_com_experience_loyalty,
                        gg_com_experience2_loyalty, ncol = 2, nrow = 3)
ggsave("figs_tables/country_effects.pdf",country_plots, width = 17, height = 25, units = "cm", dpi = 600)
