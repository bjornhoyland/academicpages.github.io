# post-estimation
# loyalty squared interacted with expertise
# coefs vary by parliamentary term
library(rstanarm);library(tidybayes);library(tidyverse)
library(modelr);library(xtable)
library(ggrepel);library(hrbrthemes)
#######
load("null_mod3_ep.RData") # working directory must be "replication material" use setwd() and getwd() to verify
print(null_mod3_ep, digits = 3)
round(ranef(null_mod3_ep)$ep,3)

print(
  xtable(round(ranef(null_mod3_ep)$ep,3), digits = 3, caption = "Term specific effects", label = "tab:ep_effects"),
  file="figs_tables/ep_effects.tex", floating.environment = 'sidewaystable'
)

null_mod3_ep %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty ep:1]`,
               `b[com_experience ep:1]`,`b[I(com_experience^2) ep:1]`,
               `b[loyalty:com_experience ep:1]`, 
               `b[loyalty:I(com_experience^2) ep:1]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty ep:1]`,
            com_experience = com_experience + `b[com_experience ep:1]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) ep:1]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience ep:1]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) ep:1]`,
            EP = "EP 1") -> EP1

null_mod3_ep %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty ep:2]`,
               `b[com_experience ep:2]`,`b[I(com_experience^2) ep:2]`,
               `b[loyalty:com_experience ep:2]`, 
               `b[loyalty:I(com_experience^2) ep:2]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty ep:2]`,
            com_experience = com_experience + `b[com_experience ep:2]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) ep:2]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience ep:2]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) ep:2]`,
            EP = "EP 2") -> EP2

null_mod3_ep %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty ep:3]`,
               `b[com_experience ep:3]`,`b[I(com_experience^2) ep:3]`,
               `b[loyalty:com_experience ep:3]`, 
               `b[loyalty:I(com_experience^2) ep:3]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty ep:3]`,
            com_experience = com_experience + `b[com_experience ep:3]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) ep:3]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience ep:3]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) ep:3]`,
            EP = "EP 3") -> EP3

null_mod3_ep %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty ep:4]`,
               `b[com_experience ep:4]`,`b[I(com_experience^2) ep:4]`,
               `b[loyalty:com_experience ep:4]`, 
               `b[loyalty:I(com_experience^2) ep:4]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty ep:4]`,
            com_experience = com_experience + `b[com_experience ep:4]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) ep:4]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience ep:4]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) ep:4]`,
            EP = "EP 4") -> EP4

null_mod3_ep %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty ep:5]`,
               `b[com_experience ep:5]`,`b[I(com_experience^2) ep:5]`,
               `b[loyalty:com_experience ep:5]`, 
               `b[loyalty:I(com_experience^2) ep:5]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty ep:5]`,
            com_experience = com_experience + `b[com_experience ep:5]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) ep:5]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience ep:5]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) ep:5]`,
            EP = "EP 5") -> EP5

null_mod3_ep %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty ep:6]`,
               `b[com_experience ep:6]`,`b[I(com_experience^2) ep:6]`,
               `b[loyalty:com_experience ep:6]`, 
               `b[loyalty:I(com_experience^2) ep:6]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty ep:6]`,
            com_experience = com_experience + `b[com_experience ep:6]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) ep:6]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience ep:6]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) ep:6]`,
            EP = "EP 6") -> EP6

null_mod3_ep %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty ep:7]`,
               `b[com_experience ep:7]`,`b[I(com_experience^2) ep:7]`,
               `b[loyalty:com_experience ep:7]`, 
               `b[loyalty:I(com_experience^2) ep:7]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty ep:7]`,
            com_experience = com_experience + `b[com_experience ep:7]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) ep:7]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience ep:7]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) ep:7]`,
            EP = "EP 7") -> EP7

bind_rows(EP1, EP2, EP3, EP4, EP5, EP6, EP7) %>% 
as.data.frame() -> eps

eps %>% 
  ggplot(aes(y = fct_rev(EP), x = loyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Loyalty") -> gg_loyal

eps %>% 
  ggplot(aes(y = fct_rev(EP), x = com_experience)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-.5,6) +
  xlab("Committee expertise") -> gg_com_experience

eps %>% 
  ggplot(aes(y = fct_rev(EP), x = com_experience2)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-4.7,.5) +
  xlab("Committee expertise^2") -> gg_com_experience2

eps %>% 
  ggplot(aes(y = fct_rev(EP), x = com_experienceXloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise x Loyalty") -> gg_com_experience_loyalty

eps %>% 
  ggplot(aes(y = fct_rev(EP), x = com_Experience2Xloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise^2 x Loyalty") -> gg_com_experience2_loyalty  

ep_plots <- gridExtra::grid.arrange(gg_loyal,gg_com_experience,
                                         gg_com_experience2,gg_com_experience_loyalty,
                                         gg_com_experience2_loyalty, ncol = 2, nrow = 3)
ggsave("ep_effects.pdf", ep_plots, width = 17, height = 25, units = "cm", dpi = 600)

##############################

effects_mat = function(posterior_mat,treatment_var, fixed_var,fixed_val,
                       min_treat = 0, max_treat = 2.5, length_treatment = 100,
                       size_set = 5){
  treatment <- seq(0, max_treat,length = length_treatment)  # limits on treatment variable
  n_controls <- size_set - 1
  tmp <- list()
  for (i in 1:length(treatment)){
    tmp[[i]] = arm::invlogit(posterior_mat[,1] * fixed_val + 
                              posterior_mat[,2] * treatment[i]  + 
                              posterior_mat[,3] * (treatment[i]^2) +
                              posterior_mat[,4] * treatment[i] * fixed_val +
                              posterior_mat[,5] * (treatment[i]^2) * fixed_val)
  }
  control = arm::invlogit(posterior_mat[,1] * median(fixed_var) + 
                            posterior_mat[,2] * median(treatment_var)  + 
                            posterior_mat[,3] * median(treatment_var)^2 +
                            posterior_mat[,4] * median(treatment_var) * median(fixed_var) +
                            posterior_mat[,5] * median(treatment_var^2) * median(fixed_var))
  
  out <- bind_cols(tmp)
  temp <- list()
  for (i in 1:ncol(out)) {
 temp[[i]] <-  out[,i]/(out[,i] + (control * n_controls))
  }
  outdata <- bind_cols(temp)
  
  return(tibble(means = colMeans(outdata), 
                lower05 = apply(outdata,2,quantile, .025),
                lower25 = apply(outdata,2,quantile, .25),
                upper75 = apply(outdata, 2, quantile, .75),
                upper95 = apply(outdata, 2, quantile, .975), 
                treatment = treatment))
}

vars7 <- EP7[,c("loyalty", "com_experience", 
               "com_experience2", "com_experienceXloyalty",
               "com_Experience2Xloyalty")]
vars6 <- EP6[,c("loyalty", "com_experience", 
                "com_experience2", "com_experienceXloyalty",
                "com_Experience2Xloyalty")]
vars5 <- EP5[,c("loyalty", "com_experience", 
                "com_experience2", "com_experienceXloyalty",
                "com_Experience2Xloyalty")]
vars4 <- EP4[,c("loyalty", "com_experience", 
                "com_experience2", "com_experienceXloyalty",
                "com_Experience2Xloyalty")]
vars3 <- EP3[,c("loyalty", "com_experience", 
                "com_experience2", "com_experienceXloyalty",
                "com_Experience2Xloyalty")]
vars2 <- EP2[,c("loyalty", "com_experience", 
                "com_experience2", "com_experienceXloyalty",
                "com_Experience2Xloyalty")]
vars1 <- EP1[,c("loyalty", "com_experience", 
                "com_experience2", "com_experienceXloyalty",
                "com_Experience2Xloyalty")]

load("data/x_out.RData")

temp7 <- x_out %>% 
  filter(ep == 7)
temp6 <- x_out %>% 
  filter(ep == 6)
temp5 <- x_out %>% 
  filter(ep == 5)
temp4 <- x_out %>% 
  filter(ep == 4)
temp3 <- x_out %>% 
  filter(ep == 3)
temp2 <- x_out %>% 
  filter(ep == 2)
temp1 <- x_out %>% 
  filter(ep == 1)

preds1 <- cbind(effects_mat(vars1,temp1$com_experience,temp1$loyalty,
                            max_treat = quantile(temp1$com_experience, .99), fixed_val = .9),
                EP = "EP 1")
preds2 <- cbind(effects_mat(vars2,temp2$com_experience,temp2$loyalty,
                            max_treat =quantile(temp2$com_experience, .99), fixed_val = .9),
                EP = "EP 2")
preds3 <- cbind(effects_mat(vars3,temp3$com_experience,temp3$loyalty,
                            max_treat = quantile(temp3$com_experience, .99), fixed_val = .9),
                EP = "EP 3")
preds4 <- cbind(effects_mat(vars4,temp4$com_experience,temp4$loyalty,
                            max_treat = quantile(temp4$com_experience, .99), fixed_val = .9),
                EP = "EP 4")
preds5 <- cbind(effects_mat(vars5,temp5$com_experience,temp5$loyalty,
                            max_treat = quantile(temp5$com_experience, .99), fixed_val = .9),
                EP = "EP 5")
preds6 <- cbind(effects_mat(vars6,temp6$com_experience,temp6$loyalty,
                            max_treat = quantile(temp6$com_experience, .99), fixed_val = .9),
                EP = "EP 6")
preds7 <- cbind(effects_mat(vars7,temp7$com_experience,temp7$loyalty,
                            max_treat = quantile(temp7$com_experience, .99), fixed_val = .9),
                EP = "EP 7")
predictions <- bind_rows(preds1, preds2, preds3, preds4, preds5, preds6, preds7)
ggplot(predictions, aes(x = treatment, y = means)) +
  geom_ribbon(data = predictions, aes(x = treatment, ymin = lower05, ymax = upper95), 
              fill = "grey70", alpha = 0.5, inherit.aes = FALSE) +
  geom_ribbon(data = predictions, aes(x = treatment, ymin = lower25, ymax = upper75), 
              fill = "grey70", alpha = 0.5,inherit.aes = FALSE) +
  geom_line() +
  geom_hline(yintercept= .2, linetype = 2, col = "red")+
  facet_wrap(~ EP, scales = "free_x", ncol = 2) +
  scale_y_continuous("Pr(Report = 1)") +
  scale_x_continuous("", breaks = c(.5, 1, 1.5, 2, 2.5),
                     labels = c("5 years", "10 years",
                                "15 years","20 years", "25 years"))+
  theme(axis.text.x = element_text(angle = 75, hjust = 1,
                                   size = 20),
        panel.background = element_rect(fill = "grey98", colour = NA),
        axis.text.y = element_text(size = 18),
        plot.title = element_text(size = 28),
        strip.text = element_text(size = 22)) +
  ggtitle("Effect of committee expertise")
ggsave("ep4_ep7_expertise_effects.pdf", dpi = 900, 
       width = 18, height = 24)
