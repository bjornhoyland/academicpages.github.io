# post-estimation
# loyalty squared interacted with expertise
library(rstanarm);library(tidybayes);library(tidyverse)
library(modelr);library(furrr)
library(ggrepel);library(hrbrthemes)
load("x_out.RData")
summary(x_out)
load("mod3_null.RData")
null_mod3_null <- null_models[[1]]
null_mod3_null
controls_mod3_null <- null_models[[2]]

########################################
## Make result figures
########################################
short = c(" Expertise"," Expertise^2","  Loyalty", "  Loyalty * Expertise", "  Loyalty * Expertise^2",
          " Expertise"," Expertise^2","  Loyalty", "  Loyalty * Expertise", "  Loyalty * Expertise^2")
mod1 = null_mod3_null %>% 
  gather_draws(loyalty,com_experience,`I(com_experience^2)`, 
               `loyalty:com_experience`,`loyalty:I(com_experience^2)`) %>%
  median_qi(.width = c(.95,.66))
mod1$.variable = short
mod1$model = "Model 1a"

long = c("Age", "Age^2", " Expertise", "Committee Leader",
         "EP Leader", "Group Leader", "Final year", " Expertise^2",
         "  Loyalty","  Loyalty * Expertise", "  Loyalty * Expertise^2",
         "Participation", "Group Switcher",
         "Age", "Age^2", " Expertise", "Committee Leader",
         "EP Leader", "Group Leader", "Final year", " Expertise^2",
         "  Loyalty","  Loyalty * Expertise", "  Loyalty * Expertise^2",
         "Participation", "Group Switcher")
mod1_cont = controls_mod3_null %>% 
  gather_draws(loyalty, com_experience,
               `I(com_experience^2)`,`loyalty:com_experience`,
               `loyalty:I(com_experience^2)`, participate, age, age_sq,
               epg_leader, com_leader, ep_leader, 
               switcher, final_year) %>%
  median_qi(.width = c(.95,.66))
mod1_cont$.variable = long
mod1_cont$model = "Model 1b"

mods <- bind_rows(mod1,mod1_cont)

ggplot(mods,aes(x = .variable, y = .value, ymin = .lower, ymax = .upper, 
                group = model, color = model)) +
  geom_hline(yintercept = 0, alpha = 0.5, linetype = 2) +
  geom_linerange(data = filter(mods, .width == 0.66), 
                 aes(x = .variable, y = .value, ymin = .lower, ymax = .upper), 
                 position = position_dodge2(width = .75), size = 1.5, show.legend = FALSE) +
  geom_linerange(data = filter(mods, .width == 0.95), 
                 aes(x = .variable, y = .value, ymin = .lower, ymax = .upper), 
                 position = position_dodge2(width = .75), size = .75, show.legend = FALSE) +
  geom_point(data = filter(mods, .width == 0.66), size = 1.5, position = position_dodge2(width = .75)) +
  coord_flip() +
  scale_color_manual("", values = c("grey70","grey30")) +
  theme_ipsum(base_size = 14) +
  theme(panel.background = element_rect(fill = "grey98", colour = NA)) +
  theme(panel.background = element_rect(fill = "grey98", colour = NA)) +
  theme(legend.position = "bottom", legend.direction = "vertical") +
 # theme(text = element_text(size=28))+
  labs(x ="", y = "", caption = "Thin and Thick Lines: 95% and 66% intervals")+
  ggtitle("Baseline model with and without control variables")
ggsave("mainresults.png", width = 16.7, height = 7.2, dpi = 600)

##### Substantive effects
### function to generate prediction plots
### experience

effects_mat = function(posterior_mat,treatment_var, fixed_var,fixed_val,
                       min_treat = 0, max_treat = 2, length_treatment = 100,
                       size_set = 5){
  treatment <- seq(0, max_treat,length = length_treatment)  # limits on treatment variable
  n_controls <- size_set - 1
  out = matrix(NA,nrow=10000,ncol = length(treatment))
  for (i in 1:length(treatment)){
    out[,i] = arm::invlogit(posterior_mat[,1] * fixed_val + 
                              posterior_mat[,2] * treatment[i]  + 
                              posterior_mat[,3] * (treatment[i]^2) +
                              posterior_mat[,4] * treatment[i] * fixed_val +
                              posterior_mat[,5] * (treatment[i]^2) * fixed_val)
  }
  control = arm::invlogit(posterior_mat[,1] * median(fixed_var) + 
                            posterior_mat[,2] * median(treatment_var)  + 
                            posterior_mat[,3] * median(treatment_var)^2 +
                            posterior_mat[,4] * median(treatment_var) * median(fixed_var) +
                            posterior_mat[,5] * median(treatment_var^2) * median(fixed_var))
   
  temp <- sapply(1:length_treatment, function(i) out[,i]/(out[,i] + (control * n_controls)))
  return(tibble(means = colMeans(temp), 
                lower05 = apply(temp,2,quantile, .025),
                lower25 = apply(temp,2,quantile, .25),
                upper75 = apply(temp, 2, quantile, .75),
                upper95 = apply(temp, 2, quantile, .975), 
                treatment = treatment))
}

mat <- as.matrix(null_mod3_null)
vars <- mat[,c("loyalty", "com_experience", 
               "I(com_experience^2)", "loyalty:com_experience",
               "loyalty:I(com_experience^2)")]

plan(multiprocess)
preds <- future_map(seq(from = .5, to =1, length = 6), function(i) {
  cbind(effects_mat(vars,x_out$com_experience,x_out$loyalty,max_treat = 2.25,
                    fixed_val = i),loyalty = paste0("Loyalty = ", i))
})
predictions <- bind_rows(preds)

ggplot(predictions, aes(x = treatment, y = means)) +
  geom_ribbon(data = predictions, aes(x = treatment, ymin = lower05, ymax = upper95), 
              fill = "grey70", alpha = 0.5, inherit.aes = FALSE) +
  geom_ribbon(data = predictions, aes(x = treatment, ymin = lower25, ymax = upper75), 
              fill = "grey70", alpha = 0.5,inherit.aes = FALSE) +
  geom_line() +
  facet_wrap(~ loyalty, ncol = 2) +
  scale_y_continuous("Pr(Report = 1)") +
  geom_hline(yintercept= .2, linetype = 2, col = "red")+
  scale_x_continuous("Committee expertise", breaks = c(.25,.5,.75, 1, 
                                                       1.25, 1.5, 1.75, 2),
                     limits = c(0,2.25),
                     labels = c("2.5 years","5 years",
                                "7.5 years","10 years", "12.5 years", 
                                "15 years","17.5 years", "20 years"))+
  theme(axis.text.x = element_text(angle = 75, hjust = 1,
                                   size = 22),
        panel.background = element_rect(fill = "grey98", colour = NA),
        axis.text.y = element_text(size = 22),
        axis.title = element_text(size = 28),
        plot.title = element_text(size = 28),
        strip.text = element_text(size = 28)) +
  ggtitle("Effect of committee expertise")
ggsave("com_expertise_effects3.pdf", dpi = 900, 
       width = 18, height = 22)   