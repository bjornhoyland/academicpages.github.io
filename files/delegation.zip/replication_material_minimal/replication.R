### This is the masterscript for replicating the material in   ###
### Chiou, Hermansen and Høyland                               ###
### Delegation of Committee Reports in the European Parliament ###
##################################################################
list.of.packages <- c("Rcpp", "RcppEigen", "rstan", "rstanarm", 
                      "tidyverse", "reshape2", "lubridate","clogitboost",
                       "tidybayes", "modelr", "furrr","xtable",
                      "ggrepel", "hrbrthemes", "survival", "enc")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
# Note that the R scripts below rely on parallel computing. 
# It is nevertheless rather time.consuming. 
# The model may take several days to run. 
# Windows users must set the number of cores to 1 or re-write the code in 
# a way that allows for parallel computing in the Windows environment
# 1. prepare data
source("prep_newdata.R") # for main analysis
source("prep_newdata_alt_date.R") # alternative date
source("descriptive.r") # table with descriptive data
#######
# 2. analysis
source("analysis_rr.R") # boosting conditional logit model, with figure
source("analysis_rr_interaction_sq_null.R") # main analysis
# varying slopes section
source("analysis_rr_interaction_sq_baseline.R") # country varying slopes
source("analysis_rr_interaction_sq_epg.R") # epg varying slopes
source("analysis_rr_interaction_sq_com.R") # committee varying slopes
source("analysis_rr_interaction_sq_procedure.R") # procedure varying slopes
source("analysis_rr_interaction_sq_ep.R") # term varying slopes
######
# 3. present results
source("present_results_loyalty_sq_interact.R") # main results
# results described in varying slopes section of paper
source("present_results_ep_coefs.R") # results from term varying slopes
## results presented in appendix
source("present_results_country_coefs.R") # results from country varying slopes
source("present_results_epg_coefs.R") # results from epg varying slopes
source("present_results_com_coefs.R") # results from committee varying slopes
source("present_results_procedure_coefs.R") # results from procedure varying slopes
######
# 4. robustness checks
# different time-frame from loyalty scores
source("analysis_rr_interaction_sq_long.R") # all previous votes (across terms)
source("analysis_rr_interaction_sq_short.R") # last 365 days
# yes and no votes only
source("analysis_rr_interaction_sq_yn.R")
# specification of committee expertise
source("analysis_rr_interaction_sq_reports.R") # as reports
source("analysis_rr_interaction_sq_alt_date.R") # alternative date
# loyalty towards national party delegation
source("analysis_rr_interaction_sq_natloy.R")
######
# 5. present results from robustness checks
source("present_results_loyalty_sq_long.R") # reports, different versions of loyalty calculation
source("present_results_loyalty_sq_natloy.R")
### Final tables are made by hand



