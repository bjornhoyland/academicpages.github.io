#### analysis
# run booting models
sink("log_files/analysis_rr.log")
set.seed(98325)
load("data/x_out.RData")
library(clogitboost)
y <- x_out$rapporteur
x <- cbind(x_out$loyalty, x_out$com_experience)
strata <- x_out$set_id
boost_model <- clogitboost(y,x, strata, iter = 100, rho = 0.01)
save(boost_model, file = "results/boost_model.rda")
pdf("figs_tables/boost_con.pdf", width = 14, height = 8)
par(mfrow=c(1,2))
plot(boost_model, d = 1, xlab = "Voting Loyalty", ylab = "Marginal effect of loyalty", type = "l",
     axes = F, main = "Loyalty")
axis(2, at = c(-.3, -.2,-.1, 0 ,.1,.3, .3))
axis(1)

labs <-  c("2.5", " 7.5","12.5", "17.5", "22.5")
plot(boost_model, d = 2, xlab = "Years in committee", ylab = "Marginal effect of expertise", 
     type = "l", axes = FALSE, main = "Committee Expertise")
axis(2, at = c(-.3, -.2,-.1, 0 ,.1, .2,.3))
axis(1, at = c(.25, .75, 1.25, 1.75, 2.25), labels = labs, las = 0)
dev.off()
sink()


