# post-estimation
# loyalty squared interacted with expertise
# coefs vary by committee
library(rstanarm);library(tidybayes);library(tidyverse)
library(modelr);library(xtable)
#######
load("null_mod3_com.RData") # working directory must be "replication material" use setwd() and getwd() to verify
print(null_mod3_com, digits = 3)
round(ranef(null_mod3_com)$committee,3)

print(
  xtable(round(ranef(null_mod3_com)$committee,3), digits = 3, caption = "Committee specific effects", label = "tab:procedure_effects"),
  file="figs_tables/committee_effects.tex", floating.environment = 'sidewaystable'
)

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:AFCO]`,
               `b[com_experience committee:AFCO]`,`b[I(com_experience^2) committee:AFCO]`,
               `b[loyalty:com_experience committee:AFCO]`, 
               `b[loyalty:I(com_experience^2) committee:AFCO]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:AFCO]`,
            com_experience = com_experience + `b[com_experience committee:AFCO]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:AFCO]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:AFCO]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:AFCO]`,
            committee = "AFCO") -> AFCO

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:AFET]`,
               `b[com_experience committee:AFET]`,`b[I(com_experience^2) committee:AFET]`,
               `b[loyalty:com_experience committee:AFET]`, 
               `b[loyalty:I(com_experience^2) committee:AFET]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:AFET]`,
            com_experience = com_experience + `b[com_experience committee:AFET]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:AFET]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:AFET]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:AFET]`,
            committee = "AFET") -> AFET

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:AGRI]`,
               `b[com_experience committee:AGRI]`,`b[I(com_experience^2) committee:AGRI]`,
               `b[loyalty:com_experience committee:AGRI]`, 
               `b[loyalty:I(com_experience^2) committee:AGRI]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:AGRI]`,
            com_experience = com_experience + `b[com_experience committee:AGRI]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:AGRI]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:AGRI]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:AGRI]`,
            committee = "AGRI") -> AGRI

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:BUDG]`,
               `b[com_experience committee:BUDG]`,`b[I(com_experience^2) committee:BUDG]`,
               `b[loyalty:com_experience committee:BUDG]`, 
               `b[loyalty:I(com_experience^2) committee:BUDG]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:BUDG]`,
            com_experience = com_experience + `b[com_experience committee:BUDG]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:BUDG]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:BUDG]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:BUDG]`,
            committee = "BUDG") -> BUDG

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:CIA]`,
               `b[com_experience committee:CIA]`,`b[I(com_experience^2) committee:CIA]`,
               `b[loyalty:com_experience committee:CIA]`, 
               `b[loyalty:I(com_experience^2) committee:CIA]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:CIA]`,
            com_experience = com_experience + `b[com_experience committee:CIA]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:CIA]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:CIA]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:CIA]`,
            committee = "CIA") -> CIA

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:CLIM]`,
               `b[com_experience committee:CLIM]`,`b[I(com_experience^2) committee:CLIM]`,
               `b[loyalty:com_experience committee:CLIM]`, 
               `b[loyalty:I(com_experience^2) committee:CLIM]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:CLIM]`,
            com_experience = com_experience + `b[com_experience committee:CLIM]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:CLIM]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:CLIM]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:CLIM]`,
            committee = "CLIM") -> CLIM

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:CONT]`,
               `b[com_experience committee:CONT]`,`b[I(com_experience^2) committee:CONT]`,
               `b[loyalty:com_experience committee:CONT]`, 
               `b[loyalty:I(com_experience^2) committee:CONT]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:CONT]`,
            com_experience = com_experience + `b[com_experience committee:CONT]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:CONT]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:CONT]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:CONT]`,
            committee = "CONT") ->CONT

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:CRIM]`,
               `b[com_experience committee:CRIM]`,`b[I(com_experience^2) committee:CRIM]`,
               `b[loyalty:com_experience committee:CRIM]`, 
               `b[loyalty:I(com_experience^2) committee:CRIM]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:CRIM]`,
            com_experience = com_experience + `b[com_experience committee:CRIM]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:CRIM]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:CRIM]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:CRIM]`,
            committee = "CRIM") -> CRIM

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:CRIS]`,
               `b[com_experience committee:CRIS]`,`b[I(com_experience^2) committee:CRIS]`,
               `b[loyalty:com_experience committee:CRIS]`, 
               `b[loyalty:I(com_experience^2) committee:CRIS]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:CRIS]`,
            com_experience = com_experience + `b[com_experience committee:CRIS]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:CRIS]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:CRIS]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:CRIS]`,
            committee = "CRIS") -> CRIS

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:CULT]`,
               `b[com_experience committee:CULT]`,`b[I(com_experience^2) committee:CULT]`,
               `b[loyalty:com_experience committee:CULT]`, 
               `b[loyalty:I(com_experience^2) committee:CULT]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:CULT]`,
            com_experience = com_experience + `b[com_experience committee:CULT]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:CULT]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:CULT]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:CULT]`,
            committee = "CULT") -> CULT

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:DEVE]`,
               `b[com_experience committee:DEVE]`,`b[I(com_experience^2) committee:DEVE]`,
               `b[loyalty:com_experience committee:DEVE]`, 
               `b[loyalty:I(com_experience^2) committee:DEVE]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:DEVE]`,
            com_experience = com_experience + `b[com_experience committee:DEVE]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:DEVE]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:DEVE]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:DEVE]`,
            committee = "DEVE") -> DEVE

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:ECON]`,
               `b[com_experience committee:ECON]`,`b[I(com_experience^2) committee:ECON]`,
               `b[loyalty:com_experience committee:ECON]`, 
               `b[loyalty:I(com_experience^2) committee:ECON]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:ECON]`,
            com_experience = com_experience + `b[com_experience committee:ECON]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:ECON]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:ECON]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:ECON]`,
            committee = "ECON") -> ECON

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:EMPL]`,
               `b[com_experience committee:EMPL]`,`b[I(com_experience^2) committee:EMPL]`,
               `b[loyalty:com_experience committee:EMPL]`, 
               `b[loyalty:I(com_experience^2) committee:EMPL]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:EMPL]`,
            com_experience = com_experience + `b[com_experience committee:EMPL]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:EMPL]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:EMPL]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:EMPL]`,
            committee = "EMPL") -> EMPL

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:ENVI]`,
               `b[com_experience committee:ENVI]`,`b[I(com_experience^2) committee:ENVI]`,
               `b[loyalty:com_experience committee:ENVI]`, 
               `b[loyalty:I(com_experience^2) committee:ENVI]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:ENVI]`,
            com_experience = com_experience + `b[com_experience committee:ENVI]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:ENVI]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:ENVI]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:ENVI]`,
            committee = "ENVI") -> ENVI

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:EQULIFE]`,
               `b[com_experience committee:EQULIFE]`,`b[I(com_experience^2) committee:EQULIFE]`,
               `b[loyalty:com_experience committee:EQULIFE]`, 
               `b[loyalty:I(com_experience^2) committee:EQULIFE]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:EQULIFE]`,
            com_experience = com_experience + `b[com_experience committee:EQULIFE]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:EQULIFE]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:EQULIFE]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:EQULIFE]`,
            committee = "EQULIFE") -> EQULIFE

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:FEMM]`,
               `b[com_experience committee:FEMM]`,`b[I(com_experience^2) committee:FEMM]`,
               `b[loyalty:com_experience committee:FEMM]`, 
               `b[loyalty:I(com_experience^2) committee:FEMM]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:FEMM]`,
            com_experience = com_experience + `b[com_experience committee:FEMM]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:FEMM]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:FEMM]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:FEMM]`,
            committee = "FEMM") -> FEMM

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:IMCO]`,
               `b[com_experience committee:IMCO]`,`b[I(com_experience^2) committee:IMCO]`,
               `b[loyalty:com_experience committee:IMCO]`, 
               `b[loyalty:I(com_experience^2) committee:IMCO]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:IMCO]`,
            com_experience = com_experience + `b[com_experience committee:IMCO]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:IMCO]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:IMCO]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:IMCO]`,
            committee = "IMCO") -> IMCO

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:INTA]`,
               `b[com_experience committee:INTA]`,`b[I(com_experience^2) committee:INTA]`,
               `b[loyalty:com_experience committee:INTA]`, 
               `b[loyalty:I(com_experience^2) committee:INTA]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:INTA]`,
            com_experience = com_experience + `b[com_experience committee:INTA]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:INTA]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:INTA]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:INTA]`,
            committee = "INTA") -> INTA

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:ITRE]`,
               `b[com_experience committee:ITRE]`,`b[I(com_experience^2) committee:ITRE]`,
               `b[loyalty:com_experience committee:ITRE]`, 
               `b[loyalty:I(com_experience^2) committee:ITRE]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:ITRE]`,
            com_experience = com_experience + `b[com_experience committee:ITRE]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:ITRE]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:ITRE]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:ITRE]`,
            committee = "ITRE") -> ITRE

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:JURI]`,
               `b[com_experience committee:JURI]`,`b[I(com_experience^2) committee:JURI]`,
               `b[loyalty:com_experience committee:JURI]`, 
               `b[loyalty:I(com_experience^2) committee:JURI]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:JURI]`,
            com_experience = com_experience + `b[com_experience committee:JURI]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:JURI]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:JURI]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:JURI]`,
            committee = "JURI") -> JURI

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:LIBE]`,
               `b[com_experience committee:LIBE]`,`b[I(com_experience^2) committee:LIBE]`,
               `b[loyalty:com_experience committee:LIBE]`, 
               `b[loyalty:I(com_experience^2) committee:LIBE]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:LIBE]`,
            com_experience = com_experience + `b[com_experience committee:LIBE]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:LIBE]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:LIBE]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:LIBE]`,
            committee = "LIBE") -> LIBE

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:PECH]`,
               `b[com_experience committee:PECH]`,`b[I(com_experience^2) committee:PECH]`,
               `b[loyalty:com_experience committee:PECH]`, 
               `b[loyalty:I(com_experience^2) committee:PECH]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:PECH]`,
            com_experience = com_experience + `b[com_experience committee:PECH]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:PECH]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:PECH]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:PECH]`,
            committee = "PECH") -> PECH

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:PETI]`,
               `b[com_experience committee:PETI]`,`b[I(com_experience^2) committee:PETI]`,
               `b[loyalty:com_experience committee:PETI]`, 
               `b[loyalty:I(com_experience^2) committee:PETI]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:PETI]`,
            com_experience = com_experience + `b[com_experience committee:PETI]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:PETI]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:PETI]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:PETI]`,
            committee = "PETI") -> PETI

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:REGI]`,
               `b[com_experience committee:REGI]`,`b[I(com_experience^2) committee:REGI]`,
               `b[loyalty:com_experience committee:REGI]`, 
               `b[loyalty:I(com_experience^2) committee:REGI]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:REGI]`,
            com_experience = com_experience + `b[com_experience committee:REGI]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:REGI]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:REGI]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:REGI]`,
            committee = "REGI") -> REGI

null_mod3_com %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty committee:TRAN]`,
               `b[com_experience committee:TRAN]`,`b[I(com_experience^2) committee:TRAN]`,
               `b[loyalty:com_experience committee:TRAN]`, 
               `b[loyalty:I(com_experience^2) committee:TRAN]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty committee:TRAN]`,
            com_experience = com_experience + `b[com_experience committee:TRAN]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) committee:TRAN]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience committee:TRAN]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) committee:TRAN]`,
            committee = "TRAN") -> TRAN

bind_rows(AFCO, AFET, AGRI, BUDG, CIA, CLIM, CONT, CRIM, CRIS,CULT, DEVE, 
          ECON, EMPL, ENVI, EQULIFE, FEMM, IMCO, INTA, ITRE, 
          JURI, LIBE, PECH, PETI, REGI, TRAN) %>% 
  as.data.frame() -> committees

committees %>% 
  ggplot(aes(y = fct_rev(committee), x = loyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Loyalty") -> gg_loyal

committees %>% 
  ggplot(aes(y = fct_rev(committee), x = com_experience)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-.5,4.5) +
  xlab("Committee expertise") -> gg_com_experience

committees %>% 
  ggplot(aes(y = fct_rev(committee), x = com_experience2)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-2.7,.5) +
  xlab("Committee expertise^2") -> gg_com_experience2

committees %>% 
  ggplot(aes(y = fct_rev(committee), x = com_experienceXloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise x Loyalty") -> gg_com_experience_loyalty

committees %>% 
  ggplot(aes(y = fct_rev(committee), x = com_Experience2Xloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise^2 x Loyalty") -> gg_com_experience2_loyalty  

committee_plots <- gridExtra::grid.arrange(gg_loyal,gg_com_experience,
                                         gg_com_experience2,gg_com_experience_loyalty,
                                         gg_com_experience2_loyalty, ncol = 2, nrow = 3)
ggsave("figs_tables/committee_effects.pdf", committee_plots, width = 17, height = 25, units = "cm", dpi = 600)
