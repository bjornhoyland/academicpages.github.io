# post-estimation
# loyalty squared interacted with expertise
# loyalty calculated on the basis of national group delegations
library(rstanarm);library(tidybayes);library(tidyverse);library(modelr)
load("mod3_null_natloy.RData")
null_mod3_natparty <- null_models_natloy[[1]]
controls_mod3_natparty <- null_models_natloy[[2]]

print(null_mod3_natparty, digits = 3)
print(controls_mod3_natparty, digits = 3)

## date of allocation decision 90 days before vote on report. 
load("x_out_alt_date.RData")
sum(x_out_alt_date$rapporteur)
load("mod3_null_alt.RData")
null_mod3_null_alt <- null_models_alt[[1]]
controls_mod3_alt <- null_models_alt[[2]]

print(null_mod3_null_alt, digits = 3)
print(controls_mod3_null_alt, digits = 3)

