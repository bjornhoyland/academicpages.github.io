# post-estimation
# loyalty squared interacted with expertise
# coefs vary by parliamentary term
library(rstanarm);library(tidybayes);library(tidyverse)
library(modelr);library(xtable)
#######
load("null_mod3_epg.RData") # working directory must be "replication material" use setwd() and getwd() to verify
print(null_mod3_epg, digits = 3)
round(ranef(null_mod3_epg)$epg,3)

print(
  xtable(round(ranef(null_mod3_epg)$ep,3), digits = 3, caption = "Political group specific effects", label = "tab:ep_effects"),
  file="epg_effects.tex", floating.environment = 'sidewaystable'
)

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:ED]`,
               `b[com_experience epg:ED]`,`b[I(com_experience^2) epg:ED]`,
               `b[loyalty:com_experience epg:ED]`, 
               `b[loyalty:I(com_experience^2) epg:ED]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:ED]`,
            com_experience = com_experience + `b[com_experience epg:ED]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:ED]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:ED]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:ED]`,
            EPG = "ED") -> ED

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:EDD]`,
               `b[com_experience epg:EDD]`,`b[I(com_experience^2) epg:EDD]`,
               `b[loyalty:com_experience epg:EDD]`, 
               `b[loyalty:I(com_experience^2) epg:EDD]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:EDD]`,
            com_experience = com_experience + `b[com_experience epg:EDD]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:EDD]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:EDD]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:EDD]`,
            EPG = "EDD") -> EDD

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:EFD]`,
               `b[com_experience epg:EFD]`,`b[I(com_experience^2) epg:EFD]`,
               `b[loyalty:com_experience epg:EFD]`, 
               `b[loyalty:I(com_experience^2) epg:EFD]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:EFD]`,
            com_experience = com_experience + `b[com_experience epg:EFD]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:EFD]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:EFD]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:EFD]`,
            EPG = "EFD") -> EFD

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:EPP]`,
               `b[com_experience epg:EPP]`,`b[I(com_experience^2) epg:EPP]`,
               `b[loyalty:com_experience epg:EPP]`, 
               `b[loyalty:I(com_experience^2) epg:EPP]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:EPP]`,
            com_experience = com_experience + `b[com_experience epg:EPP]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:EPP]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:EPP]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:EPP]`,
            EPG = "EPP") -> EPP

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:ERA]`,
               `b[com_experience epg:ERA]`,`b[I(com_experience^2) epg:ERA]`,
               `b[loyalty:com_experience epg:ERA]`, 
               `b[loyalty:I(com_experience^2) epg:ERA]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:ERA]`,
            com_experience = com_experience + `b[com_experience epg:ERA]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:ERA]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:ERA]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:ERA]`,
            EPG = "ERA") -> ERA

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:ERC]`,
               `b[com_experience epg:ERC]`,`b[I(com_experience^2) epg:ERC]`,
               `b[loyalty:com_experience epg:ERC]`, 
               `b[loyalty:I(com_experience^2) epg:ERC]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:ERC]`,
            com_experience = com_experience + `b[com_experience epg:ERC]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:ERC]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:ERC]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:ERC]`,
            EPG = "ERC") -> ERC

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:EUL-NGL]`,
               `b[com_experience epg:EUL-NGL]`,`b[I(com_experience^2) epg:EUL-NGL]`,
               `b[loyalty:com_experience epg:EUL-NGL]`, 
               `b[loyalty:I(com_experience^2) epg:EUL-NGL]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:EUL-NGL]`,
            com_experience = com_experience + `b[com_experience epg:EUL-NGL]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:EUL-NGL]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:EUL-NGL]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:EUL-NGL]`,
            EPG = "EUL-NGL") -> EULNGL

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:Forza]`,
               `b[com_experience epg:Forza]`,`b[I(com_experience^2) epg:Forza]`,
               `b[loyalty:com_experience epg:Forza]`, 
               `b[loyalty:I(com_experience^2) epg:Forza]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:Forza]`,
            com_experience = com_experience + `b[com_experience epg:Forza]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:Forza]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:Forza]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:Forza]`,
            EPG = "Forza") -> Forza

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:Green]`,
               `b[com_experience epg:Green]`,`b[I(com_experience^2) epg:Green]`,
               `b[loyalty:com_experience epg:Green]`, 
               `b[loyalty:I(com_experience^2) epg:Green]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:Green]`,
            com_experience = com_experience + `b[com_experience epg:Green]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:Green]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:Green]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:Green]`,
            EPG = "Green") -> Green

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:IndDem]`,
               `b[com_experience epg:IndDem]`,`b[I(com_experience^2) epg:IndDem]`,
               `b[loyalty:com_experience epg:IndDem]`, 
               `b[loyalty:I(com_experience^2) epg:IndDem]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:IndDem]`,
            com_experience = com_experience + `b[com_experience epg:IndDem]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:IndDem]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:IndDem]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:IndDem]`,
            EPG = "ID") -> ID

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:LIB]`,
               `b[com_experience epg:LIB]`,`b[I(com_experience^2) epg:LIB]`,
               `b[loyalty:com_experience epg:LIB]`, 
               `b[loyalty:I(com_experience^2) epg:LIB]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:LIB]`,
            com_experience = com_experience + `b[com_experience epg:LIB]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:LIB]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:LIB]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:LIB]`,
            EPG = "ALDE") -> ALDE

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:Non]`,
               `b[com_experience epg:Non]`,`b[I(com_experience^2) epg:Non]`,
               `b[loyalty:com_experience epg:Non]`, 
               `b[loyalty:I(com_experience^2) epg:Non]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:Non]`,
            com_experience = com_experience + `b[com_experience epg:Non]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:Non]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:Non]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:Non]`,
            EPG = "NI") -> NI

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:SOC]`,
               `b[com_experience epg:SOC]`,`b[I(com_experience^2) epg:SOC]`,
               `b[loyalty:com_experience epg:SOC]`, 
               `b[loyalty:I(com_experience^2) epg:SOC]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:SOC]`,
            com_experience = com_experience + `b[com_experience epg:SOC]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:SOC]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:SOC]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:SOC]`,
            EPG = "S&D") -> SD

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:TGI]`,
               `b[com_experience epg:TGI]`,`b[I(com_experience^2) epg:TGI]`,
               `b[loyalty:com_experience epg:TGI]`, 
               `b[loyalty:I(com_experience^2) epg:TGI]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:TGI]`,
            com_experience = com_experience + `b[com_experience epg:TGI]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:TGI]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:TGI]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:TGI]`,
            EPG = "TGI") -> TGI

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:UEN]`,
               `b[com_experience epg:UEN]`,`b[I(com_experience^2) epg:UEN]`,
               `b[loyalty:com_experience epg:UEN]`, 
               `b[loyalty:I(com_experience^2) epg:UEN]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:UEN]`,
            com_experience = com_experience + `b[com_experience epg:UEN]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:UEN]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:UEN]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:UEN]`,
            EPG = "UEN") -> UEN

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:rain]`,
               `b[com_experience epg:rain]`,`b[I(com_experience^2) epg:rain]`,
               `b[loyalty:com_experience epg:rain]`, 
               `b[loyalty:I(com_experience^2) epg:rain]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:rain]`,
            com_experience = com_experience + `b[com_experience epg:rain]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:rain]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:rain]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:rain]`,
            EPG = "Rainbow") -> Rain

null_mod3_epg %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty epg:right]`,
               `b[com_experience epg:right]`,`b[I(com_experience^2) epg:right]`,
               `b[loyalty:com_experience epg:right]`, 
               `b[loyalty:I(com_experience^2) epg:right]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty epg:right]`,
            com_experience = com_experience + `b[com_experience epg:right]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) epg:right]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience epg:right]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) epg:right]`,
            EPG = "right") -> Right

bind_rows(ALDE, ED, EDD, EFD, EPP, ERA, ERC, EULNGL, Forza, ID, NI, Rain, Right, SD, TGI, UEN) %>% 
as.data.frame() -> epgs

epgs %>% 
  ggplot(aes(y = fct_rev(EPG), x = loyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Loyalty") -> gg_loyal

epgs %>% 
  ggplot(aes(y = fct_rev(EPG), x = com_experience)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-.5,4) +
  xlab("Committee expertise") -> gg_com_experience

epgs %>% 
  ggplot(aes(y = fct_rev(EPG), x = com_experience2)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-3,.5) +
  xlab("Committee expertise^2") -> gg_com_experience2

epgs %>% 
  ggplot(aes(y = fct_rev(EPG), x = com_experienceXloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise x Loyalty") -> gg_com_experience_loyalty

epgs %>% 
  ggplot(aes(y = fct_rev(EPG), x = com_Experience2Xloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise^2 x Loyalty") -> gg_com_experience2_loyalty  

epg_plots <- gridExtra::grid.arrange(gg_loyal,gg_com_experience,
                                         gg_com_experience2,gg_com_experience_loyalty,
                                         gg_com_experience2_loyalty, ncol = 2, nrow = 3)
ggsave("figs_tables/epg_effects.pdf", epg_plots, width = 17, height = 25, units = "cm", dpi = 600)
