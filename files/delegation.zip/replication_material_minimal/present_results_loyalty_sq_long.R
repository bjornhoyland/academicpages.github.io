# post-estimation
# loyalty squared interacted with expertise
library(rstanarm);library(tidybayes);library(tidyverse);library(modelr)
load("x_out.RData") # working directory must be "replication material" use setwd() and getwd() to verify
summary(x_out)
load("mod3_null_long.RData")
null_mod3_long <- null_models_long[[1]]
controls_mod3_long <- null_models_long[[2]]

print(null_mod3_long, digits = 3)
print(controls_mod3_long, digits = 3)

load("mod3_null_short.RData")

null_mod3_short <- null_models_short[[1]]
controls_mod3_short <- null_models_short[[2]]

print(null_mod3_short, digits = 3)
print(controls_mod3_short, digits = 3)

###################
load("mod3_null_yn.RData")
null_mod3_yn <-null_models_yn[[1]]
controls_mod3_yn <-null_models_yn[[2]]

print(null_mod3_yn, digits = 3)
print(controls_mod3_yn, digits = 3)

load("mod3_null_reports.RData")
null_model3_reports <- null_models_reports[[1]]
controls3_reports <- null_models_reports[[2]]

print(null_model3_reports, digits = 3)
print(controls3_reports, digits = 3)
