# post-estimation
# loyalty squared interacted with expertise
# coefs vary by procedure
library(rstanarm);library(tidybayes);library(tidyverse)
library(modelr);library(xtable)
#######
load("results/null_mod3_procedure.RData")
print(null_mod3_proc, digits = 3)
round(ranef(null_mod3_proc)$procedure_stand,3)

print(
  xtable(round(ranef(null_mod3_proc)$procedure,3), digits = 3, caption = "Procedure specific effects", label = "tab:procedure_effects"),
  file="figs_tables/procedure_effects.tex", floating.environment = 'sidewaystable'
)

null_mod3_proc %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty procedure_stand:AVC]`,
               `b[com_experience procedure_stand:AVC]`,`b[I(com_experience^2) procedure_stand:AVC]`,
               `b[loyalty:com_experience procedure_stand:AVC]`, 
               `b[loyalty:I(com_experience^2) procedure_stand:AVC]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty procedure_stand:AVC]`,
            com_experience = com_experience + `b[com_experience procedure_stand:AVC]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) procedure_stand:AVC]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience procedure_stand:AVC]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) procedure_stand:AVC]`,
            procedure = "Assent") -> AVC

null_mod3_proc %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty procedure_stand:BUD]`,
               `b[com_experience procedure_stand:BUD]`,`b[I(com_experience^2) procedure_stand:BUD]`,
               `b[loyalty:com_experience procedure_stand:BUD]`, 
               `b[loyalty:I(com_experience^2) procedure_stand:BUD]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty procedure_stand:BUD]`,
            com_experience = com_experience + `b[com_experience procedure_stand:BUD]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) procedure_stand:BUD]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience procedure_stand:BUD]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) procedure_stand:BUD]`,
            procedure = "Budget") -> BUD

null_mod3_proc %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty procedure_stand:CNS]`,
               `b[com_experience procedure_stand:CNS]`,`b[I(com_experience^2) procedure_stand:CNS]`,
               `b[loyalty:com_experience procedure_stand:CNS]`, 
               `b[loyalty:I(com_experience^2) procedure_stand:CNS]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty procedure_stand:CNS]`,
            com_experience = com_experience + `b[com_experience procedure_stand:CNS]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) procedure_stand:CNS]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience procedure_stand:CNS]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) procedure_stand:CNS]`,
            procedure = "Consultation") -> CNS

null_mod3_proc %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty procedure_stand:COD]`,
               `b[com_experience procedure_stand:COD]`,`b[I(com_experience^2) procedure_stand:COD]`,
               `b[loyalty:com_experience procedure_stand:COD]`, 
               `b[loyalty:I(com_experience^2) procedure_stand:COD]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty procedure_stand:COD]`,
            com_experience = com_experience + `b[com_experience procedure_stand:COD]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) procedure_stand:COD]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience procedure_stand:COD]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) procedure_stand:COD]`,
            procedure = "Codecision") -> COD

null_mod3_proc %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty procedure_stand:COS]`,
               `b[com_experience procedure_stand:COS]`,`b[I(com_experience^2) procedure_stand:COS]`,
               `b[loyalty:com_experience procedure_stand:COS]`, 
               `b[loyalty:I(com_experience^2) procedure_stand:COS]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty procedure_stand:COS]`,
            com_experience = com_experience + `b[com_experience procedure_stand:COS]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) procedure_stand:COS]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience procedure_stand:COS]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) procedure_stand:COS]`,
            procedure = "Cooperation") -> COS

null_mod3_proc %>% 
  spread_draws(`loyalty`,`com_experience`, `I(com_experience^2)`,
               `loyalty:com_experience`, `loyalty:I(com_experience^2)`,
               `b[loyalty procedure_stand:Other]`,
               `b[com_experience procedure_stand:Other]`,`b[I(com_experience^2) procedure_stand:Other]`,
               `b[loyalty:com_experience procedure_stand:Other]`, 
               `b[loyalty:I(com_experience^2) procedure_stand:Other]`) %>% 
  transmute(loyalty = loyalty + `b[loyalty procedure_stand:Other]`,
            com_experience = com_experience + `b[com_experience procedure_stand:Other]`,
            com_experience2 = `I(com_experience^2)` + `b[I(com_experience^2) procedure_stand:Other]`,
            com_experienceXloyalty = `loyalty:com_experience` + `b[loyalty:com_experience procedure_stand:Other]`,
            com_Experience2Xloyalty = `loyalty:I(com_experience^2)` + 
              `b[loyalty:I(com_experience^2) procedure_stand:Other]`,
            procedure = "Other") -> Other

bind_rows(AVC, BUD, CNS, COD, COS, Other) %>% 
as.data.frame() -> procedures

procedures %>% 
  ggplot(aes(y = fct_rev(procedure), x = loyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Loyalty") -> gg_loyal

procedures %>% 
  ggplot(aes(y = fct_rev(procedure), x = com_experience)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-.5,4.5) +
  xlab("Committee expertise") -> gg_com_experience

procedures %>% 
  ggplot(aes(y = fct_rev(procedure), x = com_experience2)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlim(-2.7,.5) +
  xlab("Committee expertise^2") -> gg_com_experience2

procedures %>% 
  ggplot(aes(y = fct_rev(procedure), x = com_experienceXloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise x Loyalty") -> gg_com_experience_loyalty

procedures %>% 
  ggplot(aes(y = fct_rev(procedure), x = com_Experience2Xloyalty)) +
  geom_vline(xintercept = 0, col = "grey70") +
  stat_pointintervalh() +
  ylab(NULL) +
  xlab("Committee expertise^2 x Loyalty") -> gg_com_experience2_loyalty  

procedure_plots <- gridExtra::grid.arrange(gg_loyal,gg_com_experience,
                                         gg_com_experience2,gg_com_experience_loyalty,
                                         gg_com_experience2_loyalty, ncol = 2, nrow = 3)
ggsave("figs_tables/procedure_effects.pdf", procedure_plots, width = 17, height = 25, units = "cm", dpi = 600)
