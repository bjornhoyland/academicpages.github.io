#### analysis
# models with loyalty * expertise squared
# multilevel models
# country and MEP level
# different measures of loyalty
.libPaths("/cluster/home/bjornkho/admin/run4/R") # optimized R and rstan
set.seed(98325)
library(tidyverse)
load("x_out.RData")
x_out$leader <- ifelse(rowSums(cbind(x_out$ep_leader,x_out$ep_bureau))>0,1,0)
x_out$id_com_country <- paste0(x_out$id_com, x_out$country)
library(survival)

#### interactions
null_model3_long = clogit(rapporteur ~ loyalty_long + 
                      com_experience + I(com_experience^2) +
                      loyalty_long:com_experience +
                       loyalty_long:I(com_experience^2) +  
                      strata(set_id), data = x_out)
summary(null_model3_long)



#######################

library(rstanarm)
options(mc.cores = parallel::detectCores())

initf <- function(chain_id = 1,startvals) {
  list(coefficients =  rnorm(length(startvals),startvals,.1))
} 

n_chains = 4

null_mod3_long = stan_clogit(rapporteur ~ loyalty_long + 
                         com_experience + I(com_experience^2) +
                         loyalty_long:com_experience +
                        loyalty_long:I(com_experience^2)+ 

                          (1 |country) + 
                          (1|country:id_com_country),
                         prior_covariance = decov(regularization = 1, concentration = 1, shape = 1, scale = 1),
                         init = lapply(1:n_chains, 
                                       function(id) initf(chain_id = id,null_model3_long$coefficients)),
                        strata = set_id,data = x_out, adapt_delta = 0.99,
                        prior = student_t(df = 7, location = 0, scale = NULL, autoscale = TRUE), 
                       algorithm = "sampling",
                       QR = TRUE, iter = 5000, chains = n_chains, cores = n_chains)
print(null_mod3_long, digits = 3)


controls3_long = update(null_model3_long, formula = . ~ . +
                     ep_experience +
                     I(ep_experience^2) +
                    participate_long + 
                    age + age_sq +
                    epg_leader + com_leader +
                     ep_leader + 
              switcher + final_year)
summary(controls3_long)


controls_mod3_long = update(null_mod3_long, formula = . ~ . + 
                              ep_experience +
                              I(ep_experience^2) +      
                        participate_long + 
                        age + age_sq +
                        epg_leader + com_leader +
                         ep_leader +
                        switcher + final_year,
                      prior_covariance = decov(regularization = 1, concentration = 1, shape = 1, scale = 1),
                      init = lapply(1:n_chains, function(id) initf(chain_id = id,controls3_long$coefficients)),
                      strata = set_id,data = x_out, adapt_delta = .99,
                      prior = student_t(df = 7, location = 0, scale = NULL, autoscale = TRUE), 
                      algorithm = "sampling",
                      QR = TRUE, iter = 5000, chains = n_chains, cores = n_chains)
print(controls_mod3_long, digits = 4)

null_models_long <- list(null_mod3_long, controls_mod3_long)
save(null_models_long, file = "mod3_null_long.RData", compress = TRUE)
