#### analysis
# models with loyalty * expertise squared
# multilevel models
# country and MEP level
# varying coef at country level
.libPaths("/cluster/home/bjornkho/admin/run4/R") # optimized R and rstan
set.seed(98325)
load("x_out.RData")
x_out$leader <- ifelse(rowSums(cbind(x_out$ep_leader,x_out$ep_bureau))>0,1,0)
x_out$id_com_country <- paste0(x_out$id_com, x_out$country)
library(survival)

#### interactions
null_model3 = clogit(rapporteur ~ loyalty + 
                      com_experience + I(com_experience^2) +
                      loyalty:com_experience +
                       loyalty:I(com_experience^2) +  
                      strata(set_id), data = x_out)
summary(null_model3)



#######################

library(rstanarm)
options(mc.cores = 8)

initf <- function(chain_id = 1,startvals) {
  list(coefficients =  rnorm(length(startvals),startvals,.1))
} 

n_chains = 4

null_mod3_proc = stan_clogit(rapporteur ~ loyalty + 
                         com_experience + I(com_experience^2) +
                         loyalty:com_experience +
                        loyalty:I(com_experience^2)+ 
                          (loyalty + com_experience + I(com_experience^2) + 
                             loyalty:com_experience + loyalty:I(com_experience^2) -1| procedure_stand) +
                          (1|country) + 
                          (1|country:id_com_country),
                         prior_covariance = decov(regularization = 1, concentration = 1, shape = 1, scale = 1),
                         init = lapply(1:n_chains, function(id) initf(chain_id = id,null_model3$coefficients)),
                        strata = set_id,data = x_out, adapt_delta = 0.999,
                        prior = student_t(df = 7, location = 0, scale = NULL, autoscale = TRUE), 
                        algorithm = "sampling",
                        QR = TRUE, iter = 5000, chains = n_chains, cores = 8)
print(null_mod3_proc, digits = 3)
save(null_mod3_proc, file = "null_mod3_procedure.RData", compress = TRUE)
