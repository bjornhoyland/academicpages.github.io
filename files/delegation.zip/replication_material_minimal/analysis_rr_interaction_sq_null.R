#### analysis
# models with loyalty * expertise squared
# multilevel models
# country and MEP level
# varying coef at country level
.libPaths("/cluster/home/bjornkho/admin/run4/R") # optimized R and rstan
set.seed(98325)
load("x_out.RData")
x_out$leader <- ifelse(rowSums(cbind(x_out$ep_leader,x_out$ep_bureau))>0,1,0)
x_out$id_com_country <- paste0(x_out$id_com, x_out$country)
library(survival)

#### interactions
null_model3 = clogit(rapporteur ~ loyalty + 
                      com_experience + I(com_experience^2) +
                      loyalty:com_experience +
                       loyalty:I(com_experience^2) +  
                      strata(set_id), data = x_out)
summary(null_model3)



#######################

library(rstanarm)
options(mc.cores = 8)

initf <- function(chain_id = 1,startvals) {
  list(coefficients =  rnorm(length(startvals),startvals,.1))
} 

n_chains = 4

null_mod3_null = stan_clogit(rapporteur ~ loyalty + 
                         com_experience + I(com_experience^2) +
                         loyalty:com_experience +
                        loyalty:I(com_experience^2)+ 
                          (1 |country) + 
                          (1|country:id_com_country),
                         prior_covariance = decov(regularization = 1, concentration = 1, shape = 1, scale = 1),
                         init = lapply(1:n_chains, function(id) initf(chain_id = id,null_model3$coefficients)),
                        strata = set_id,data = x_out, adapt_delta = 0.99,
                        prior = student_t(df = 7, location = 0, scale = NULL, autoscale = TRUE), 
                       algorithm = "sampling", 
                       QR = TRUE, iter = 5000, chains = n_chains, cores = 8)
print(null_mod3_null, digits = 3)
#save(null_mod3_null, file = "results/null_mod3_null.RData", compress = TRUE)


controls3 = update(null_model3, formula = . ~ . +
                     ep_experience +
                     I(ep_experience^2) +
                    participate + 
                    age + age_sq +
                    epg_leader + com_leader +
                     ep_leader + 
              switcher + final_year)
summary(controls3)


controls_mod3_null = update(null_mod3_null, formula = . ~ . + 
                              ep_experience +
                              I(ep_experience^2) +      
                        participate + 
                        age + age_sq +
                        epg_leader + com_leader +
                         ep_leader +
                        switcher + final_year,
                      prior_covariance = decov(regularization = 1, concentration = 1, shape = 1, scale = 1),
                      init = lapply(1:n_chains, function(id) initf(chain_id = id,controls3$coefficients)),
                      strata = set_id,data = x_out, adapt_delta = .99,
                      prior = student_t(df = 7, location = 0, scale = NULL, autoscale = TRUE), 
                      algorithm = "sampling",
                      QR = TRUE, iter = 5000, chains = n_chains, cores = 8)
print(controls_mod3_null, digits = 4)
#save(controls_mod3_null, file = "results/controls_mod3_null.RData", compress = TRUE)
null_models <- list(null_mod3_null, controls_mod3_null)
save(null_models, file = "mod3_null.RData", compress = TRUE)
