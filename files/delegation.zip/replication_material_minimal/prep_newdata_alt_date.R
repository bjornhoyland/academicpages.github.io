### prepare data for analysis with rstanarm
## a) conformable variable names
## b) identify choice sets
## c) populate choice-set with variables
sink("log_files/prep_newdata_alt_date.log")
library(tidyverse);library(lubridate);library(parallel)
library(enc)
source("helper_funs.r") # helper functions

load("data/ReportsEP1.rda");load("data/MEPsBio.rda")
load("data/ReportsEP2.rda");load("data/ReportsEP3.rda")
load("data/ReportsEP4.rda");load("data/ReportsEP5.rda")
load("data/ReportsEP6.rda");load("data/ReportsEP7.rda")
ReportsEP1$ep = 1
ReportsEP2$ep = 2
ReportsEP3$ep = 3
ReportsEP4$ep = 4
ReportsEP5$ep = 5
ReportsEP6$ep = 6
ReportsEP6$committee = committeeNames(ReportsEP6$committee)
ReportsEP7$ep = 7

ReportsEP5$date = format(as.Date(ReportsEP5$date, format = "%Y-%m-%d"), "%Y%m%d")
  ReportsEP1 %>%  
    as_tibble() %>% 
    committeeStandard() %>% 
    mutate(date = if_else(.$date - 90 > ymd("1979-09-01"), .$date - 90,ymd("1979-09-01"))) -> ReportsEP1
  
  ReportsEP2 %>% 
    as_tibble() %>% 
    committeeStandard() %>% 
    mutate(date = if_else(.$date - 90 > ymd("1984-07-01"), .$date - 90,ymd("1984-07-01"))) -> ReportsEP2
  
  ReportsEP3 %>% 
    as_tibble() %>% 
    committeeStandard() %>% 
    mutate(date = if_else(.$date - 90 > ymd("1989-07-01"), .$date - 90,ymd("1989-07-01"))) -> ReportsEP3
  
  ReportsEP4 %>% 
    as_tibble() %>% 
    committeeStandard() %>% 
    mutate(date = if_else(.$date - 90 > ymd("1994-07-01"), .$date - 90,ymd("1994-07-01"))) -> ReportsEP4
  
  ReportsEP5 %>% 
    as_tibble() %>% 
    committeeStandard() %>% 
    mutate(date = if_else(.$date - 90 > ymd("1999-07-01"), .$date - 90,ymd("1999-07-01"))) -> ReportsEP5
  
  ReportsEP6 %>% 
    as_tibble() %>% 
    committeeStandard() %>% 
    mutate(date = if_else(.$date - 90 > ymd("2004-07-01"), .$date - 90,ymd("2004-07-01"))) -> ReportsEP6
  
  ReportsEP7 %>% 
    as_tibble() %>% 
    committeeStandard() %>% 
    mutate(date = if_else(.$date - 90 > ymd("2009-07-01"), .$date - 90,ymd("2009-07-01"))) -> ReportsEP7

reports <- bind_rows(ReportsEP1,ReportsEP2,ReportsEP3,ReportsEP4,ReportsEP5,ReportsEP6,ReportsEP7)  

reports %>% 
  mutate(rapporteur = enc2utf8(rapporteur),
         committee = enc2utf8(committee),
         procedure = enc2utf8(as.character(procedure)),
         title = enc2utf8(as.character(title))) -> reports

MEPsBio %>% 
  as_tibble() %>% 
  mutate(name = enc2utf8(as.character(name)),
         country = enc2utf8(as.character(country)),
         birthplace = enc2utf8(as.character(birthplace)),
         role = enc2utf8(as.character(role)),
         inst = enc2utf8(as.character(inst)),
         type = enc2utf8(as.character(type)),
         left = as.character(left),
         joined = as.character(joined)
  ) -> MEPsBio

tmpjoin = MEPsBio$left[62087]
tmpleft = MEPsBio$joined[62087]
MEPsBio$left[62087] = tmpleft
MEPsBio$joined[62087] = tmpjoin
MEPsBio$left[MEPsBio$id ==716 & MEPsBio$left == "23/07/1974"] = "23/07/1984" 
MEPsBio$left = as.factor(MEPsBio$left)
MEPsBio$joined = as.factor(MEPsBio$joined)

ep_leaders <- MEPsBio %>% 
  filter(.$inst == "European Parliament") %>% 
  mutate(
    name = as.character(.$name),
    id = as.character(.$id),
    joined = as.Date(.$joined,format="%d/%m/%Y"),
    left = if_else(is.na(as.Date(.$left,format="%d/%m/%Y")),
                   max(as.Date(.$left,format="%d/%m/%Y"),na.rm=TRUE),
                   as.Date(.$left,format="%d/%m/%Y")),
    born = as.Date(born,format="%d/%m/%Y"),
    type = as.character(.$type),
    inst = as.character(.$inst)) %>% 
  as_tibble()

bureau <- MEPsBio %>% 
  filter(.$type == "Bureau") %>% 
  mutate(
  name = as.character(.$name),
id = as.character(.$id),
joined = as.Date(.$joined,format="%d/%m/%Y"),
left = if_else(is.na(as.Date(.$left,format="%d/%m/%Y")),
               max(as.Date(.$left,format="%d/%m/%Y"),na.rm=TRUE),
               as.Date(.$left,format="%d/%m/%Y")),
born = as.Date(born,format="%d/%m/%Y"),
type = as.character(.$type),
inst = as.character(.$inst)) %>% 
  as_tibble()


MEPsBio %>%
  mutate(comNames = as.character(committeeNames(inst)),
         name = as.character(.$name),
         id = as.character(.$id),
         joined = as.Date(.$joined,format="%d/%m/%Y"),
         left = if_else(is.na(as.Date(.$left,format="%d/%m/%Y")),
                        max(as.Date(.$left,format="%d/%m/%Y"),na.rm=TRUE),
                        as.Date(.$left,format="%d/%m/%Y")),
         days_spent = as.numeric(left - joined)/1,
         born = as.Date(born,format="%d/%m/%Y"),
         type = as.character(.$type),
         inst = as.character(.$inst),
         epg = if_else(.$type == "Parliament Group",.$inst,NULL)) %>%
 mutate(epg = if_else(.$epg == "Liberal and Democratic Group", "Liberal and Democratic Reformist Group",as.character(.$epg)),
epg = if_else(.$epg == "Socialist Group" , "Group of the Party of European Socialists",as.character(.$epg)),
epg = if_else(.$epg == "Left Unity" , "Group for the European United Left",as.character(.$epg)),
epg = if_else(.$epg == "Technical Group of the European Right" , "Group of the European Right",as.character(.$epg)),
epg = if_else(.$epg == "Confederal Group of the European United Left" , "Confederal Group of the European United Left/Nordic Green Left",as.character(.$epg)), 
epg = if_else(.$epg == "Group Union for Europe" , "Group of the European Democratic Alliance",as.character(.$epg)),
epg = if_else(.$epg == "Europe of Nations Group (Coordination Group)" , "Group of the European Democratic Alliance",as.character(.$epg))) %>%
  filter(.$type == "Parliament Group" | .$type == "Committee" | .$type == "National Party") %>%
     filter(.$role != "Substitute" & .$role != "Observer" & .$role != "Substitute Observer") -> MEPsBio

unique(as.factor(MEPsBio$epg))
pes_string = unique(as.factor(MEPsBio$epg))[c(3,6,14,19)]
epp_string = unique(as.factor(MEPsBio$epg))[c(2,7,8,15,17)]
lib_string = unique(as.factor(MEPsBio$epg))[c(9,10,11,41)]
ed_string = unique(as.factor(MEPsBio$epg))[c(18,29)]
left_string = unique(as.factor(MEPsBio$epg))[c(5,22,23,30,39,46,48)]
uen_string = unique(as.factor(MEPsBio$epg))[c(24,25,26,28,42,49)]
green_string = unique(as.factor(MEPsBio$epg))[c(4,16)]
rain_string = unique(as.factor(MEPsBio$epg))[c(32,33)]
right_string = unique(as.factor(MEPsBio$epg))[c(13,40)]
edd_string = unique(as.factor(MEPsBio$epg))[c(21,34)]
non_string = unique(as.factor(MEPsBio$epg))[c(12,20)]
tgi_string = unique(as.factor(MEPsBio$epg))[c(27,31,36)]
forza_string = unique(as.factor(MEPsBio$epg))[c(43)]
era_string = unique(as.factor(MEPsBio$epg))[c(45)]
its_string = unique(as.factor(MEPsBio$epg))[c(47)]
inddem_string = unique(as.factor(MEPsBio$epg))[c(35)]
efd_string = unique(as.factor(MEPsBio$epg))[c(38,44)]
erc_string = unique(as.factor(MEPsBio$epg))[c(37)]

MEPsBio = MEPsBio %>%
  mutate(epg = case_when(is.element(.$epg, pes_string) ~ "SOC",
                         is.element(.$epg, epp_string) ~ "EPP",
                         is.element(.$epg, lib_string) ~ "LIB",
                         is.element(.$epg, ed_string) ~ "ED",
                         is.element(.$epg, left_string) ~ "EUL-NGL",
                         is.element(.$epg, uen_string) ~ "UEN",
                         is.element(.$epg, green_string) ~ "Green",
                         is.element(.$epg, right_string) ~ "right",
                         is.element(.$epg, edd_string) ~ "EDD",
                         is.element(.$epg, non_string) ~ "Non",
                         is.element(.$epg, tgi_string) ~ "TGI",
                         is.element(.$epg, rain_string) ~ "rain",
                         is.element(.$epg, forza_string) ~ "Forza",
                         is.element(.$epg, era_string) ~ "ERA",
                         is.element(.$epg, its_string) ~ "ITS",
                         is.element(.$epg, inddem_string) ~ "IndDem",
                         is.element(.$epg, efd_string) ~ "EFD",
                         is.element(.$epg, erc_string) ~ "ERC")
         )

groups = MEPsBio %>%  
  filter(is.na(epg) == FALSE)

coms = MEPsBio %>%
  filter(is.na(comNames) == FALSE) %>%
  as_tibble()

committeeSet = function(report){
coms %>%
  filter(.$comNames == report$committee &
           .$joined <= report$date &
           .$left >= report$date)
}

tmp = NULL
out = list()
for (i in 1:nrow(reports)){
  report = reports[i,]
  ## indentify committee compostion and rapporteur
  tmp = committeeSet(report)
  tmp$rapporteur = if_else(report$id== tmp$id,1,0)
  # add report variables
  tmp$date = rep(report$date,nrow(tmp))
  tmp$procedure = rep(report$procedure,nrow(tmp))
  tmp$reportID = rep(report$reportID,nrow(tmp))
  tmp$title = rep(report$title,nrow(tmp))
  tmp$setID = rep(i,nrow(tmp))
  tmp$ep = rep(report$ep,nrow(tmp))
  # find relevant political group
  if(sum(tmp$rapporteur)==0){
    next } else {
party = groups %>%
  filter(.$joined <= unique(tmp$date) &
           .$left >= unique(tmp$date) &
           .$id == tmp$id[tmp$rapporteur==1]) %>%
  .$epg

partymembers = groups %>%
  filter(.$joined <= tmp$date[1] &
           .$left >= tmp$date[1] &
           .$epg == party)

ep_lead <- ep_leaders %>%
  filter(.$joined <= tmp$date[1] &
           .$left >= tmp$date[1])
ep_bur <- bureau %>% 
  filter(.$joined <= tmp$date[1] &
           .$left >= tmp$date[1])

# restrict to committee members in relevant group
tmp = inner_join(tmp,partymembers, by =c("id","name","country","born","birthplace"))
tmp = left_join(tmp,bureau, by =c("id","name","country","born","birthplace"))
tmp = left_join(tmp,ep_leaders, by =c("id","name","country","born","birthplace"))

tmp %>%
  transmute(rapporteur = .$rapporteur,
            date = .$date,
            id = .$id,
            name = .$name,
            country = .$country,
            age = as.numeric(.$date - .$born)/365,
            joined_committee = .$joined.x,
            left_committee = .$left.x,
            days_committee = as.numeric(.$date - .$joined.x)/1,
            committee = .$comNames.x,
            com_leader = if_else(.$role.x == "Member",0,1),
            joined_group = .$joined.y,
            left_group = .$left.y,
            days_group = as.numeric(.$date - .$joined.y)/1,
            epg = .$epg.y,
            epg_leader = if_else(.$role.y == "Member",0,1),
            ep_bureau = if_else(is.na(.$role.x.x),0,1),
            ep_leader = if_else(is.na(.$role.y.y),0,1),
            procedure = .$procedure,
            report_title = as.character(.$title),
            report_id = as.character(.$reportID),
            set_id = .$setID,
            ep = .$ep
            ) %>% 
  unique() -> tempset
tempset$set_size <- nrow(tempset)
out[[i]] <- tempset
}
}
x_out <- bind_rows(out)

# add variables: previous reports, experience, final year

x_out = x_out %>%
  mutate(com_experience = unlist(mclapply(seq_along(.$date), com_exper, mc.cores = 8)),
         group_experience = unlist(mclapply(seq_along(.$date), group_exper, mc.cores = 8)),
        ep_experience = unlist(mclapply(seq_along(.$date), ep_exper, mc.cores = 8)),
         prev_reports = unlist(mclapply(seq_along(.$date), prev_rep, mc.cores = 8)),
        final_year = unlist(mclapply(seq_along(.$date), final_yr, mc.cores = 8)))

summary(x_out[x_out$ep==6,])
summary(x_out[x_out$ep==7,])
summary(x_out[x_out$ep==3,])
summary(x_out)



# Add  Loyalty and participation 
#load RCV data
load("data/ep1.rda"); load("data/ep2.rda") 
load("data/ep3.rda"); load("data/ep4.rda")
load("data/ep5.rda"); load("data/ep6.rda")
load("data/ep7.rda")

ep1pos = ep1 %>% 
  pos(yes = 1, no = 2)

ep1pos_nat <- ep1 %>% 
  pos(yes = 1, no = 2, party = "party")

ep2pos = ep2 %>%
  pos(yes = 1, no = 2)

ep2pos_nat <- ep2 %>% 
  pos(yes = 1, no = 2, party = "party")

ep3pos = ep3 %>%
  pos(yes = 1, no = 2)

ep3pos_nat <- ep3 %>% 
  pos(yes = 1, no = 2, party = "natparty")

ep4pos = ep4 %>%
  pos(yes = 1, no = 2)

ep4pos_nat <- ep4 %>% 
  pos(yes = 1, no = 2, party = "party")

ep5pos = ep5 %>%
  pos(yes = 1, no = 2)

ep5pos_nat <- ep5 %>% 
  pos(yes = 1, no = 2, party = "party")

ep6pos = ep6 %>%
  pos(yes = 1, no = 2)

ep6pos_nat <- ep6 %>% 
  pos(yes = 1, no = 2, party = "party")

ep7pos = ep7 %>%
  pos(yes = 1, no = 2) 

ep7pos_nat <- ep7 %>% 
  pos(yes = 1, no = 2, party = "party")

x_out$natparty <- paste(x_out$epg, x_out$country, sep = "_")

x_out$partic = 0
x_out$partic_yn = 0
x_out$total_votes = 0
x_out$loyal_votes = 0
x_out$partic_total = 0
x_out$partic_yn_total = 0 
x_out$total_votes_total = 0
x_out$loyal_votes_total = 0
x_out$partic_short = 0
x_out$partic_yn_short = 0
x_out$total_votes_short = 0
x_out$loyal_votes_short = 0
x_out$loyal_votes_nat = 0

eps <- list(ep1,ep2,ep3,ep4,ep5,ep6,ep7)
eps_pos <- list(ep1pos,ep2pos,ep3pos,ep4pos,
               ep5pos,ep6pos,ep7pos)
eps_pos_nat <- list(ep1pos_nat,ep2pos_nat,ep3pos_nat,ep4pos_nat,
                    ep5pos_nat,ep6pos_nat,ep7pos_nat)

for (j in 1:7){
x_out$partic[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                              function(i) participation(x_out[i,],eps[[j]]),
                              mc.cores = 8)))
x_out$partic_yn[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                 function(i) participation_yesno(x_out[i,],eps[[j]]),
                                 mc.cores = 8)))
x_out$total_votes[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                 function(i) total_v(x_out[i,],eps[[j]]),
                                 mc.cores = 8)))
x_out$loyal_votes[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                   function(i) loyal_v(x_out[i,],eps[[j]],eps_pos[[j]]),
                                   mc.cores = 8)))
x_out$loyal_votes_nat[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                                 function(i) loyal_nat(x_out[i,],eps[[j]],eps_pos_nat[[j]]),
                                                                 mc.cores = 8)))
x_out$partic_short[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                            function(i) participation_short(x_out[i,],eps[[j]]),
                                                            mc.cores = 8)))
x_out$partic_yn_short[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                               function(i) participation_yesno_short(x_out[i,],eps[[j]]),
                                                               mc.cores = 8)))
x_out$total_votes_short[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                                 function(i) total_v_short(x_out[i,],eps[[j]]),
                                                                 mc.cores = 8)))
x_out$loyal_votes_short[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                                 function(i) loyal_v_short(x_out[i,],eps[[j]],eps_pos[[j]]),
                                                                 mc.cores = 8)))
if (j > 1){
  x_out$partic_total[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                                    function(i) sum(x_out$partic[i], #_total includes behavior previous term
                              ifelse(
                                max(x_out$partic[x_out$id == x_out$id[i] & x_out$ep ==(j-1)])>0,
                                max(x_out$partic[x_out$id == x_out$id[i] & x_out$ep ==(j-1)]),0)),
                              mc.cores = 8)))
  x_out$partic_yn_total[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                                    function(i) sum(x_out$partic_yn[i], #_total includes behavior previous term
                                                                                    ifelse(
                                                                                      max(x_out$partic_yn[x_out$id == x_out$id[i] & x_out$ep ==(j-1)])>0,
                                                                                      max(x_out$partic_yn[x_out$id == x_out$id[i] & x_out$ep ==(j-1)]),0)),
                                                                    mc.cores = 8)))
  x_out$total_votes_total[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                                       function(i) sum(x_out$total_votes[i], #_total includes behavior previous term
                                                                                       ifelse(
                                                                                         max(x_out$total_votes[x_out$id == x_out$id[i] & x_out$ep ==(j-1)])>0,
                                                                                         max(x_out$total_votes[x_out$id == x_out$id[i] & x_out$ep ==(j-1)]),0)),
                                                                       mc.cores = 8)))
  x_out$loyal_votes_total[which(x_out$ep == j)] = unlist(unlist(mclapply(which(x_out$ep == j),
                                                                         function(i) sum(x_out$loyal_votes[i], #_total includes behavior previous term
                                                                                         ifelse(
                                                                                           max(x_out$loyal_votes[x_out$id == x_out$id[i] & x_out$ep ==(j-1)])>0,
                                                                                           max(x_out$loyal_votes[x_out$id == x_out$id[i] & x_out$ep ==(j-1)]),0)),
                                                                         mc.cores = 8)))

} else {
  x_out$partic_total[which(x_out$ep == j)] = x_out$partic[which(x_out$ep == j)] 
  x_out$partic_yn_total[which(x_out$ep == j)] = x_out$partic_yn[which(x_out$ep == j)] 
  x_out$total_votes_total[which(x_out$ep == j)] = x_out$total_votes[which(x_out$ep == j)] 
  x_out$loyal_votes_total[which(x_out$ep == j)] = x_out$loyal_votes[which(x_out$ep == j)] 
}
message(j)
}

x_out = x_out %>%
  mutate(switcher = if_else(.$ep_experience > 365 + .$group_experience,1,0),
         loyalty = .$loyal_votes / (.$partic +1),
         loyalty_short = .$loyal_votes_short / (.$partic_short +1),
         loyalty_yn = .$loyal_votes / (.$partic_yn + 1),
         loyalty_natparty = .$loyal_votes_nat / (.$partic +1),
         participate = .$partic / (.$total_votes + 1),
         participate_yn = .$partic_yn / (.$total_votes +1),
         loyalty_long = .$loyal_votes_total / (.$partic_total +1), # includes data from the term before
         loyalty_yn_long = .$loyal_votes_total / (.$partic_yn_total + 1),
         participate_long = .$partic_total / (.$total_votes_total + 1),
         participate_yn_long = .$partic_yn_total / (.$total_votes_total +1),
         loyalty_yn_short = .$loyal_votes_short / (.$partic_yn_short + 1),
         participate_short = .$partic_short / (.$total_votes_short + 1),
         participate_yn_short = .$partic_yn_short / (.$total_votes_short +1),
         id_com = paste0(.$id,.$committee) #Committee-specific MEP id
         )
unique(x_out$procedure)

x_out = x_out %>%
  mutate(procedure_stand = case_when(.$procedure == "Consultation" ~ "CNS",
                               .$procedure == "Cooperation - 1st reading" ~ "COS",
                               .$procedure == "Cooperation - 2nd reading" ~ "COS",
                               .$procedure == "2nd Consultation" ~ "CNS",
                               .$procedure == "Codecision - 1st reading" ~ "COD",
                               .$procedure == "Codecision - 2nd reading" ~ "COD",
                               .$procedure == "I Cooperation" ~ "COS",
                               .$procedure == "I Cooperation" ~ "COS",
                               .$procedure == "COS" ~ "COS",
                               .$procedure == "CNS" ~ "CNS",
                               .$procedure == "COD1" ~ "COD",
                               .$procedure == "COD2" ~ "COD",
                               .$procedure == "COD3" ~ "COD",
                               .$procedure == "COD" ~ "COD",
                               .$procedure == "BUD" ~ "BUD",
                               .$procedure == "Ordinary legislative procedure" ~ "COD",
                               .$procedure == "Consultation procedure" ~ "CNS",
                               .$procedure == "Cooperation procedure" ~ "COS",
                               .$procedure == "Resolution" ~ "Other",
                               .$procedure == "Budget resolution" ~ "BUD",
                               .$procedure == "Optional consultation" ~ "Other",
                               .$procedure == "Budget consultation" ~ "BUD",
                               .$procedure == "Approval of minutes" ~ "Other",
                               .$procedure == "Agenda" ~ "Other",
                               .$procedure == "Budget resolution" ~ "BUD",
                               .$procedure == "Resolution" ~ "Other",
                               .$procedure == "Assent" ~ "AVC",
                               .$procedure == "Enlargement of European Union" ~ "AVC",
                               .$procedure == "Assent procedure" ~ "AVC",
                               .$procedure == "Consent procedure" ~ "AVC",
                               .$procedure == "Consent procedure" ~ "AVC",
                               .$procedure == "ACC" ~ "AVC",
                               .$procedure == "APP" ~ "AVC",
                               .$procedure == "AVC" ~ "AVC",
                               TRUE ~ "Other"))
x_out = x_out %>%
  filter(.$set_size >1)

x_out = x_out %>%
  mutate(com_experience = .$com_experience/3650, # in decadea
         group_experience = .$group_experience/3650, # in decadea
         ep_experience = .$ep_experience/3650) # in decades

summary(x_out)
summary(x_out[x_out$ep == 1,])
summary(x_out[x_out$ep == 2,])
summary(x_out[x_out$ep == 3,])
summary(x_out[x_out$ep == 4,])
summary(x_out[x_out$ep == 5,])
summary(x_out[x_out$ep == 6,])
summary(x_out[x_out$ep == 7,])

x_out$loyalty = ifelse(is.na(x_out$loyalty),0,x_out$loyalty)
x_out$loyalty_yn = ifelse(is.na(x_out$loyalty_yn),0,x_out$loyalty_yn)
x_out$loyalty_long = ifelse(is.na(x_out$loyalty_long),0,x_out$loyalty_long)
x_out$loyalty_yn_long = ifelse(is.na(x_out$loyalty_yn_long),0,x_out$loyalty_yn_long)
x_out$loyalty_short = ifelse(is.na(x_out$loyalty_short),0,x_out$loyalty_short)
x_out$loyalty_yn_short = ifelse(is.na(x_out$loyalty_yn_short),0,x_out$loyalty_yn_short)
x_out$participate = ifelse(is.na(x_out$participate),0,x_out$participate)
x_out$participate_yn = ifelse(is.na(x_out$participate_yn),0,x_out$participate_yn)
x_out$participate_long = ifelse(is.na(x_out$participate_long),0,x_out$participate_long)
x_out$participate_short = ifelse(is.na(x_out$participate_short),0,x_out$participate_short)

x_out$loyalty_sq = x_out$loyalty^2
x_out$com_experience_sq = x_out$com_experience^2
x_out$ep_experience_sq = x_out$ep_experience^2

x_out$age = ifelse(is.na(x_out$age),rnorm(1,mean(x_out$age, na.rm= TRUE)),x_out$age)
x_out$age_sq = x_out$age^2

x_out_alt_date <- x_out

save(x_out_alt_date, file = "x_out_alt_date.RData")
sink()