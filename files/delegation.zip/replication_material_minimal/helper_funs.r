# helper functions for the scripts

# fix committee names
committeeNames <- function(y){
  afetstring <- c("Committee on Foreign Affairs","Political Affairs Committee",
                  "Committee on Foreign Affairs, Human Rights, Common Security and Defence Policy","Committee on Foreign Affairs, Security and Defence Policy"
                  ,"Committee on Foreign Affairs and Security")
  
  envistring <- c("Committee on the Environment, Public Health and Food Safety","Committee on the Environment, Public Health and Consumer Protection",
                  "Committee on the Environment, Public Health and Consumer Policy")
  libestring <- c("Committee on Civil Liberties, Justice and Home Affairs","Committee on Citizens' Freedoms and Rights, Justice and Home Affairs",
                  "Committee on Civil Liberties and Internal Affairs")
  itrestring <- c("Committee on Industry, Research and Energy","Committee on Research, Technological Development and Energy",
                  "Committee on Energy and Research","Committee on Energy, Research and Technology","Committee on Industry, External Trade, Research and Energy")
  registring <- c("Committee on Regional Development","Committee on Regional Policy, Transport and Tourism","Committee on Regional Policy","Committee on Regional Policy and Regional Planning",
                  "Committee on Regional Policy, Regional Planning and Relations with Regional and Local Authorities","Committee on Regional Policy, Regional Planning and Transport")
  transtring <- c("Committee on Transport and Tourism","Committee on Transports and Tourism","Committee on Transports","Committee on Transport")
  econstring <- c("Committee on Economic and Monetary Affairs","Committee on Economic and Monetary Affairs and Industrial Policy")
  emplstring <- c("Committee on Employment and Social Affairs","Committee on Social Affairs and Employment",
                  "Committee on Social Affairs, Employment and the Working Environment","Committee on Social Affairs, Employment and Education")
  budgstring <- "Committee on Budgets"
  agristring <- c("Committee on Agriculture and Rural Development","Committee on Agriculture, Fisheries and Rural Development","Committee on Agriculture, Fisheries and Food","Committee on Agriculture")
  imcostring <- "Committee on the Internal Market and Consumer Protection"
  petistring <- c("Committee on Petitions","Committee on the Rules of Procedure, the Verification of Credentials and Immunities","Committee on the Verification of Credentials","Committee on the Rules of Procedure, the Verification of Credencials and Immunities",
                  "Committee on the Rules of Procedure and Petitions","Committee on the Rules of Procedure, the Verification of Credencials and Immunities",
                  "Committee on the Rules of Procedure, the Verification of Credencials and Immunities","Committee on the verification of credentials")
  femmstring <- c("Committee on Women's Rights and Gender Equality","Committee on Women's Rights and Equal Opportunities",
                  "Committee of inquiry into the situation of women in Europe","Committee on Women's Rights")
  intastring <- c("Committee on International Trade","Committee on External Economic Relations")
  contstring <- "Committee on Budgetary Control"
  cultstring <- c("Committee on Culture and Education","Committee on Culture, Youth, Education and the Media","Committee on Youth, Culture, Education, Information and Sport","Committee on Culture, Youth, Education, the Media and Sport",
                  "Committee on Youth, Culture, Education, the Media and Sport")
  devestring <- c("Committee on Development","Committee on Development and Cooperation")
  juristring <- c("Committee on Legal Affairs","Committee on Legal Affairs and Citizens' Rights","Committee on Legal Affairs and the Internal Market","Legal Affairs Committee")
  pechstring <- "Committee on Fisheries"
  afcostring <- c("Committee on Constitutional Affairs","Committee on Institutional Affairs")
  crisstring <- "Special Committee on the Financial, Economic and Social Crisis"
  crimstring <- "Special Committee on Organised Crime, Corruption and Money Laundering"
  climstring <- "Temporary Committee on Climate Change"
  ciastring <- "Temporary Committee on the alleged use of European countries by the CIA for the transport and illegal detention of prisoners"
  equlifestring <- "Committee of Inquiry into the crisis of the Equitable Life Assurance Society"
  
  y <- trim(y)
  tmp <- NA
  for (i in 1:length(afetstring)){
    tmp <- ifelse(y==afetstring[i],"AFET",tmp)
  }
  for (i in 1:length(envistring)){
    tmp <- ifelse(y==envistring[i],"ENVI",tmp)
  }
  for (i in 1:length(libestring)){
    tmp <- ifelse(y==libestring[i],"LIBE",tmp)
  }
  for (i in 1:length(itrestring)){
    tmp <- ifelse(y==itrestring[i],"ITRE",tmp)
  }
  for (i in 1:length(registring)){
    tmp <- ifelse(y==registring[i],"REGI",tmp)
  }
  for (i in 1:length(transtring)){
    tmp <- ifelse(y==transtring[i],"TRAN",tmp)
  }
  for (i in 1:length(econstring)){
    tmp <- ifelse(y==econstring[i],"ECON",tmp)
  }
  for (i in 1:length(emplstring)){
    tmp <- ifelse(y==emplstring[i],"EMPL",tmp)
  }
  for (i in 1:length(budgstring)){
    tmp <- ifelse(y==budgstring[i],"BUDG",tmp)
  }
  for (i in 1:length(agristring)){
    tmp <- ifelse(y==agristring[i],"AGRI",tmp)
  }
  for (i in 1:length(imcostring)){
    tmp <- ifelse(y==imcostring[i],"IMCO",tmp)
  }
  for (i in 1:length(petistring)){
    tmp <- ifelse(y==petistring[i],"PETI",tmp)
  }
  for (i in 1:length(femmstring)){
    tmp <- ifelse(y==femmstring[i],"FEMM",tmp)
  }
  for (i in 1:length(intastring)){
    tmp <- ifelse(y==intastring[i],"INTA",tmp)
  }
  for (i in 1:length(contstring)){
    tmp <- ifelse(y==contstring[i],"CONT",tmp)
  }
  for (i in 1:length(cultstring)){
    tmp <- ifelse(y==cultstring[i],"CULT",tmp)
  }
  for (i in 1:length(devestring)){
    tmp <- ifelse(y==devestring[i],"DEVE",tmp)
  }
  for (i in 1:length(juristring)){
    tmp <- ifelse(y==juristring[i],"JURI",tmp)
  }
  for (i in 1:length(pechstring)){
    tmp <- ifelse(y==pechstring[i],"PECH",tmp)
  }
  for (i in 1:length(afcostring)){
    tmp <- ifelse(y==afcostring[i],"AFCO",tmp)
  }
  for (i in 1:length(crimstring)){
    tmp <- ifelse(y==crimstring[i],"CRIM",tmp)
  }
  for (i in 1:length(climstring)){
    tmp <- ifelse(y==climstring[i],"CLIM",tmp)
  }
  for (i in 1:length(ciastring)){
    tmp <- ifelse(y==ciastring[i],"CIA",tmp)
  }
  for (i in 1:length(equlifestring)){
    tmp <- ifelse(y==equlifestring[i],"EQULIFE",tmp)
  }
  for (i in 1:length(crisstring)){
    tmp <- ifelse(y==crisstring[i],"CRIS",tmp)
  }
  return(as.factor(tmp))
}
trim <- function(x) {
  gsub("(^[[:space:]]+|[[:space:]]+$)", "", x)
}
NULL    

committeeStandard = function(reports){
  reports %>% 
    mutate(committee = as.character(committee)) %>%
    mutate(
      committee = case_when(.$committee == "ACTE" ~ "ECON",
                            .$committee == "ASOC" ~ "EMPL",
                            .$committee == "ENER" ~ "ITRE",
                            .$committee == "ENQU" ~ "PETI",
                            .$committee == "FISH" ~ "PECH",
                            .$committee == "INST" ~ "AFCO",
                            .$committee == "JEUN" ~ "CULT",
                            .$committee == "LEGA" ~ "JURI",
                            .$committee == "POLI" ~ "AFET",
                            .$committee == "REGL" ~ "PETI",
                            .$committee == "RELA" ~ "INTA",
                            .$committee == "RETT" ~ "TRAN",
                            .$committee == "SOCI" ~ "JEUN",
                            .$committee == "VERI" ~ "PETI", 
                            .$committee == "BUDE" ~ "BUDG",  
                            TRUE ~ .$committee),
      date = ymd(.$date),
      rapporteur = as.character(.$rapporteur),
      id = as.character(.$id)
    )
}

# calculates the majority position on a vote-by-vote basis. By party and outcome
pos <- function(data, size=3,yes =1,no=2, party = "group"){
  all <- list()  
  # by party
  if(party== "group"){
    tmp <- data$legis.data$party
  }else if (party == "party") {
    tmp <- as.factor(paste(data$legis.data$party,data$legis.data$state, sep = "_"))
  } else {
    stop
  }
  realparties <- summary(tmp)>size
  realparties <- names(realparties[realparties==TRUE])
  for (p in realparties){
    yea <- apply(data$votes[tmp==p,]==yes,MARGIN=2,FUN=sum,na.rm=TRUE)
    nay <- apply(data$votes[tmp==p,]==no,MARGIN=2,FUN=sum,na.rm=TRUE)
    out <- apply(cbind(yea,nay),1,which.max)
    all[[p]]<- ifelse(out==1,"yes","no")
  }
  #overall
  yea <- apply(data$votes==yes,MARGIN=2,FUN=sum,na.rm=TRUE)
  nay <- apply(data$votes==no,MARGIN=2,FUN=sum,na.rm=TRUE)
  out <-apply(cbind(yea,nay),1,which.max)
  all[["outcome"]] <- ifelse(out==1,"yes","no")
  # turn into a table
  outtable <- do.call(cbind,all)
  rownames(outtable)   <- data$vote.data$vote.id
  return(outtable)
}

# add variables: previous reports, experience, final year
com_exper = function(x) { 
  MEPsBio %>%
    filter(.$id == x_out$id[x] &
             .$comNames == x_out$committee[x] &
             .$joined < x_out$date[x] &
             .$left < x_out$date[x]) %>%
    .$days_spent %>%
    sum() %>%
    + x_out$days_committee[x]
}

group_exper = function(x) { 
  MEPsBio %>%
    filter(.$id == x_out$id[x] &
             .$epg == x_out$epg[x] &
             .$joined < x_out$date[x] &
             .$left < x_out$date[x]) %>%
    .$days_spent %>%
    sum() %>%
    + x_out$days_group[x]
}

ep_exper = function(x) { 
  MEPsBio %>%
    filter(.$id == x_out$id[x] &
             .$type == "Parliament Group" &
             .$joined < x_out$date[x] &
             .$left < x_out$date[x]) %>%
    .$days_spent %>%
    sum() %>%
    + x_out$days_group[x]
}

final_yr = function(x) { 
  days_left = MEPsBio %>%
    filter(.$id == x_out$id[x] &
             .$type == "Parliament Group" &
             .$joined > x_out$date[x] &
             .$left > x_out$date[x]) %>%
    .$days_spent %>%
    sum() %>%
    + x_out$left_group[x] - x_out$date[x]
  if_else(days_left > 365,0,1)
}

prev_rep = function(x) { 
  x_out %>%
    filter(.$id == .$id[x] &
             .$committee == .$committee[x] & # innad i kommittee
             .$date < .$date[x]) %>%
    .$rapporteur %>%
    sum()
}

participation = function(x,votedata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset= votedata$vote.data$Date<x$date))
  sum(votedata$votes[leg,relvote] <3)
}

participation_short = function(x,votedata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset= votedata$vote.data$Date < x$date & 
                               votedata$vote.data$Date > x$date-365))
  tmp = votedata$votes[leg,relvote]
  sum(tmp<3) 
}

participation_yesno = function(x,votedata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset= votedata$vote.data$Date < x$date))
  tmp = votedata$votes[leg,relvote]
  sum(tmp>0 & tmp<3)
}
participation_yesno_short = function(x,votedata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset= votedata$vote.data$Date < x$date & 
                               votedata$vote.data$Date > x$date - 365))
  tmp = votedata$votes[leg,relvote]
  sum(tmp>0 & tmp<3)
}

total_v = function(x,votedata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset= votedata$vote.data$Date < x$date))
  tmp = votedata$votes[leg,relvote]
  sum(tmp<5)
}

total_v_short = function(x,votedata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset= votedata$vote.data$Date < x$date & 
                               votedata$vote.data$Date > x$date - 365))
  tmp = votedata$votes[leg,relvote]
  sum(tmp<5)
}

loyal_v = function(x,votedata,posdata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset= votedata$vote.data$Date < x$date))
  tmp = ifelse(votedata$votes[leg,relvote]==2,"no",ifelse(votedata$votes[leg,relvote]==1,"yes","miss"))
  tmp_pos = posdata[,x$epg][1:length(tmp)]
  if(length(tmp_pos)>0){
    sum(tmp_pos == tmp)
  }else {
    NA
  }
}

loyal_v_short = function(x,votedata,posdata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset=votedata$vote.data$Date < x$date & 
                               as.Date(votedata$vote.data$Date)>as.Date(x$date)-365))
  tmp = ifelse(votedata$votes[leg,relvote]==2,"no",ifelse(votedata$votes[leg,relvote]==1,"yes","miss"))
  tmp_pos = posdata[,x$epg][1:length(tmp)]
  if(length(tmp_pos)>0){
    sum(tmp_pos == tmp)
  }else {
    NA
  }
}

loyal_nat = function(x,votedata,posdata){
  leg = row.names(votedata$legis.data[votedata$legis.data$id == x$id,])
  relvote = row.names(subset(votedata$vote.data, subset= votedata$vote.data$Date < x$date))
  tmp = ifelse(votedata$votes[leg,relvote]==2,"no",ifelse(votedata$votes[leg,relvote]==1,"yes","miss"))
  if (is.element(x$natparty, colnames(posdata))){
    tmp_pos = posdata[,x$natparty][1:length(tmp)]
    if(length(tmp_pos)>0){
      sum(tmp_pos == tmp)
    }else {
      NA
    }} else{
      NA
    }
}



