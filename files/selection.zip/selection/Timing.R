##################################
## Figure of the conditional     #
## effect of the electoral cycle #
## on the effect of  experience  #
##################################
ruler <- seq(-1,1,length=10000)
example <- 5
values <- fixef(postEffects)[,17]*example +
  fixef(postEffects)[,12]

length(ruler)
length(values)
out <- data.frame()
for (i in 1:length(ruler)){
test <- quantile(values*abs(ruler[i])+ 
                 fixef(postEffects)[,2]*example,
                 probs=c(0.025,.5,.975))
out <- rbind(out,test)
}
dim(out)
out[1:10,]

alpha.bar <- out[,2]
alpha.ci <- rbind(out[,1],out[,3]) #95 % central tendency
dseq <- ruler
pdf(file="EffectTiming.pdf",height=8, width=14)
#par(mfrow=c(1,1))
plot(dseq,alpha.bar,
     type="n",
     axes=T,
     xlab="Midterm",
     ylab="Change in vote share",
     xlim=c(-1,1),
     ylim=c(-3,10),
     main="Timing of the EP elections",
     yaxs="i",
     xaxs="i")

polygon(x=c(dseq,rev(dseq)),
        y=c(alpha.ci[1,],rev(alpha.ci[2,])),
        border=F,
        col=gray(.75))
lines(dseq,alpha.bar,lwd=3)


abline(h=0,lty=1,lwd=1)
dev.off()
