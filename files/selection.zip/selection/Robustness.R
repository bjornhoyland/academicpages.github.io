# Main results
source("ModelResults.R")
names(Data)
Data$votechange <- Data$voteshareEP - Data$PartySize
Data$turnoutDiff <- Data$turnoutEP - Data$turnoutNatElect
cor(Data$experienceMax,Data$turnoutDiff,use="complete.obs")
sd(Data$experienceMax,na.rm=TRUE)
sd(Data$experienceMean,na.rm=TRUE)
summary(Data$position)

model0 <- lmer(votechange~ 1 +	
	(1|country)+(1|electionTime),
	data=Data,REML=FALSE)
model0

model1<- lmer(votechange ~ experienceMax + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
	electionCloseness  +
              PartySize +
	electionCloseness:governingParty+
	experienceMax:governingParty + 
	experienceMax:electionCloseness +
              (1|electionTime)+
	(experienceMax + governingParty + electionCloseness|country),
	data=Data,REML=FALSE)
summary(model1)
conf <- cbind(fixef(model1) - 1.96*se.fixef(model1),
          fixef(model1) + 1.96*se.fixef(model1))
conf

model2<- lmer(votechange ~ experienceMax + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
	electionCloseness  +
              PartySize +
	electionCloseness:governingParty+
	experienceMax:governingParty +  systemIndex + systemIndex:experienceMax +
	experienceMax:electionCloseness + electionThreshold + electionThreshold:experienceMax+
              (1|electionTime)+
	(experienceMax + governingParty + electionCloseness|country),
	data=Data,REML=FALSE)
summary(model2)


model3<- lmer(votechange ~ position + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
	electionCloseness  + 
              PartySize + systemIndex + systemIndex:position +
              electionThreshold + electionThreshold:position+
	electionCloseness:governingParty+
	position:governingParty + 
	position:electionCloseness +
              (1|electionTime)+
	(position + governingParty + electionCloseness|country),
	data=Data,REML=FALSE)
summary(model3)


model4<- lmer(votechange ~ experienceMax + position + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
	electionCloseness  +
              PartySize + electionThreshold + electionThreshold:experienceMax+
	electionCloseness:governingParty+
              	experienceMax:governingParty +
	experienceMax:electionCloseness +
              electionThreshold:position+
	position:governingParty + 
	position:electionCloseness +
              (1|electionTime)+
	(experienceMax + position + governingParty + electionCloseness|country),
	data=Data,REML=FALSE)
summary(model4)

model4a<- lmer(votechange ~ experienceMean + position + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
	electionCloseness  +
              PartySize + electionThreshold + electionThreshold:experienceMean+
	electionCloseness:governingParty+
              	experienceMean:governingParty +
	experienceMean:electionCloseness +
              electionThreshold:position+
	position:governingParty + 
	position:electionCloseness +
              (1|electionTime)+
	(experienceMean + position + governingParty + electionCloseness|country),
	data=Data,REML=FALSE)
summary(model4a)

model1Fixed<- lm(votechange ~ -1+experienceMax + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
	electionCloseness  +
              PartySize +
	electionCloseness:governingParty+
              	experienceMax:governingParty +
	experienceMax:electionCloseness + 
	factor(country)+factor(electionTime),
	data=Data)
AIC(model1Fixed)
robust1 <- coeftest(model1Fixed, vcov = vcovHAC)
robust1

model4Fixed<- lm(votechange ~ -1+experienceMax + position + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
	electionCloseness  +
              PartySize + 
	electionCloseness:governingParty+
              	experienceMax:governingParty +
	experienceMax:electionCloseness + 
	position:governingParty +         
	position:electionCloseness +
	factor(country)+factor(electionTime),
        #         data=Data)
	data=Data[-c(365,380,422,450),])
AIC(model4Fixed)
robust <- coeftest(model4Fixed, vcov = vcovHAC)
robust

##############
outlierTest(model4Fixed)

######
pdf(file="Outliers.pdf")
par(mfrow=c(2,2))
plot(model4Fixed)
dev.off()

Model4Fixed <- ModelResults(model4Fixed$coefficients[c(seq(1,13),seq(44,48))],robust[c(seq(1,13),seq(44,48)),2],number=6)
Model1 <- ModelResults(fixef(model1),se.fixef(model1),number=1)

Sigma<- sigma.hat(model1)
sigma <-rbind(Sigma$sigma$country[1],Sigma$sigma$country[2],Sigma$cors$country[1,2],Sigma$sigma$electionTime,Sigma$sigma$data)
rownames(sigma) <- c("intercept country","slope experience","correlation intercept - slope","intercept election","residual")
sigma

Model2 <- ModelResults(fixef(model2),se.fixef(model2),number=2)
Model3 <- ModelResults(fixef(model3),se.fixef(model3),number=3)
Model4 <- ModelResults(fixef(model4),se.fixef(model4),number=4)
Model5 <- ModelResults(fixef(model4a),se.fixef(model4a),number=5)
ResultsEffects <- merge(Model1,Model2,all=TRUE,by="row.names")
ResultsEffects <- merge(ResultsEffects,Model3,all=TRUE,by.x="Row.names",by.y="row.names")
ResultsEffects <- merge(ResultsEffects,Model4,all=TRUE,by.x="Row.names",by.y="row.names")
ResultsEffects <- merge(ResultsEffects,Model5,all=TRUE,by.x="Row.names",by.y="row.names")
ResultsEffects <- merge(ResultsEffects,Model4Fixed,all=TRUE,by.x="Row.names",by.y="row.names")

library(xtable)
captionText <- "The table presents the coefficients for the hierarchical model as
well as an model with country and year fixed effects (not
shown) and heteroskedastic and auto-correlation consistent standard errors."
results <- xtable(ResultsEffects,digits=3,align="llllllll")
print(results,file="ResTab.tex",include.rownames=FALSE)

##############
##############
ran <- ranef(model4)
ranSE <- se.ranef(model4)
## random intercepts
maxim <- dim(ran$country)[1]
ranIntersept <- matrix(ncol=maxim,nrow=10000)
for (i in 1:maxim){
ranIntersept[,i] <- rnorm(10000,ran$country[i,1],ranSE$country[i,1])
}
colnames(ranIntersept) <- row.names(ran$country)
summary(ranIntersept)
# random slope Experience
ranExperience <- matrix(ncol=maxim,nrow=10000)
for (i in 1:maxim){
ranExperience[,i] <- rnorm(10000,ran$country[i,2],ranSE$country[i,2])
}
colnames(ranExperience) <- row.names(ran$country)
summary(ranExperience)
#random slope prestige
ranPrestige<- matrix(ncol=maxim,nrow=10000)
for (i in 1:maxim){
ranPrestige[,i] <- rnorm(10000,ran$country[i,3],ranSE$country[i,3])
}
colnames(ranPrestige) <- row.names(ran$country)
summary(ranPrestige)
#random slope government
ranGovernment <- matrix(ncol=maxim,nrow=10000)
for (i in 1:maxim){
ranGovernment[,i] <- rnorm(10000,ran$country[i,4],ranSE$country[i,4])
}
colnames(ranGovernment) <- row.names(ran$country)
summary(ranGovernment)
#random slope proximity
ranProximity <- matrix(ncol=maxim,nrow=10000)
for (i in 1:maxim){
ranProximity[,i] <- rnorm(10000,ran$country[i,5],ranSE$country[i,5])
}
colnames(ranProximity) <- row.names(ran$country)
summary(ranProximity)
# random years
years <- dim(ran$electionTime)[1]
ranYears <- matrix(ncol=years,nrow=10000)
for (i in 1:years){
ranYears[,i] <- rnorm(10000,ran$electionTime[i,1],ranSE$electionTime[i,1])
}
colnames(ranYears) <- row.names(ran$electionTime)
summary(ranYears)
########################
postEffects <- sim(model4,n=10000)