Data <- read.csv2("ElectionData.csv",header=T) # Made with PrepareElectionsEP.R
names(Data)
summary(Data)
Data$Soc
# Add election system information
ElectionSystemIndex <- read.csv2("ElectionSystemIndex.csv",header=F)
colnames(ElectionSystemIndex) <- c("country","y1979","y1984","y1989","y1994","y1999","y2004")
ElectionSystemDummy <- read.csv2("ElectionSystemDummy.csv",header=F)
colnames(ElectionSystemDummy) <- c("country","y1979","y1984","y1989","y1994","y1999","y2004")
ElectionSystemIndex

countries <- factor(ElectionSystemIndex$country)
Data$systemIndex <- NA
for(j in 1:25){
for (i in 1:6){
cond <- Data$country==countries[j] & Data$electionTime==i
Data$systemIndex <- ifelse(cond,ElectionSystemIndex[ElectionSystemIndex$country==countries[j],i+1],Data$systemIndex)
}
}
Data$systemIndex

Data$systemDummy <- NA
for(j in 1:25){
for (i in 1:6){
cond <- Data$country==countries[j] & Data$electionTime==i
Data$systemDummy <- ifelse(cond,ElectionSystemDummy[ElectionSystemIndex$country==countries[j],i+1],Data$systemDummy)
}
}
mean(Data$experienceMax)
summary(Data)
mean(Data$experienceMax[Data$systemDummy==1])

cor(Data$experienceMax,Data$experienceMean)
cor(Data$experienceMax,Data$voteshareEP)

year <- c(1979,1984,1989,1994,1999,2004)

t.test(Data$experienceMax[Data$systemDummy==1],
Data$experienceMax[Data$systemDummy==0])

mean(Data$experienceMax[Data$governingParty==1])
mean(Data$experienceMax[Data$governingParty==0])
t.test(Data$experienceMax[Data$governingParty==1],
Data$experienceMax[Data$governingParty==0])

write.csv(Data,"HoboltHoyland_BJPSdata.csv")