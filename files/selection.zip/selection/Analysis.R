library(arm);library(car);library(sandwich);library(lmtest)
Data <- read.csv("HoboltHoyland_BJPSdata.csv")
mean(Data$experienceMax)
summary(Data)
mean(Data$experienceMax[Data$systemDummy==1])

cor(Data$experienceMax,Data$experienceMean)
cor(Data$experienceMax,Data$voteshareEP)

year <- c(1979,1984,1989,1994,1999,2004)

t.test(Data$experienceMax[Data$systemDummy==1],
Data$experienceMax[Data$systemDummy==0])

mean(Data$experienceMax[Data$governingParty==1])
mean(Data$experienceMax[Data$governingParty==0])
t.test(Data$experienceMax[Data$governingParty==1],
Data$experienceMax[Data$governingParty==0])

# Run the analysis
model0 <- lmer(voteshareEP ~ 1 +	
	(1|country)+(1|electionTime),
	data=Data,REML=FALSE)
model0


model5<- lmer(voteshareEP ~  experienceMax + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
	electionCloseness  +
              PartySize +
	electionCloseness:governingParty+
	experienceMax:governingParty +
	experienceMax:electionCloseness + systemDummy + experienceMax:systemDummy +
              (1|electionTime)+
	(experienceMax|country),
	data=Data,REML=FALSE)
model5

model3Fixed<- lm(voteshareEP ~ -1+experienceMax + 
	governingParty + Green + Anti + Cdem + Con + Left +Lib + Reg + Right +
                 PartySize + 
	electionCloseness  + 
	electionCloseness:governingParty+
	experienceMax:governingParty +
	experienceMax:electionCloseness + systemDummy + experienceMax:systemDummy +
	factor(country)+factor(electionTime),
	data=Data)
summary(model3Fixed)
robust <- coeftest(model3Fixed, vcov = vcovHAC)
robust
####
postEffects<- sim(model5,n.sims=10000)

ran <- ranef(model5)
ranSE <- se.ranef(model5)
## random intercepts
maxim <- dim(ran$country)[1]
ranIntersept <- matrix(ncol=maxim,nrow=10000)
for (i in 1:maxim){
ranIntersept[,i] <- rnorm(10000,ran$country[i,1],ranSE$country[i,1])
}
colnames(ranIntersept) <- row.names(ran$country)
summary(ranIntersept)
# random slopes
ranExperience <- matrix(ncol=maxim,nrow=10000)
for (i in 1:maxim){
ranExperience[,i] <- rnorm(10000,ran$country[i,2],ranSE$country[i,2])
}
colnames(ranExperience) <- row.names(ran$country)
summary(ranExperience)
# random years
years <- dim(ran$electionTime)[1]
ranYears <- matrix(ncol=years,nrow=10000)
for (i in 1:years){
ranYears[,i] <- rnorm(10000,ran$electionTime[i,1],ranSE$electionTime[i,1])
}
colnames(ranYears) <- row.names(ran$electionTime)
summary(ranYears)
summary(fixef(postEffects))
