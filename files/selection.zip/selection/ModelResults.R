##########################
# This function creates  #
# \beta (se.error) table #
##########################
ModelResults <- function(coefficients=coefficients,stErrors=stErrors,
                          digits=3,row.names=names(coefficients),number=1){
  star <- c(ifelse(abs(coefficients/stErrors) > 1.645,"+  ","   "))
  star <- c(ifelse(abs(coefficients/stErrors) > 1.96,"*  ",star))
    star <- c(ifelse(abs(coefficients/stErrors) > 2.326,"** ",star))
    star <- c(ifelse(abs(coefficients/stErrors) > 2.576,"***",star))
    coef <-round(coefficients,digits)
    stE <- round(stErrors,digits)
  stErr <- paste(stE,star,sep=")")
   Results <-data.frame(paste(coef,stErr,sep=" ("),row.names=row.names)
   names(Results) <- paste("model",number)
   return(Results)
 }
