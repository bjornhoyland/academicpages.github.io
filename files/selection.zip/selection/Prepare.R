rm(list = ls())
library(car);library(arm)
options(digits=5)
Meps<-read.csv2("BJPSdata.csv") #load data
Meps<-Meps[do.call(order,list(Meps$ep)),]
names(Meps)
##########################
## Make and plot index  ##  
##########################
Meps$QualityAdd <- ifelse(Meps$MP>0,1,0)
Meps$QualityAdd <- ifelse(Meps$minister>0,2+ Meps$QualityAdd,Meps$QualityAdd)
Meps$QualityAdd <- ifelse(Meps$leader>0,3+ Meps$QualityAdd,Meps$QualityAdd)
Meps$QualityAdd <- ifelse(Meps$pm>0,4+ Meps$QualityAdd,Meps$QualityAdd)

Meps$QualityAdd<- ifelse(Meps$double==0,Meps$QualityAdd,0) # Takes out double mandates

CountryMean<-data.frame(aggregate(Meps$QualityAdd,
by=list(Meps$country.x,Meps$year),FUN=mean))
CountryMax<-data.frame(aggregate(Meps$QualityAdd,
by=list(Meps$country.x,Meps$year),FUN=max))
CountryMin<-data.frame(aggregate(Meps$QualityAdd,
by=list(Meps$country.x,Meps$year),FUN=min))
names(CountryMean)<-c('Country','Year','Quality')
names(CountryMax)<-c('Country','Year','Max')
names(CountryMin)<-c('Country','Year','Min')
CountryMean<-merge(CountryMean,CountryMax,
by=c('Country','Year'))
CountryMean<-merge(CountryMean,CountryMin,by=c('Country','Year'))
CountryTurnoutEP <- data.frame(aggregate(Meps$turn.ep, 
by=list(Meps$country.y,Meps$year),FUN=mean))
CountryTurnoutNat <- data.frame(aggregate(Meps$turn.ge, 
by=list(Meps$country.y,Meps$year),FUN=mean))
CountryDiff <- CountryTurnoutNat$x -CountryTurnoutEP$x 
plot(CountryDiff,CountryMax$x)
#################################
## Prepare data for party level #
#################################
levels(Meps$family)

Meps$anti <- ifelse(Meps$family=='ANTI',1,0)
Meps$cdem <- ifelse(Meps$family=='CDEM',1,0)
Meps$con <- ifelse(Meps$family=='CON',1,0)
Meps$green <- ifelse(Meps$family=='GRN',1,0)
Meps$left <- ifelse(Meps$family=='LEFT',1,0)
Meps$lib <- ifelse(Meps$family=='LIB',1,0)
Meps$reg <- ifelse(Meps$family=='REG',1,0)
Meps$right <- ifelse(Meps$family=='RIGHT',1,0)
Meps$soc <- ifelse(Meps$family=='SOC',1,0)

Meps$position <- ifelse(Meps$position>0,1,0)

PartyMean<-data.frame(aggregate(Meps$QualityAdd,
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
PartyMedian<-data.frame(aggregate(Meps$QualityAdd,
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
PartyMax<-data.frame(aggregate(Meps$QualityAdd,
by=list(Meps$party,Meps$country.y,Meps$year),FUN=max))
PartyPosition<-data.frame(aggregate(Meps$position,
by=list(Meps$party,Meps$country.y,Meps$year),FUN=max))

OutcomeParty<-data.frame(aggregate(Meps$vep, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
govParty<-data.frame(aggregate(Meps$gov, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
monthsPrevParty<-data.frame(aggregate(Meps$mth.prev, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
monthsnextParty<-data.frame(aggregate(Meps$mth.fol, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
GreenParty<-data.frame(aggregate(Meps$green, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
AntiParty<-data.frame(aggregate(Meps$anti, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
CdemParty<-data.frame(aggregate(Meps$cdem, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
ConParty<-data.frame(aggregate(Meps$con, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
LeftParty<-data.frame(aggregate(Meps$left, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
LibParty<-data.frame(aggregate(Meps$lib, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
RegParty<-data.frame(aggregate(Meps$reg, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
RightParty<-data.frame(aggregate(Meps$right, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))
SocParty<-data.frame(aggregate(Meps$soc, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=median))


EUPosParty<-data.frame(aggregate(Meps$eu.pos, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
SizeParty<-data.frame(aggregate(Meps$vge.prev, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
candCenterParty<-data.frame(aggregate(Meps$c.cent.es, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
thresholdParty<-data.frame(aggregate(Meps$eff.thre, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
VolatilityParty<-data.frame(aggregate(Meps$el.vol, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
FirstParty<-data.frame(aggregate(Meps$ep.first, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
Outcome<-data.frame(aggregate(Meps$vep, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
lr.extr<-data.frame(aggregate(Meps$lr.extr, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
left.right<-data.frame(aggregate(Meps$left.right, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))

turnoutEP<-data.frame(aggregate(Meps$turn.ep, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
turnoutNat<-data.frame(aggregate(Meps$turn.ge, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
unemploy<-data.frame(aggregate(Meps$unemp, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
gdpchange<-data.frame(aggregate(Meps$gdp, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))
pubeu<-data.frame(aggregate(Meps$pub.eu, 
by=list(Meps$party,Meps$country.y,Meps$year),FUN=mean))

Party<-data.frame(PartyMean$Group.3,PartyMean$x,PartyMax$x,PartyMedian$x,PartyPosition$x,
OutcomeParty$x,govParty$x,monthsPrevParty$x,monthsnextParty$x,
GreenParty$x,AntiParty$x,CdemParty$x,ConParty$x,LeftParty$x,LibParty$x,RegParty$x,
                  RightParty$x,SocParty$x,
                  EUPosParty$x,SizeParty$x,lr.extr$x,
VolatilityParty$x,candCenterParty$x,left.right$x,
thresholdParty$x,FirstParty$x,Outcome$Group.2,turnoutEP$x,unemploy$x,
gdpchange$x,pubeu$x,turnoutNat$x)
#######################
Party$time<-as.numeric(recode(Party$PartyMean.Group.3,"'1979'='1';
'1984'='2';'1989'='3';'1994'='4';'1999'='5';'2004'='6'"))
Party$ElectionDistance<-
abs(Party$monthsPrevParty.x-Party$monthsnextParty.x)/
max(Party$monthsPrevParty.x,Party$monthsnextParty.x)

#############
#############
CountryMean<-tapply(Party$PartyMax.x,Party$Outcome.Group.2,FUN=mean,na.rm=TRUE)
CountrySD<-tapply(Party$PartyMax.x,Party$Outcome.Group.2,FUN=sd,na.rm=TRUE)
CountryMin<-tapply(Party$PartyMax.x,Party$Outcome.Group.2,FUN=min,na.rm=TRUE)
CountryMax<-tapply(Party$PartyMax.x,Party$Outcome.Group.2,FUN=max,na.rm=TRUE)
CountryQuan<-array(tapply(Party$PartyMax.x,Party$Outcome.Group.2,FUN=quantile,na.rm=TRUE))
CountryQuans <- rbind(CountryQuan[[1]],
                      CountryQuan[[2]],
                      CountryQuan[[3]],
                      CountryQuan[[4]],
                      CountryQuan[[5]],
                      CountryQuan[[6]],
                      CountryQuan[[7]],
                      CountryQuan[[8]],
                      CountryQuan[[9]],
                      CountryQuan[[10]],
                      CountryQuan[[11]],
                      CountryQuan[[12]],
                      CountryQuan[[13]],
                      CountryQuan[[14]],
                      CountryQuan[[15]],
                      CountryQuan[[16]],
                      CountryQuan[[17]],
                      CountryQuan[[18]],
                      CountryQuan[[19]],
                      CountryQuan[[20]],
                      CountryQuan[[21]],
                      CountryQuan[[22]],
                      CountryQuan[[23]],
                      CountryQuan[[24]],
                      CountryQuan[[25]])
CountryQuans

Countries<-cbind(CountryMean,CountrySD,CountryMin,CountryMax,CountryQuans)
Countrysort <- Countries[order(-CountryMean),]
Countrysort
rownames(Countrysort)[16] <- "UNITED KINGDOM"
rownames(Countrysort)[12] <- "CZECH REPUBLIC"
write.csv(Countrysort,"Countrydata.csv")
index<-25:1
pdf(file="TopCandidateExperience.pdf")
par(mfrow=c(1,1))
plot(Countrysort[,1],index,type="p",xlim=c(-3.9,11),bty="n",yaxt="n",ylab="",
xlab="",col=1,pch=16,main="",ylim=c(0,27))
for (i in 1:25){
segments(x0=Countrysort[i,3],
y0=index[i],x1=Countrysort[i,4],y1=index[i],lwd=1)
segments(x0=Countrysort[i,6],
y0=index[i],x1=Countrysort[i,8],y1=index[i],lwd=3)
text(-2.5,index[i],labels = rownames(Countrysort)[i]
,cex=.7)} 
    legend(1.5,2, legend=c("Mean of top candidate within each party across elections")
    ,pch=16,col=1,bty="n",cex=.7)
 legend(.5,1.25, 
    legend=c("Inter-quantile range of political experience of top candidate")
         ,lwd=3,col=1,bty="n",cex=.7)
    legend(.5,.5, 
    legend=c("Min to Max political experience of top candidate in each party")
    ,lwd=1,col=1,bty="n",cex=.7)
dev.off()

################
################
summary(Party)
names(Party) <- c("electionYear","experienceMean","experienceMax",
"experienceMedian","position","voteshareEP","governingParty","monthsSinceElections",
"monthsToElections","Green","Anti","Cdem","Con","Left","Lib","Reg","Right","Soc",
                  "PositionEU","PartySize","leftRightExtreme",
"volatility","candidateCentered","leftRight","electionThreshold","firstEPelect",
"country","turnoutEP","unemployment","gdpchange","publicSupportEU",
"turnoutNatElect","electionTime","electionCloseness")
write.csv2(Party,"ElectionData.csv",row.names = FALSE)
