#######################################################
# Replication material: Hobolt & Hoyland (2011)       #
# Selection in European Parliamentary Elections       #
# British Journal of Political Science, 41(3): 477:98 #
#######################################################
source("Prepare.R")
source("Background.R")
source("Analysis.R")
source("ExperienceEffectsPlot.R")
source("Robustness.R")
source("Timing.R")
