#################################
## Figure of the average effect #
## of experience for governing  #
## and opposition parties       #
#################################
ruler <- seq(0.001,10,length=10000)
values <- fixef(postEffects)[,2]

length(ruler)
length(values)
out <- data.frame()
for (i in 1:length(ruler)){
test <- quantile(values*ruler[i]+fixef(postEffects)[,1]+
                 fixef(postEffects)[,13]*mean(Data$PartySize[Data$governingParty==0]),probs=c(0.025,.5,.975))
out <- rbind(out,test)
}
dim(out)
out[1:10,]


alpha.bar <- out[,2]
alpha.ci <- rbind(out[,1],out[,3]) #95 % central tendency
dseq <- ruler
pdf(file="EffectExperience.pdf",height=8, width=14)
par(mfrow=c(1,2))
plot(dseq,alpha.bar,
     type="n",
     axes=T,
     xlab="Experience",
     ylab="Change in vote share",
     xlim=c(0,10),
     ylim=c(-9,9),
     main="Opposition",
     yaxs="i",
     xaxs="i")

polygon(x=c(dseq,rev(dseq)),
        y=c(alpha.ci[1,],rev(alpha.ci[2,])),
        border=F,
        col=gray(.75))
lines(dseq,alpha.bar,lwd=3)
abline(h=0,lty=1,lwd=1)

values <- fixef(postEffects)[,2]+fixef(postEffects)[,16]

length(ruler)
length(values)
out <- data.frame()
for (i in 1:length(ruler)){
test <- quantile(values*ruler[i]+fixef(postEffects)[,1]+fixef(postEffects)[,3]+
                 fixef(postEffects)[,13]*mean(Data$PartySize[Data$governingParty==1])
                 ,probs=c(0.025,.5,.975))
out <- rbind(out,test)
}
dim(out)
out[1:10,]


alpha.bar <- out[,2]
alpha.ci <- rbind(out[,1],out[,3]) #95 % central tendency
dseq <- ruler
plot(dseq,alpha.bar,
     type="n",
     axes=T,
     xlab="Experience",
     ylab="Change in vote share",
     xlim=c(0,10),
     ylim=c(-9,9),
     main="Government",
     yaxs="i",
     xaxs="i")

polygon(x=c(dseq,rev(dseq)),
        y=c(alpha.ci[1,],rev(alpha.ci[2,])),
        border=F,
        col=gray(.75))
lines(dseq,alpha.bar,lwd=3)
abline(h=0,lty=1,lwd=1)
dev.off()
  
