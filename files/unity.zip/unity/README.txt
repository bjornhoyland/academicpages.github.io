##################
# Replication material:
# Unity in Diversity? The Development of Political Parties in the Parliament of Canada (1867 - 2011).
# Jean-François Godbout and Bjørn Høyland
# British Journal of Political Science
#######################################

The analysis was done with R (v. 3.1.3, 2015).
The main code for the replication material is in the "replication_master.r" file. 

