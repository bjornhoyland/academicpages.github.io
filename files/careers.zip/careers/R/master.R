# list of r-scripts to run in order to replicate the results
list.of.packages <- c("runjags","coda","xtable")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

# Posteriors for Table 4 and Table 6
mainMCMC.R # main analysis: votes and debates
measureMCMC.R # daily participation analysis: votes and debates
elsysMCMC.R # analysis with electoral-system * career ambitions dymmies

# Posterior for Table 9
survMCMC.R # survey analysis: votes and debates


# Robustness
RobustLegis.R # Legislative votes only
RobustClose.R # Close votes only
natpartyMCMC.R # National party random effects: Votes and debates

# Tables and Figures
TablesFigs.R # Makes all tables and figures
