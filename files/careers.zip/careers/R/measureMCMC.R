rm(list=ls())
load("../Data/revealed.RData")
set.seed(873209)
adapt <- 1e4
burn <- 25e4
samp <- 1e4
thin <- 25
chains <- 3
group.counter <- unique(allmeps$party)
group <- rep(NA,nrow(allmeps))
for (i in 1:length(group.counter)){
  group<- ifelse(allmeps$party==group.counter[i],i,group)
}
n.groups <- length(levels(as.factor(allmeps$party)))

nat.counter <- unique(allmeps$state)
nat <- rep(NA,nrow(allmeps))
for (i in 1:length(nat.counter)){
  nat<- ifelse(allmeps$state==nat.counter[i],i,nat)
}
n.nat <- length(levels(as.factor(allmeps$state)))

year <- allmeps$ep -3
n.year <- length(unique(year))

chains <- 3

allmeps$nationalopen <- ifelse(is.na(allmeps$nationalopen),0,allmeps$nationalopen)
allmeps$nationalclosed <- ifelse(is.na(allmeps$nationalclosed),0,allmeps$nationalclosed)
allmeps$euopen <- ifelse(is.na(allmeps$euopen),0,allmeps$euopen)
allmeps$natback <- ifelse(is.na(allmeps$natback),0,allmeps$natback)
allmeps$other <- ifelse(is.na(allmeps$other),0,allmeps$other)
allmeps$epback <- ifelse(is.na(allmeps$epback),0,allmeps$epback)
allmeps$groupRole <- ifelse(is.na(allmeps$groupRole),0,allmeps$groupRole)
allmeps$committeeRole <- ifelse(is.na(allmeps$committeeRole),0,allmeps$committeeRole)

X <- with(allmeps,cbind(nationalopen,nationalclosed,euopen,epback,natback,other,age,groupRole,committeeRole))
n.betas <- ncol(X)
Jagsdata <- list(r=allmeps$days,n=allmeps$totaldays,n.obs=nrow(allmeps),
                 X=X,group=group,n.groups=n.groups,n.nat=n.nat,nat=nat,
                 year=year,n.year=n.year,n.betas=n.betas,
                 b0=rep(0,n.betas),B0=diag(.001,n.betas))


initsfunction <- function(chain) return(switch(chain,
                                               "1"=list(deltaTmp=rnorm(n.groups,0,2),gammaTmp=rnorm(n.nat,1,2),beta=rnorm(n.betas,0,3),
                                                        nuTmp=rnorm(n.year),
                                                        .RNG.name="base::Super-Duper",.RNG.seed=2), 
                                               "2"=list(deltaTmp=rnorm(n.groups,-1,3),gammaTmp=rnorm(n.nat,-2,3),beta=rnorm(n.betas,-1,2),
                                                        nuTmp=rnorm(n.year),
                                                        .RNG.name="base::Wichmann-Hill",.RNG.seed=2),
                                               "3"=list(deltaTmp=rnorm(n.groups,1,2),gammaTmp=rnorm(n.nat,0,3),beta=rnorm(n.betas,1,1.5),
                                                        nuTmp=rnorm(n.year),
                                                        .RNG.name="base::Mersenne-Twister",.RNG.seed=2)))

foo <- run.jags(model="../jags/binomialhier.jags",
                data=Jagsdata,inits=initsfunction,modules="glm",
                adapt=adapt,burnin=burn,sample=samp,
                n.chains=chains,method='parallel',thin=thin,#summarise=FALSE,plots=FALSE,
                monitor=c("beta","gamma","deviance","delta","nu"))

save(foo,file="../Posteriors/ResultsVotesDays.RData")
# Debates $ only for EP5 - EP7
debmeps <- subset(allmeps,subset=allmeps$ep>4) 
group <- rep(NA,nrow(debmeps))
for (i in 1:length(group.counter)){
  group<- ifelse(debmeps$party==group.counter[i],i,group)
}
n.groups <- length(levels(as.factor(debmeps$party)))

nat.counter <- unique(debmeps$state)
nat <- rep(NA,nrow(debmeps))
for (i in 1:length(nat.counter)){
  nat<- ifelse(debmeps$state==nat.counter[i],i,nat)
}
n.nat <- length(levels(as.factor(debmeps$state)))

year <- debmeps$ep -4
n.year <- length(unique(year))

X <- with(debmeps,cbind(nationalopen,nationalclosed,euopen,epback,natback,other,age,groupRole,committeeRole))
n.betas <- ncol(X)
Jagsdata <- list(r=debmeps$speechesAll,n=debmeps$debatesAll,n.obs=nrow(debmeps),
                 X=X,group=group,n.groups=n.groups,n.nat=n.nat,nat=nat,
                 year=year,n.year=n.year,n.betas=n.betas,
                 b0=rep(0,n.betas),B0=diag(.001,n.betas))

fooDebates <- run.jags(model="../jags/binomialhier.jags",
                       data=Jagsdata,inits=initsfunction,modules="glm",
                       adapt=adapt,burnin=burn,sample=samp,
                       n.chains=chains,method='parallel',thin=thin,#summarise=FALSE,plots=FALSE,
                       monitor=c("beta","gamma","deviance","delta","nu"))
save(fooDebates,file="../Posteriors/ResultsDebatesAll.RData")