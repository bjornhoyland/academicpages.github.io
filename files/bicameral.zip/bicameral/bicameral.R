# Replication material    #
# Hagemann & Høyland 2010 #
# Bicamleral Politics     #
###########################
# theoretical figure
library(plotrix)
plot(1:5,seq(1,10,length=5), type="n", xlab="Left-Right",ylab="Institutional Interest",
     main="Effect of shifting majority requirements in the Parliament",xaxt="n",yaxt="n",bty="n")
draw.circle(3,4,.8,border="black",lty=1,lwd=4)
draw.circle(4,6,.8,border="gray",lty=2,lwd=3)
draw.circle(4,6,.6,border="gray",lty=1,lwd=4)
draw.circle(4,6,.95,border="gray",lty=3,lwd=2)
text(3,4, "Council")
text(4,6,"Parliament")
text(4,8.8,"Absolute, low abstention")
text(4,9.3,"Absolute, high abstention")
text(4,8.2,"Absolute, no abstention")
text(4,4.2,"Simple")


#####################
library("pscl")
# Council 1d IRTM #
Council <- read.csv2("CouncilVotes.csv")
names(Council)<-c('PES Germany SPD / Grönen','PES France PS PCF RPF Verts','EPP France UMP UDF Ind',
                  'PES UK Labour','PES Italy DS MARG UDR PDCI','EPP Italy FI AN LN CCD/CDC Ind','EPP Spain PP',
                  'PES Netherlands PvdA VVD D66','EPP Netherlands CDV VVD LPF','PES Greece PASOK',
                  'PES/EPP Belgium CVP (CD & V) PSC SP PS)','ELDR Belgium VLD MR SP PS Ecolo Agalev',
                  'PES Portugal PS','EPP Portugal PSD CDS/PP','PES Sweden SAP','EPP Austria SPÖ ÖVP',
                  'EPP Austria ÖVP FPÖ','PES Denmark SD RV','ELDR Denmark V KF','ELDR Finland SDP KOK SFP VAS VIHR',
                  'ELDR Finland KESP SDP SFP','UEN Ireland FF PD','EPP Luxembourg CSV PDL','EPP Luxembourg CSV LSAP')
council<-rollcall(t(Council),yea=1,nay=0,notInLegis=c(9,"NA"),
                  legis.names=names(Council),
                  desc="Council Coalitions")

d1 <- ideal(council, normalize=TRUE, verbose=TRUE, 
            maxiter=11e5, burnin=1e5, thin=1e3)
summary(d1)

plot(d1,showAllNames=TRUE)

## EP roll call requests
# load and divide by concflict in Council
library(car)
VoteInfo <- read.csv2("VoteInfo.csv", row.names = 1)
VoteInfo$RCV <- recode(VoteInfo$RCVSponsor," 'EPP'='EPP';'PES'='PES';else= 'Other' ")
VoteInfo$Passed <- factor(recode(VoteInfo$Yes," 0:313='failed';314:700='passed'"))
prop.table(table(VoteInfo$Passed))
prop.table(table(VoteInfo$Passed[VoteInfo$Negative=="Consensus"]))
prop.table(table(VoteInfo$Passed[VoteInfo$Negative=="NegVotes"]))
# in the original paper, this model is estimated with the arm package lmer and mcmcsamp for uncertainty
# mcmcsamp is redrawn by lme4, the bayesian version is here estimated with rstanarm
library(lme4)
rcr <- glmer(Passed~RCV*Negative+(1|Legno),data=VoteInfo, family=binomial(link="probit"))
summary(rcr)
library(rstanarm)
options(mc.cores = parallel::detectCores())
rcr.bayes <- stan_glmer(Passed~RCV*Negative+(1|Legno),data=VoteInfo, 
                        prior = student_t(df = 7), 
                        prior_intercept = student_t(df = 7),
                        family=binomial(link="probit"))
summary(rcr.bayes)

###########
# Estimating how MEP votes by Council consensus
MEPdata <- read.csv2("MEPData.csv", row.names = 1)
EPvotes <- read.csv2("EPVotes.csv", row.names = 1)
EP <- rollcall(EPvotes, legis.names = row.names(EPvotes),
               legis.data = MEPdata, vote.data = VoteInfo,
               desc = "2nd reading codecision amendments",
               source = "Hix, Noury & Roland 2006")

conflict<-dropRollCall(EP, dropList=alist(dropVotes=Opposition!="Opposing"))
conflict$desc<-"Non-unanimous Common Position"
ideal_conflict <- ideal(conflict, d=2, verbose = TRUE, store.item = TRUE,
                        maxiter = 1e6, burnin = 1e5, thin = 1e3)

uni<-dropRollCall(EP, dropList=alist(dropVotes=Opposition!="Consensus"))
uni$desc<-"Unanimous Common Position"
ideal_uni <- ideal(uni, d=2, verbose = TRUE,store.item = TRUE,
                   maxiter = 1e6, burnin = 1e5, thin = 1e3)
uni2dpost <- postProcess(ideal_uni, constraints=list("MEIJER Erik NL_SP"=c(2,0),"VANHECKE Frank BE_VB"=c(0,-1),
                                                   "VARELA SUANZES-CARPEGNA Daniel ES_PP"=c(-1,2)))
par(mfrow=c(2,1))
plot(ideal_conflict, overlayCuttingPlanes=TRUE)
plot(uni2dpost, overlayCuttingPlanes=TRUE)

