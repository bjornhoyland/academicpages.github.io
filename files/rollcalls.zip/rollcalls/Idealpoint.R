#################
# Revision EUP  #
#################
set.seed(3141593)
rm(list=ls())
allVotes <- read.csv("Data/rcv_ep5.txt",header=TRUE)
dim(allVotes)
allVotes[1:10,1:10]
Votes <- allVotes[,6:dim(allVotes)[2]]
dim(Votes)
info <- read.delim("Data/VoteInfoEP5.txt",header=TRUE)
dim(info)
names(info)
info[1:10,] 
res <- Votes[,info$Procedure=="RES"]
info[1:10,]
sampleVotes <- sample(1:dim(res)[2],450,replace=FALSE)
resSample <- res[,sampleVotes]
dim(resSample)
cod2 <- Votes[,info$Procedure=="COD" & info$Rule.SM.0..AM.1==1]
infoCod <- info[info$Procedure=="COD"& info$Rule.SM.0..AM.1==1,]
infoRes <- info[info$Procedure=="RES",]#,sampleVotes]
infoRes <- infoRes[sampleVotes,]
info <- rbind(infoRes,infoCod)
dim(cod2)
myVotes <- cbind(resSample,cod2)
recodes <- c(5,0,3,4)
for (i in 1:4){
myVotes[myVotes==recodes[i]] <- NA # Recode votes
}
myVotes[myVotes==2] <- 0
myVotes[1:10,1:10]

library(pscl)
legis.data <- allVotes[,1:5]
Legisnames <- allVotes[,2]
MyVotes <- rollcall(myVotes,legis.data=legis.data,vote.data=info,legis.names=Legisnames)
MyVotes <-  dropRollCall(MyVotes, dropList=list(lop = 25,legisMin=100))

summary(MyVotes)
names(MyVotes)
summary(MyVotes$vote.data)
summary(MyVotes$legis.data)
write.csv2(MyVotes$votes,file="Votes.csv")
write.csv2(MyVotes$legis.data,file="LegisData.csv")
# Hand-coded party group of rapporteur and directive number
MyVotes$vote.data <- read.csv2("Data/VoteDataFull.csv")
MyVotes$legis.data$EPG[MyVotes$legis.data$EPG=="N"] <- "A"
#############
names(MyVotes$legis.data) <- c('legno','name','state','natparty','party')
source("HixIndex.R")
# The output is party cohesion in each vote
ResHix <- HixIndex(MyVotes,votes=MyVotes$votes[,1:359])
summary(ResHix)
CodHix <- HixIndex(MyVotes,votes=MyVotes$votes[,360:713])
summary(CodHix)
pdf("CohesionScore.pdf",width=12)
par(mfrow=c(2,3))
plot(density(ResHix$E),ylim=c(0,4),main="Cohesion score EPP",
     xlab="Cohesion",bty="n",lwd=3)
lines(density(CodHix$E),col="grey",lwd=3)
legend(0,3,legend=c("resolutions","codecision"),col=c("black","grey"),lwd=3,lty=1,bty="n")
plot(density(ResHix$S),ylim=c(0,4),main="Cohesion score PES",
     xlab="Cohesion",bty="n",lwd=3)
lines(density(CodHix$S),col="grey",lwd=3)
legend(0,3,legend=c("resolutions","codecision"),col=c("black","grey"),lwd=3,lty=1,bty="n")
plot(density(ResHix$L),ylim=c(0,4),main="Cohesion score ELDR",
     xlab="Cohesion",bty="n",lwd=3)
lines(density(CodHix$L),col="grey",lwd=3)
legend(0,3,legend=c("resolutions","codecision"),col=c("black","grey"),lwd=3,lty=1,bty="n")
plot(density(ResHix$V),ylim=c(0,4),main="Cohesion score V/ALE",
     xlab="Cohesion",bty="n",lwd=3)
lines(density(CodHix$V),col="grey",lwd=3)
legend(0,3,legend=c("resolutions","codecision"),col=c("black","grey"),lwd=3,lty=1,bty="n")
plot(density(ResHix$M),ylim=c(0,4),main="Cohesion score GUE/NGL",
     xlab="Cohesion",bty="n",lwd=3)
lines(density(CodHix$M),col="grey",lwd=3)
legend(0,3,legend=c("resolutions","codecision"),col=c("black","grey"),lwd=3,lty=1,bty="n")
plot(density(ResHix$G),ylim=c(0,4),main="Cohesion score UEN",
     xlab="Cohesion",bty="n",lwd=3)
lines(density(CodHix$G),col="grey",lwd=3)
legend(0,3,legend=c("resolutions","codecision"),col=c("black","grey"),lwd=3,lty=1,bty="n")
dev.off()
###############
#Prepare a party-pressure model
# Pressure on cod2 votes
y <- c(MyVotes$votes,recursive=TRUE)
names(y) <- NULL
y <- array(y,dim=c(dim(MyVotes$votes)[1],dim(MyVotes$votes)[2]))

if(exists("foo"))
  rm(foo)
foo <- list()

foo$y <- y
foo$n <- dim(MyVotes$votes)[1]
foo$m <- dim(MyVotes$votes)[2]
foo$p <- 359
foo$E <- ifelse(MyVotes$legis.data$EPG=="E",1,0)
foo$S <- ifelse(MyVotes$legis.data$EPG=="S",1,0)
foo$L <- ifelse(MyVotes$legis.data$EPG=="L",1,0)
foo$V <- ifelse(MyVotes$legis.data$EPG=="V",1,0)
foo$A <- ifelse(MyVotes$legis.data$EPG=='A',1,0)
foo$G <- ifelse(MyVotes$legis.data$EPG=="G",1,0)

for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="pressuredata.R")   ## dump
##############
randomNumbers <- 3141593
RNGname <- "base::Wichmann-Hill"

k <- 1
for (j in 1:k){
if(exists("inits"))
  rm(inits)
inits <- list()
inits$alpha <- rnorm(foo$m,0)
inits$beta <- rnorm(foo$m,0)
inits$delta <- cbind(rep(0,foo$m),rep(0,foo$m),rep(0,foo$m),
                     rep(0,foo$m),rep(0,foo$m),rep(0,foo$m))
inits$delta[,1] <- rnorm(foo$m,0,1)
inits$delta[,2] <- rnorm(foo$m,0,1)
inits$delta[,3] <- rnorm(foo$m,0,1)
inits$delta[,4] <- rnorm(foo$m,0,1)
inits$delta[,5] <- rnorm(foo$m,0,1)
inits$delta[,6] <- rnorm(foo$m,0,1)
inits$theta <- ifelse(MyVotes$legis.data$EPG=="E" & MyVotes$legis.data$MS=="U",1,0)
inits$theta <- ifelse(MyVotes$legis.data$EPG=="M",-1,inits$theta)
inits$.RNG.name <- RNGname
inits$.RNG.seed <- randomNumbers


for(i in 1:length(inits))
  assign(x=names(inits)[i],
         value=inits[[i]])
filename <- paste("inits",j,sep="_")
filename <- paste(filename,"txt",sep=".")
dump(list=names(inits),file=filename)
}

rm(list=names(foo))     ## now clean-up
rm(list=names(inits))
############################
#Prepare a standard model  #
############################
y <- c(MyVotes$votes,recursive=TRUE)
names(y) <- NULL
y <- array(y,dim=c(dim(MyVotes$votes)[1],dim(MyVotes$votes)[2]))

if(exists("foo"))
  rm(foo)
foo <- list()

foo$y <- y
foo$n <- dim(MyVotes$votes)[1]
foo$m <- dim(MyVotes$votes)[2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="standarddata.R")   ## dump
##############
randomNumbers <- 3141593
RNGname <- "base::Wichmann-Hill"
k <- 1
for (j in 1:k){
if(exists("initsStandard"))
  rm(inits)
inits <- list()
inits$alpha <- rnorm(foo$m,0)
inits$beta <- rnorm(foo$m,0)
inits$theta <- ifelse(MyVotes$legis.data$EPG=="E" & MyVotes$legis.data$MS=="U",1,0)
inits$theta <- ifelse(MyVotes$legis.data$EPG=="M",-1,inits$theta)
inits$.RNG.name <- RNGname
inits$.RNG.seed <- randomNumbers


for(i in 1:length(inits))
  assign(x=names(inits)[i],
         value=inits[[i]])
filename <- paste("initsStandard",j,sep="_")
filename <- paste(filename,"txt",sep=".")
dump(list=names(inits),file=filename)
}

rm(list=names(foo))     ## now clean-up
rm(list=names(inits))


