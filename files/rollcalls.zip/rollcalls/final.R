####################
# Post analysis of #
# EP votes         #
####################
rm(list=ls())
library(coda)
# Standard model
results <- read.coda("JAGSoutput/StandardVeryLongchain1.txt","JAGSoutput/StandardVeryLongindex.txt")
legis.info <- read.csv2("LegisData.csv")
vote.info <- read.csv2("Data/VoteDataFull.csv")
###############
foo <- unclass(results)
alphaRes <- -1*foo[,1:359] 
alphaCod <- -1*foo[,360:713]
betaRes <- foo[,714:1072]
betaCod <- foo[,1073:1426]
theta <- foo[,1427:2085]
################
results2 <- read.coda("JAGSoutput/ProcedurePressureVeryLongchain1.txt","JAGSoutput/ProcedurePressureVeryLongindex.txt")
foo2 <- unclass(results2)
alphaRes2 <- -1*foo2[,1:359] 
alphaCod2 <- -1*foo2[,360:713]
betaRes2 <- foo2[,714:1072]
betaCod2 <- foo2[,1073:1426]
theta2 <- foo2[,1427:2085]
deltaEPP <- -1*foo2[,2445:2798]
deltaPES <- -1*foo2[,3158:3511]
deltaELDR <- -1*foo2[,3871:4224]
deltaGreen <- -1*foo2[,4584:4937]
deltaAnti <- -1*foo2[,5297:5650]
deltaGue <- -1*foo2[,6010:6363]
gamma <- foo2[,6364:7022]
Codtheta <- theta2 + gamma
Cod <- as.mcmc(Codtheta)
###########################
# 1 dimension, standard model
betaResSum <- data.frame(summary(as.mcmc(betaRes))[2])
RealBetaRes <- betaResSum[,1]>0 | betaResSum[,5]<0
summary(RealBetaRes)
##
betaCodSum <- data.frame(summary(as.mcmc(betaCod))[2])
RealBetaCod <- betaCodSum[,1]>0 | betaCodSum[,5]<0
summary(RealBetaCod)
# 1 dimension, pressure model
betaResSum2 <- data.frame(summary(as.mcmc(betaRes2))[2])
RealBetaRes2 <- betaResSum2[,1]>0 | betaResSum2[,5]<0
summary(RealBetaRes2)
##
betaCodSum2 <- data.frame(summary(as.mcmc(betaCod2))[2])
RealBetaCod2 <- betaCodSum2[,1]>0 | betaCodSum2[,5]<0
summary(RealBetaCod2)
###########################
# Convergence tests
# standard model
autheta <- autocorr.diag(as.mcmc(theta))
aubetaRes <- autocorr.diag(as.mcmc(betaRes))
aubetaCod <- autocorr.diag(as.mcmc(betaCod))
aualphaRes <- autocorr.diag(as.mcmc(alphaRes))
aualphaCod <- autocorr.diag(as.mcmc(alphaCod))

gwtheta <- geweke.diag(as.mcmc(theta))
gwbetaRes <- geweke.diag(as.mcmc(betaRes))
gwbetaCod <- geweke.diag(as.mcmc(betaCod))
gwalphaRes <- geweke.diag(as.mcmc(alphaRes))
gwalphaCod <- geweke.diag(as.mcmc(alphaCod))

hetheta <- heidel.diag(as.mcmc(theta))
hebetaRes <- heidel.diag(as.mcmc(betaRes))
hebetaCod <- heidel.diag(as.mcmc(betaCod))
healphaRes <- heidel.diag(as.mcmc(alphaRes))
healphaCod <- heidel.diag(as.mcmc(alphaCod))
##########
normal <- rnorm(5000)
pdf("GewekeStandard.pdf",width=10, height=3)
par(mfrow=c(1,5))
gwthe <- unclass(gwtheta)
plot(density(gwthe$z),lwd=2,main=expression(paste("Geweke test ", theta)),
xlab="z-value,
standard model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwBRes <- unclass(gwbetaRes)
plot(density(gwBRes$z),lwd=2,main=expression(paste("Geweke test ", beta, " resolutions")),
xlab="z-value,
standard model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
     
gwBCod <- unclass(gwbetaCod)
plot(density(gwBCod$z),lwd=2,main=expression(paste("Geweke test ", beta, " codecision")),
xlab="z-value,
standard model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)

gwARes <- unclass(gwalphaRes)
plot(density(gwARes$z),lwd=2,main=expression(paste("Geweke test ", alpha, " resolutions")),
xlab="z-value,
standard model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)

gwACod <- unclass(gwalphaCod)
plot(density(gwACod$z),lwd=2,main=expression(paste("Geweke test ", alpha, " resolutions")),
xlab="z-value,
standard model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
dev.off()
###########
## pressuremodel
autheta2 <- autocorr.diag(as.mcmc(Codtheta))
aubetaRes2 <- autocorr.diag(as.mcmc(betaRes2))
aubetaCod2 <- autocorr.diag(as.mcmc(betaCod2))
aualphaRes2 <- autocorr.diag(as.mcmc(alphaRes2))
aualphaCod2 <- autocorr.diag(as.mcmc(alphaCod2))
audEPP <- autocorr.diag(as.mcmc(deltaEPP))
audPES <- autocorr.diag(as.mcmc(deltaPES))
audELDR <- autocorr.diag(as.mcmc(deltaELDR))
audGreen <- autocorr.diag(as.mcmc(deltaGreen))                        
audAnti <- autocorr.diag(as.mcmc(deltaAnti))
audGUE <- autocorr.diag(as.mcmc(deltaGue)) 

gwtheta2 <- geweke.diag(as.mcmc(Codtheta))
gwbetaRes2 <- geweke.diag(as.mcmc(betaRes2))
gwbetaCod2 <- geweke.diag(as.mcmc(betaCod2))
gwalphaRes2 <- geweke.diag(as.mcmc(alphaRes2))
gwalphaCod2 <- geweke.diag(as.mcmc(alphaCod2))
gwdEPP <- geweke.diag(as.mcmc(deltaEPP))
gwdPES <- geweke.diag(as.mcmc(deltaPES))
gwdELDR <- geweke.diag(as.mcmc(deltaELDR))
gwdGreen <- geweke.diag(as.mcmc(deltaGreen))                        
gwdAnti <- geweke.diag(as.mcmc(deltaAnti))
gwdGUE <- geweke.diag(as.mcmc(deltaGue))

hetheta2 <- heidel.diag(as.mcmc(Codtheta))
hebetaRes2 <- heidel.diag(as.mcmc(betaRes2))
hebetaCod2 <- heidel.diag(as.mcmc(betaCod2))
healphaRes2 <- heidel.diag(as.mcmc(alphaRes2))
healphaCod2 <- heidel.diag(as.mcmc(alphaCod2))
hedEPP <- heidel.diag(as.mcmc(deltaEPP))
hedPES <- heidel.diag(as.mcmc(deltaPES))
hedELDR <- heidel.diag(as.mcmc(deltaELDR))
hedGreen <- heidel.diag(as.mcmc(deltaGreen))                        
hedAnti <- heidel.diag(as.mcmc(deltaAnti))
hedGUE <- heidel.diag(as.mcmc(deltaGue))

pdf("GewekePressure.pdf",width=10, height=6)
par(mfrow=c(2,5))
gwthe2 <- unclass(gwtheta2)
plot(density(gwthe2$z),lwd=2,main=expression(paste("Geweke test ", theta)),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwBRes2 <- unclass(gwbetaRes2)
plot(density(gwBRes2$z),lwd=2,main=expression(paste("Geweke test ", beta, " resolutions")),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwBCod2 <- unclass(gwbetaCod2)
plot(density(gwBCod2$z),lwd=2,main=expression(paste("Geweke test ", beta, " codecision")),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwARes2 <- unclass(gwalphaRes2)
plot(density(gwARes2$z),lwd=2,main=expression(paste("Geweke test ", alpha, " resolutions")),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwACod2 <- unclass(gwalphaCod2)
plot(density(gwACod$z),lwd=2,main=expression(paste("Geweke test ", alpha, " codecision")),
xlab="z-value, procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwdEPP <- unclass(gwdEPP)
plot(density(gwdEPP$z),lwd=2,main=expression(paste("Geweke test ", delta, " EPP")),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwdPES <- unclass(gwdPES)
plot(density(gwdPES$z),lwd=2,main=expression(paste("Geweke test ", delta, " PES")),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwdELDR <- unclass(gwdELDR)
plot(density(gwdELDR$z),lwd=2,main=expression(paste("Geweke test ", delta, " ELDR")),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwdGreen <- unclass(gwdGreen)
plot(density(gwdGreen$z),lwd=2,main=expression(paste("Geweke test ", delta, " V/ALE")),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
gwdGUE <- unclass(gwdGUE)
plot(density(gwdGUE$z),lwd=2,main=expression(paste("Geweke test ", delta, " UEN")),
xlab="z-value,
procedure and party model",ylab="density",bty="n",xlim=c(-4,4),ylim=c(0,.5))
lines(density(normal),col="grey",lty=1,lwd=3)
dev.off()
########
###########################
# evidence of procedural effects
RealGamma <- data.frame(summary(as.mcmc(gamma))[2])
ChangeGamma <- RealGamma[,1]>0 | RealGamma[,5]<0
TestGamma <- cbind(legis.info,ChangeGamma,RealGamma)
TestGamma[TestGamma$MS=="U"& TestGamma$EPG=="E",]
## UK
sumTestGamma <- table(TestGamma$EPG[TestGamma$MS=="U"],
                      TestGamma$ChangeGamma[TestGamma$MS=="U"])
pro <- sumTestGamma[,2]/(sumTestGamma[,1]+sumTestGamma[,2])
sumGammaUK <- cbind(sumTestGamma,round(pro,3))
sumGammaUK
## Germany
sumTestGamma <- table(TestGamma$EPG[TestGamma$MS=="D"],
                      TestGamma$ChangeGamma[TestGamma$MS=="D"])
pro <- sumTestGamma[,2]/(sumTestGamma[,1]+sumTestGamma[,2])
sumGammaD <- cbind(sumTestGamma,round(pro,3))
sumGammaD
## France
sumTestGamma <- table(TestGamma$EPG[TestGamma$MS=="F"],
                      TestGamma$ChangeGamma[TestGamma$MS=="F"])
pro <- sumTestGamma[,2]/(sumTestGamma[,1]+sumTestGamma[,2])
sumGammaF <- cbind(sumTestGamma,round(pro,3))
sumGammaF
## Italy
sumTestGamma <- table(TestGamma$EPG[TestGamma$MS=="I"],
                      TestGamma$ChangeGamma[TestGamma$MS=="I"])
pro <- sumTestGamma[,2]/(sumTestGamma[,1]+sumTestGamma[,2])
sumGammaI <- cbind(sumTestGamma,round(pro,3))
sumGammaI
## Spain
sumTestGamma <- table(TestGamma$EPG[TestGamma$MS=="E"],
                      TestGamma$ChangeGamma[TestGamma$MS=="E"])
pro <- sumTestGamma[,2]/(sumTestGamma[,1]+sumTestGamma[,2])
sumGammaE <- cbind(sumTestGamma,round(pro,3))
sumGammaE
######
TestGamma <- cbind(legis.info,ChangeGamma)
sumTestGamma <- table(TestGamma$EPG,TestGamma$ChangeGamma)
pro <- sumTestGamma[,2]/(sumTestGamma[,1]+sumTestGamma[,2])
sumGamma <- cbind(sumTestGamma,round(pro,3),sumGammaUK[,3],sumGammaD[,3],sumGammaF[,3]
                  ,sumGammaI[,3],sumGammaE[,3])
colnames(sumGamma) <- c("No change","Change","Proportion","UK","Germany","France","Italy","Spain")
library(xtable)
xtable(sumGamma)
###########################
# Evidence of party inducement
RealDeltaEPP <- data.frame(summary(as.mcmc(deltaEPP))[2])
DeltaEPP <- RealDeltaEPP[,1]>0 | RealDeltaEPP[,5]<0
RealDeltaPES <- data.frame(summary(as.mcmc(deltaPES))[2])
DeltaPES <- RealDeltaPES[,1]>0 | RealDeltaPES[,5]<0
RealDeltaELDR <- data.frame(summary(as.mcmc(deltaELDR))[2])
DeltaELDR <- RealDeltaPES[,1]>0 | RealDeltaELDR[,5]<0
RealDeltaGreen <- data.frame(summary(as.mcmc(deltaGreen))[2])
DeltaGreen <- RealDeltaPES[,1]>0 | RealDeltaGreen[,5]<0

TestDelta <- cbind(vote.info[360:713,c(11,12,16,18)],DeltaEPP,DeltaPES,DeltaELDR,DeltaGreen)
TestDelta
names(TestDelta)
summary(TestDelta)
dim(TestDelta[TestDelta$DeltaEPP==TRUE,])
summary(TestDelta[TestDelta$DeltaEPP==TRUE,])
summary(TestDelta[TestDelta$DeltaPES==TRUE,])
summary(TestDelta[TestDelta$DeltaELDR==TRUE,])
summary(TestDelta[TestDelta$DeltaGreen==TRUE,])
summary(TestDelta)
summary(TestDelta[TestDelta$RCV.Sponsor=="V/ALE",])
summary(TestDelta[TestDelta$RCV.Sponsor=="V/ALE" &
                  TestDelta$Main.Policy.Issue=="Environment",])
summary(TestDelta[TestDelta$DeltaELDR==TRUE,])
summary(TestDelta[TestDelta$DeltaPES==TRUE,])
summary(TestDelta[TestDelta$DeltaEPP==TRUE,])
Allpres <- (TestDelta[TestDelta$DeltaEPP==TRUE & TestDelta$DeltaPES==TRUE
                  & TestDelta$DeltaELDR==TRUE,])
dim(Allpres)
summary(as.numeric(Allpres$Yes)<314)
summary(as.numeric(TestDelta$Yes)<314)

BIGpres <- (TestDelta[TestDelta$DeltaEPP==TRUE & TestDelta$DeltaPES==TRUE,])
summary(BIGpres)
summary(as.numeric(BIGpres$Yes)<314)

Nopres <- (TestDelta[TestDelta$DeltaEPP==FALSE & TestDelta$DeltaPES==FALSE
                  & TestDelta$DeltaELDR==FALSE,])
dim(Nopres)
summary(as.numeric(Nopres$Yes)<314)
# Compare the ideal points#
Standard<-summary(as.mcmc(theta))[2] #Standard
Smed<-Standard$quantiles[,3]
Slower<-Standard$quantiles[,1]
Shigher<-Standard$quantiles[,5]
Slow25<-Standard$quantiles[,2]
Shigh75<-Standard$quantiles[,4]

Resolutions<-summary(as.mcmc(theta2))[2] #Resolutions
Rmed<-Resolutions$quantiles[,3]
Rlower<-Resolutions$quantiles[,1]
Rhigher<-Resolutions$quantiles[,5]
Rlow25<-Resolutions$quantiles[,2]
Rhigh75<-Resolutions$quantiles[,4]

Codecision<-summary(as.mcmc(Cod))[2] # Codecision
Cmed<-Codecision$quantiles[,3]
Clower<-Codecision$quantiles[,1]
Chigher<-Codecision$quantiles[,5]
Clow25<-Codecision$quantiles[,2]
Chigh75<-Codecision$quantiles[,4]

Idealpoints <- cbind(Smed,Slower,Shigher,Slow25,Shigh75,
                     Rmed,Rlower,Rhigher,Rlow25,Rhigh75,
                     Cmed,Clower,Chigher,Clow25,Chigh75,
                     legis.info)
IdealSort <- data.frame(Idealpoints[order(-Smed),])

####################
# Plot ideal points#
pdf("Idealpoints.pdf",width=8,height=5)
par(mfrow=c(1,3),mar=c(5,3,3,5) +.2)
index<-659:1
plot(IdealSort$Smed,index,type="n",xlim=c(-7.5,8),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Standard model")
for (i in 1:659){
segments(x0=IdealSort$Slower[i],y0=index[i],x1=IdealSort$Shigher[i],y1=index[i])}
for (j in 1:659){
segments(x0=IdealSort$Slow25[j],y0=index[j],x1=IdealSort$Shigh75[j],y1=index[j],col="gray")}
text((mean(IdealSort$Smed[IdealSort$EPG=="E"&IdealSort$MS=="U"])-3),645,labels="EPP UK",cex=1)
text((mean(IdealSort$Smed[IdealSort$EPG=="E"])+2),550,labels="EPP",cex=1)
text((mean(IdealSort$Smed[IdealSort$EPG=="G"])+2),400,labels="UEN",cex=1)
text((mean(IdealSort$Smed[IdealSort$EPG=="L"])+2),320,labels="ELDR",cex=1)
text((mean(IdealSort$Smed[IdealSort$EPG=="S"])+2),170,labels="PES",cex=1)
text((mean(IdealSort$Smed[IdealSort$EPG=="V"])+2.5),40,labels="V/ALE",cex=1)
text((mean(IdealSort$Smed[IdealSort$EPG=="M"])+2.5),15,labels="EUL/NGL",cex=1)

plot(IdealSort$Rmed,index,type="n",xlim=c(-7.5,8),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Resolutions")
for (i in 1:659){
segments(x0=IdealSort$Rlower[i],y0=index[i],x1=IdealSort$Rhigher[i],y1=index[i])}
for (j in 1:659){
segments(x0=IdealSort$Rlow25[j],y0=index[j],x1=IdealSort$Rhigh75[j],y1=index[j],col="gray")}
text((mean(IdealSort$Rmed[IdealSort$EPG=="E"&IdealSort$MS=="U"])-3),645,labels="EPP UK",cex=1)
text((mean(IdealSort$Rmed[IdealSort$EPG=="E"])+2),550,labels="EPP",cex=1)
text((mean(IdealSort$Rmed[IdealSort$EPG=="G"])+2),400,labels="UEN",cex=1)
text((mean(IdealSort$Rmed[IdealSort$EPG=="L"])+2),320,labels="ELDR",cex=1)
text((mean(IdealSort$Rmed[IdealSort$EPG=="S"])+2),170,labels="PES",cex=1)
text((mean(IdealSort$Rmed[IdealSort$EPG=="V"])+2.5),40,labels="V/ALE",cex=1)
text((mean(IdealSort$Rmed[IdealSort$EPG=="M"])+2.5),15,labels="EUL/NGL",cex=1)

plot(IdealSort$Cmed,index,type="n",xlim=c(-9,9),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Codecision amendments")
for (i in 1:659){
segments(x0=IdealSort$Clower[i],y0=index[i],x1=IdealSort$Chigher[i],y1=index[i])}
for (j in 1:659){
segments(x0=IdealSort$Clow25[j],y0=index[j],x1=IdealSort$Chigh75[j],y1=index[j],col="gray")}
text((mean(IdealSort$Cmed[IdealSort$EPG=="E"&IdealSort$MS=="U"])-3),645,labels="EPP UK",cex=1)
text((mean(IdealSort$Cmed[IdealSort$EPG=="E"])+2),550,labels="EPP",cex=1)
text((mean(IdealSort$Cmed[IdealSort$EPG=="G"])+2),400,labels="UEN",cex=1)
text((mean(IdealSort$Cmed[IdealSort$EPG=="L"])+2),320,labels="ELDR",cex=1)
text((mean(IdealSort$Cmed[IdealSort$EPG=="S"])+2),170,labels="PES",cex=1)
text((mean(IdealSort$Cmed[IdealSort$EPG=="V"])+2.5),40,labels="V/ALE",cex=1)
text((mean(IdealSort$Cmed[IdealSort$EPG=="M"])+2.5),15,labels="EUL/NGL",cex=1)
dev.off()
# Correlation
cor(IdealSort$Smed,IdealSort$Rmed)
cor(IdealSort$Smed,IdealSort$Cmed)
cor(IdealSort$Rmed,IdealSort$Cmed)

cor(IdealSort$Rmed[IdealSort$EPG=="E"],IdealSort$Cmed[IdealSort$EPG=="E"])
cor(IdealSort$Rmed[IdealSort$EPG=="S"],IdealSort$Cmed[IdealSort$EPG=="S"])
cor(IdealSort$Rmed[IdealSort$EPG=="L"],IdealSort$Cmed[IdealSort$EPG=="L"])
cor(IdealSort$Rmed[IdealSort$EPG=="V"],IdealSort$Cmed[IdealSort$EPG=="V"])
cor(IdealSort$Rmed[IdealSort$EPG=="M"],IdealSort$Cmed[IdealSort$EPG=="M"])
cor(IdealSort$Rmed[IdealSort$EPG=="G"],IdealSort$Cmed[IdealSort$EPG=="G"])

#######################
# Compare cutpoints
# on resolutions and codecision
# standard model
aRes <- as.mcmc(alphaRes/betaRes)
testAr2<-data.frame(summary(aRes)[2])
SmallAr <- (testAr2[,5] - testAr2[,1])<5
testAr <- testAr2[SmallAr,]
medAr<-testAr[,3]
lowerAr<-testAr[,1]
higherAr<-testAr[,5]
low25Ar<-testAr[,2]
high75Ar<-testAr[,4]
testAc2<-data.frame(summary(as.mcmc(alphaCod/betaCod))[2])
SmallAc <- (testAc2[,5] - testAc2[,1])<5 # Only those with reasonable uncertainty
testAc <- testAc2[SmallAc,]
medAc<-testAc[,3]
lowerAc<-testAc[,1]
higherAc<-testAc[,5]
low25Ac<-testAc[,2]
high75Ac<-testAc[,4]
ourdataAr<-cbind(medAr,lowerAr,higherAr,low25Ar,high75Ar)
ourdataAc <- cbind(medAc,lowerAc,higherAc,low25Ac,high75Ac)
OurdataSortAr<-data.frame(ourdataAr[order(-medAr),])
OurdataSortAc<-data.frame(ourdataAc[order(-medAc),])
indexAr<-dim(OurdataSortAr)[1]:1
indexAc<-dim(OurdataSortAc)[1]:1
pdf("CutpointsStandard.pdf",width=10)
par(mfrow=c(2,1))
plot(OurdataSortAr$medAr,indexAr,type="n",xlim=c(-7.5,8),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Resolution cutpoints")
for (i in 1:max(indexAr)){
segments(x0=OurdataSortAr$lowerAr[i],y0=indexAr[i],x1=OurdataSortAr$higherAr[i],y1=indexAr[i])}
for (j in 1:max(indexAr)){
segments(x0=OurdataSortAr$low25Ar[j],y0=indexAr[j],x1=OurdataSortAr$high75Ar[j],y1=indexAr[j],col="gray")}
legend(1,80,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")

plot(OurdataSortAc$medAc,indexAc,type="n",xlim=c(-7.5,8),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Codecision cutpoints")
for (i in 1:max(indexAc)){
segments(x0=OurdataSortAc$lowerAc[i],y0=indexAc[i],x1=OurdataSortAc$higherAc[i],y1=indexAc[i])}
for (j in 1:max(indexAc)){
segments(x0=OurdataSortAc$low25Ac[j],y0=indexAc[j],x1=OurdataSortAc$high75Ac[j],y1=indexAc[j],col="gray")}
legend(1,80,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")
dev.off()

################################
# Party induced cutpoints
alphadeltaPES <- (alphaCod2 + deltaPES)/betaCod2
pressurePES <- data.frame(summary(as.mcmc(alphadeltaPES))[2])
SmallS <- (pressurePES[,5] - pressurePES[,1])<5
pressPESa <- round(pressurePES[SmallS,],3)
names(pressPESa) <- c('lower','low25','med','high75','higher')
OurdataSortS<-data.frame(pressPESa[order(-pressPESa$med),])

alphadeltaL <- (alphaCod2 + deltaELDR)/betaCod2
pressureL <- data.frame(summary(as.mcmc(alphadeltaL))[2])
SmallL <- (pressureL[,5] - pressureL[,1])<5
pressLa <- round(pressureL[SmallL,],3)
names(pressLa) <- c('lower','low25','med','high75','higher')
OurdataSortL<-data.frame(pressLa[order(-pressLa$med),])

alphadeltaEPP <- (alphaCod2 + deltaEPP)/betaCod2
pressureEPP <- data.frame(summary(as.mcmc(alphadeltaEPP))[2])
SmallE <- (pressureEPP[,5] - pressureEPP[,1])<5
pressEPPa <- round(pressureEPP[SmallE,],3)
names(pressEPPa) <- c('lower','low25','med','high75','higher')
OurdataSortE<-data.frame(pressEPPa[order(-pressEPPa$med),])

alphadeltaGreen <- (alphaCod2 + deltaGreen)/betaCod2
pressureGreen <- data.frame(summary(as.mcmc(alphadeltaGreen))[2])
SmallV <- (pressureGreen[,5] - pressureGreen[,1])<5
pressVa <- round(pressureGreen[SmallV,],3)
names(pressVa) <- c('lower','low25','med','high75','higher')
OurdataSortV<-data.frame(pressVa[order(-pressVa$med),])

alphadeltaLeft <- (alphaCod2)/betaCod2
pressureLeft <- data.frame(summary(as.mcmc(alphadeltaLeft))[2])
SmallM <- (pressureLeft[,5] - pressureLeft[,1])<5
pressMa <- round(pressureLeft[SmallM,],3)
names(pressMa) <- c('lower','low25','med','high75','higher')
OurdataSortM<-data.frame(pressMa[order(-pressMa$med),])

alphadeltaGue <- (alphaCod2 + deltaGue)/betaCod2
pressureGue <- data.frame(summary(as.mcmc(alphadeltaGue))[2])
SmallG <- (pressureGue[,5] - pressureGue[,1])<5
pressGa <- round(pressureGue[SmallG,],3)
names(pressGa) <- c('lower','low25','med','high75','higher')
OurdataSortG<-data.frame(pressGa[order(-pressGa$med),])
#####################
pdf("PressureProcedureParty.pdf",height=8)
par(mfrow=c(3,2))
################
index <- dim(OurdataSortM)[1]:1
plot(OurdataSortM$med,index,type="n",xlim=c(-7.5,8.5),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Party induced cutpoints, GUE/NGL
Codecision position")
for (i in 1:max(index)){
segments(x0=OurdataSortM$lower[i],y0=index[i],x1=OurdataSortM$higher[i],y1=index[i])}
for (j in 1:max(index)){
segments(x0=OurdataSortM$low25[j],y0=index[j],x1=OurdataSortM$high75[j],y1=index[j],col="gray")}
legend(-.5,70,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")
hist(IdealSort$Cmed[IdealSort$EPG=="M"],add=TRUE,col="grey")

index <- dim(OurdataSortV)[1]:1
plot(OurdataSortV$med,index,type="n",xlim=c(-7.5,8.5),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Party induced cutpoints, V/ALE
Codecision position")
for (i in 1:max(index)){
segments(x0=OurdataSortV$lower[i],y0=index[i],x1=OurdataSortV$higher[i],y1=index[i])}
for (j in 1:max(index)){
segments(x0=OurdataSortV$low25[j],y0=index[j],x1=OurdataSortV$high75[j],y1=index[j],col="gray")}
legend(-.5,40,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")
hist(IdealSort$Cmed[IdealSort$EPG=="V"],add=TRUE,col="grey")
####################
index <- dim(OurdataSortS)[1]:1
plot(OurdataSortS$med,index,type="n",xlim=c(-7.5,8.5),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Party induced cutpoints, PES
Codecision position")
for (i in 1:max(index)){
segments(x0=OurdataSortS$lower[i],y0=index[i],x1=OurdataSortS$higher[i],y1=index[i])}
for (j in 1:max(index)){
segments(x0=OurdataSortS$low25[j],y0=index[j],x1=OurdataSortS$high75[j],y1=index[j],col="gray")}
legend(-.5,70,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")
hist(IdealSort$Cmed[IdealSort$EPG=="S"],add=TRUE,col="grey")

####################
index <- dim(OurdataSortL)[1]:1
plot(OurdataSortL$med,index,type="n",xlim=c(-7.5,8.5),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Party induced cutpoints, ELDR
Codecision position")
for (i in 1:max(index)){
segments(x0=OurdataSortL$lower[i],y0=index[i],x1=OurdataSortL$higher[i],y1=index[i])}
for (j in 1:max(index)){
segments(x0=OurdataSortL$low25[j],y0=index[j],x1=OurdataSortL$high75[j],y1=index[j],col="gray")}
legend(.5,70,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")
hist(IdealSort$Cmed[IdealSort$EPG=="L"],add=TRUE,col="grey")

index <- dim(OurdataSortG)[1]:1
plot(OurdataSortG$med,index,type="n",xlim=c(-7.5,8.5),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Party induced cutpoints, UEN
Codecision position")
for (i in 1:max(index)){
segments(x0=OurdataSortG$lower[i],y0=index[i],x1=OurdataSortG$higher[i],y1=index[i])}
for (j in 1:max(index)){
segments(x0=OurdataSortG$low25[j],y0=index[j],x1=OurdataSortG$high75[j],y1=index[j],col="gray")}
legend(1,120,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")
hist(IdealSort$Cmed[IdealSort$EPG=="G"],add=TRUE,col="grey")

index <- dim(OurdataSortE)[1]:1
plot(OurdataSortE$med,index,type="n",xlim=c(-7.5,8.5),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Party induced cutpoints, EPP
Codecision position")
for (i in 1:max(index)){
segments(x0=OurdataSortE$lower[i],y0=index[i],x1=OurdataSortE$higher[i],y1=index[i])}
for (j in 1:max(index)){
segments(x0=OurdataSortE$low25[j],y0=index[j],x1=OurdataSortE$high75[j],y1=index[j],col="gray")}
legend(1.75,80,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")
hist(IdealSort$Cmed[IdealSort$EPG=="E"],add=TRUE,col="grey")

dev.off()
#################
# Party model
# Resolution cutpoints
aPRes <- as.mcmc(alphaRes/betaRes)
testPAr2<-data.frame(summary(aRes)[2])
SmallPAr <- (testPAr2[,5] - testPAr2[,1])<5
testPAr <- testPAr2[SmallAr,]
medPAr<-testPAr[,3]
lowerPAr<-testPAr[,1]
higherPAr<-testPAr[,5]
low25PAr<-testPAr[,2]
high75PAr<-testPAr[,4]
ourdataPAr<-cbind(medPAr,lowerPAr,higherPAr,low25PAr,high75PAr)
OurdataSortPAr<-data.frame(ourdataPAr[order(-medPAr),])
indexPAr<-dim(OurdataSortPAr)[1]:1

pdf("CutpointsParty.pdf",height=4)
par(mfrow=c(1,1))
plot(OurdataSortPAr$medPAr,indexPAr,type="n",xlim=c(-7.5,8),bty="n",yaxt="n",ylab="",
xlab="Left - Right",col=1,pch=16,main="Resolution cutpoints")
for (i in 1:max(indexPAr)){
segments(x0=OurdataSortPAr$lowerPAr[i],y0=indexPAr[i],x1=OurdataSortPAr$higherPAr[i],y1=indexPAr[i])}
for (j in 1:max(indexPAr)){
segments(x0=OurdataSortPAr$low25PAr[j],y0=indexPAr[j],x1=OurdataSortPAr$high75PAr[j],y1=indexPAr[j],col="gray")}
legend(1,80,legend=c("95% credibility interval",
"50% credibility interval"),col=c("black","gray"),cex=.8,,lty=1,bty="n")
dev.off()
