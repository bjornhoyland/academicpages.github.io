#####################
# Agreement index   #
# Hix et al 2007:91 #
#####################
AI <-   function(Majority,Total){
# This is the functional form of the Hix index
  AI <- (Majority - .5*(Total-Majority))/Total
return(AI)
}
###########################
# This function does all the work,
# The output is party cohesion in each vote  
agree <- function(votes=votes){  
yes <- Yes <- no <- No <- abstain <- Abstain <- Total <- Agree <- NA
for (i in 1:dim(votes)[2]){
yes <- sum(votes[,i]==1,na.rm=TRUE)
Yes <- rbind(Yes,yes)
no <- sum(votes[,i]==0,na.rm=TRUE)
No <- rbind(No,no)
abstain <- sum(is.na(votes[,i]))
Abstain <- rbind(Abstain,abstain)
}
yes <- Yes[2:length(Yes)]
no <- No[2:length(No)]
abstain <- Abstain[2:length(Abstain)]
decisions <- cbind(yes,no,abstain)
Majority <- apply(decisions,MARGIN=1,max)
Total <- apply(decisions,MARGIN=1,sum)
Agree <- AI(Majority,Total)
return(Agree)
}
#############
HixIndex <- function(data=data,votes=data$votes,party=data$legis.data$party){
Index <- NA
for (j in levels(party)){
index <- agree(votes[party==j,])
Index <- cbind(Index,index)
}
HixIndex <- Index[,2:dim(Index)[2]]
colnames(HixIndex) <- levels(data$legis.data$party)
return(data.frame(HixIndex))
}
