# This file reproduces the results.
# I have commented out the JAGS models
source("Idealpoint.R")
#source("JAGSmodels/jagscript.r") These models take several days to run
source("final.R")
