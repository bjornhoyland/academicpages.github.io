system("jags standard.cmd")
system("jags pressureprocedure.cmd")
