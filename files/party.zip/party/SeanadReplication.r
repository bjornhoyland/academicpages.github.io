##########################
## Get the Party Started #
## Sircar & H?yland      #
## Party politics        #
## Vol 16 (1): 89 - 110  #
##########################
rm(list=ls())
InfoPre <- read.csv2("VoteInfoPre.csv",header=F)
VotesPre <- read.csv2("VotesPre.csv",header=F)
InfoPost <- read.csv2("VoteInfoPost.csv",header=F)
VotesPost <- read.csv2("VotesPost.csv",header=F)
Bio <- read.csv2("SeanadBioNarrow.csv",header=T)
Legis<-data.frame(Bio[,3:7])
library(car)
Legis$party<-recode(Legis$party," 1=0;0=1;2=2")
library(pscl)
PreVotes<-rollcall(t(VotesPre),legis.name=Bio$Name,yea=1,nay=2,missing=c(3,4),notInLegis=9,legis.data=Legis
 ,vote.data=InfoPre,desc="Irish Seanad 1922-28",source="www.oireachtas.ie")
PreVotes<-dropRollCall(PreVotes,dropList=list(legisMin=1))
constraintsd1 <- constrain.legis(PreVotes,x=list("Countess of Desart"=-1,
						"Mr. William Cummins"=1),d=1)
 
summary(PreVotes,verbose=TRUE)
ResultsPre<-ideal(PreVotes,maxiter=1e5,#mda=FALSE,
	burnin=1e4,thin=1e2,store.item=TRUE,verbose=TRUE,d=2)
ResultsPre1<-ideal(PreVotes,maxiter=1e5,startvals=constraintsd1,#mda=FALSE,
	burnin=1e4,thin=1e2,store.item=TRUE,verbose=TRUE,d=1)
ResultsPre3<-ideal(PreVotes,maxiter=1e5,#mda=FALSE,
	burnin=1e4,thin=1e2,store.item=TRUE,verbose=TRUE,d=3)
pdf(file="TraceplotPre.pdf",height=8,width=14)
tracex(ResultsPre1,legis=c("Rt. Hon. Henry Givens Burgess"))
dev.off()
summary(ResultsPre1)
plot(ResultsPre1)
text(locator(2),labels=c("Labour","Others"),cex=1.5) 
res2dpre <- ResultsPre
res2dpre$xbar <- ResultsPre$xbar * (-1) # Turn to compare with the other period
plot(res2dpre,overlayCuttingPlanes=FALSE)
text(locator(2),labels=c("Labour","Others"),cex=1.5) 
plot(res2dpre,overlayCuttingPlanes=TRUE)
text(locator(2),labels=c("Labour","Others"),cex=1.5) 
fit.pre <- predict(ResultsPre)
fit1.pre <- predict(ResultsPre1)
fit3.pre <- predict(ResultsPre3)
fit1.pre$overall.percent
fit.pre$overall.percent
fit3.pre$overall.percent
par(mfrow=c(2,1))
plot(fit.pre,type="legis")
par(mfrow=c(1,1))
####
#########
pre<-summary(PreVotes,verbose=TRUE)
diff.pre<-pre$voteTab
naive.pre <- rep(0,dim(diff.pre)[1])
for (i in 1:dim(diff.pre)[1]){
naive.pre[i] <- 100*(max(diff.pre[i,1],diff.pre[i,2])/
	(diff.pre[i,1]+diff.pre[i,2]))
}
mean(naive.pre)
APRE.pre1 <- (fit1.pre$overall.percent / mean(naive.pre)) - 1
APRE.pre1
APRE.pre <- (fit.pre$overall.percent / mean(naive.pre)) - 1
APRE.pre
APRE.pre3 <- (fit3.pre$overall.percent / mean(naive.pre)) - 1
APRE.pre3

Legis<-data.frame(Bio[,3:7])
Legis$party<-recode(Legis$party," 1=0;0=1;2=2")
PostVotes<-rollcall(t(VotesPost),legis.name=Bio$Name,yea=1,nay=2,missing=c(3,4),
                    notInLegis=9,legis.data=Legis
 ,vote.data=InfoPost,desc="Irish Seanad 1928-36",source="www.oireachtas.ie")
PostVotes<-dropRollCall(PostVotes,dropList=list(legisMin=1))
summary(PostVotes,verbose=TRUE)
constraintsd1 <- constrain.legis(PostVotes,x=list("Countess of Desart"=-1,
						"Mr. William Cummins"=1),d=1)
ResultsPost<-ideal(PostVotes,maxiter=1e5,
	burnin=1e4,thin=1e2,store.item=TRUE,verbose=TRUE,d=2)
ResultsPost1<-ideal(PostVotes,maxiter=1e5,startvals=constraintsd1,
	burnin=1e4,thin=1e2,store.item=TRUE,verbose=TRUE,d=1)
ResultsPost3<-ideal(PostVotes,maxiter=1e5,
	burnin=1e4,thin=1e2,store.item=TRUE,verbose=TRUE,d=3)
summary(ResultsPost1)
#plot(ResultsPost1)
#text(locator(3),labels=c("Labour","Fianna Fail","Others"),cex=1.5)
plot(ResultsPost,overlayCuttingPlanes=FALSE)
#text(locator(3),labels=c("Labour","Fianna Fail","Others"),cex=1.5) 
plot(ResultsPost,overlayCuttingPlanes=TRUE)
#text(locator(3),labels=c("Labour","Fianna Fail","Others"),cex=1.5) 

fit.post <- predict(ResultsPost)
par(mfrow=c(2,1))
plot(fit.post,type="legis")
par(mfrow=c(1,1))
fit1.post <- predict(ResultsPost1)
fit3.post <- predict(ResultsPost3)

fit1.post$overall.percent
fit.post$overall.percent
fit3.post$overall.percent
#########
post<-summary(PostVotes,verbose=TRUE)
diff.post<-post$voteTab
naive.post <- rep(0,dim(diff.post)[1])
for (i in 1:dim(diff.post)[1]){
naive.post[i] <- 100*(max(diff.post[i,1],diff.post[i,2])/
	(diff.post[i,1]+diff.post[i,2]))
}
mean(naive.post)

APRE.post1 <- (fit1.post$overall.percent - mean(naive.post)) - 1
APRE.post1
fit1.post$overall.percent
APRE.post <- (fit.post$overall.percent - mean(naive.post)) - 1
APRE.post
APRE.post3 <- (fit3.post$overall.percent - mean(naive.post)) - 1
APRE.post3

###########
Pre <- idealToMCMC(ResultsPre1)
## Moore
Power1 <- Pre[,55]
Esmonde1 <- Pre[,7]
Hooper1 <- Pre[,21]
#Plot density of the two thetas
par(mfrow=c(2,1))
plot(density(Power1), col="blue", 
main="Ideal Point Estimate Distributions 1922-1927", 
xlim=c(-.7,.7), xlab="Location",ylim=c(0,6),lty=1,lwd=3,bty="n") 
lines(density(Esmonde1), col="green",lty=2,lwd=3)
lines(density(Hooper1), col="red",lty=3,lwd=3)
legend(-.7, 5.8, legend=c("Power -  Independent", 
"Esmonde -  Independent","Hooper - Independent"), 
lwd=3, col=c("blue", "green","red"),lty=1:3,bty="n")

Post <- idealToMCMC(ResultsPost1)
Power2 <- Post[,64]
Esmonde2 <- Post[,25]
Hooper2 <- Post[,36]
#Plot density of the two thetas
plot(density(Power2), col="blue", 
main="Ideal Point Estimate Distributions 1928-1936", 
xlim=c(-.7,.7), xlab="Location",ylim=c(0,7),lty=1,lwd=3,bty="n") 
lines(density(Esmonde2), col="green",lty=2,lwd=3)
lines(density(Hooper2), col="red",lty=3,lwd=3)
legend(-.7, 7.8, legend=c("Power - Fianna F?il", 
"Esmonde Independent","Hooper Independent"), 
lwd=3, col=c("blue", "green","red"),lty=1:3,bty="n")
par(mfrow=c(1,1))



