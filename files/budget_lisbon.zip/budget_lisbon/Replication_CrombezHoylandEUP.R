
## ------------------------------------------------------------------------
set.seed(985236)
votes <- list.files("../EP_votes/")
votes <- votes[-length(votes)]
onevote<- list()
for (i in 1:length(votes)){
  onevote[[i]] <- cbind(i,read.csv(paste("../EP_votes/",votes[i],sep="")))
  colnames(onevote[[i]]) <- c("voteid","name","state","loyal","vote","group")
}
votes <- data.frame(do.call("rbind",onevote))
votes <- votes[,-4]
votematrix <- reshape(votes, timevar=c("voteid"),idvar=c("name","state","group"),direction="wide")

library(pscl)
legisdata <- data.frame(with(votematrix,cbind(as.character(state),as.character(state),0,
                                              1:nrow(votematrix),as.character(group),as.character(group))))
colnames(legisdata) <- c("state","icpsrState","cd","icpsrLegis","partyName","party")
voteinfo <- read.csv("../EP_votes/VoteInfo.csv")

info <- tolower(voteinfo$Name.of.document)
legisnames <- paste(votematrix$name,votematrix$state,votematrix$group,sep=" ")
rownames(votematrix) <- legisnames
votemat <- t(votematrix[,4:ncol(votematrix)])
trim <- function (x) gsub("^\\s+|\\s+$", "", x)
voteinfo$Name.of.document <- trim(voteinfo$Name.of.document)
votematInfo <- cbind(voteinfo[,1:2],votemat)


## ------------------------------------------------------------------------
tmp <- file("../CouncilVotes//BudgetvotesinCouncil.csv",encoding="Latin1")
votes <- read.csv2(tmp)
C.voteinfo <- votes[,1:33]
info <- trim(C.voteinfo$EP.ref)
voting <- t(votes[,62:89])
voting[is.na(voting)] <- 1

names <- unlist(strsplit(rownames(voting),split=".1"))
rownames(voting) <- names
###################
C.voting <- t(voting)
C.voting[voteinfo$Negative==1,] <- abs(C.voting[voteinfo$Negative==1,] -1)
C.voting[C.voting>1] <- "Against"
C.voting[C.voting==1] <- "For"


## ------------------------------------------------------------------------
C.vote <- cbind(C.voteinfo[,31:32],C.voting)
C.vote$EP.ref <-  gsub(" -.*","",C.vote$EP.ref)
votematInfo$Name.of.document <-  gsub(" -.*","",votematInfo$Name.of.document)
C.vote$EP.date <- as.Date(C.vote$EP.date,format="%d.%m.%y")
C.vote <- C.vote[C.vote$EP.date>"2009-12-01",]
votematInfo$Date <- as.Date(votematInfo$Date,format="%d.%m.%Y")
votematInfo <- votematInfo[votematInfo$Date>"2009-12-01",]
votematInfo <- votematInfo[-1,]
test <- merge(C.vote,votematInfo,by.x=c("EP.date","EP.ref"),by.y=c("Date","Name.of.document"),all=TRUE)
votes <- test[,3:ncol(test)]
info <- test[,1:2]
for (i in 1:ncol(votes)){
votes[,i] <- ifelse(votes[,i]=="For",1,ifelse(votes[,i]=="Against",0,9))
}

legdata <- cbind(names,names,0,0,"council","council")
colnames(legdata) <- names(legisdata)
rownames(legdata) <- names
rownames(legisdata) <- legisnames
legisdata <- rbind(legdata,legisdata)
legisnames <- t(rownames(legisdata))
vot <- rollcall(t(votes),
                  legis.names=legisnames,
                  legis.data=legisdata,vote.data=info,
                  desc="EP and Council Budget votes 2009-12-01 - 2014-01-02",
                  source="votewatch.eu")


## ------------------------------------------------------------------------
vot <- dropRollCall(vot,dropList=list(lop=1,legisMin=10))
out1 <- ideal(vot,d=1,store.item=TRUE)
out2 <- ideal(vot,d=2,store.item=TRUE)


## ------------------------------------------------------------------------
phat <- predict(out1, cutoff=.88)
phat2 <- predict(out2, cutoff=.88)
phat.table <- round(rbind(
  phat$party.percent,
  phat2$party.percent,
  phat2$party.percent - phat$party.percent),3)
phat.table


## ------------------------------------------------------------------------
library(car)
cols <- c(recode(vot$legis.data$party,"'ALDE/ADLE'=1;'ECR'=7;
                 'EFD'=8;'EPP'=4;'Greens/EFA'=3;'GUE-NGL'=5;'S&D'=2;else=9"))
votingweights <- c(12,10,12,7,29,4,7,12,27,29,7,
                   29,4,4,7,4,12,3,13,10,27,12,14,4,7,7,10,29)
## calculate group mean and sd in 2d, 
gr.mean <- aggregate(out2$xbar,by=list(vot$legis.data$partyName),FUN=mean)
gr.sd <- aggregate(out2$xbar,by=list(vot$legis.data$partyName),FUN=var)
gr.mean <- gr.mean[-1,]
gr.sd <- gr.sd[-1,]

plot(x=gr.mean$D1,y=gr.mean$D2,type="n",xlim=c(-1.75,2),ylim=c(-2,2.5),
     bty="n",main="Budget votes: Political groups",ylab="2nd dimension",xlab="1st dimension")
points(out2$xbar,pch=16,cex=.5,col="grey")
text(x=gr.mean$D1,y=gr.mean$D2+.2,labels=gr.mean$Group.1,cex=1.5)

plot(out2$xbar[1:28,],xlim=c(-1.75,2),ylim=c(-2,2.5),type="n",
     bty="n",main="Budget votes: Council members",ylab="2nd dimension",xlab="1st dimension")
text(out2$xbar[1:28,],labels=rownames(out2$xbar)[1:28],cex=.9)

gr1 <- rownames(out2$xbar)[1:28][out2$xbar[1:28,1]< -.5 & out2$xbar[1:28,2]<0]
#legend("bottomleft",legend=gr1,cex=.6)
gr2 <- rownames(out2$xbar)[1:28][out2$xbar[1:28,1]> -.3 &  out2$xbar[1:28,1]< .3 & out2$xbar[1:28,2]< 0]
#legend(0,-1.35,legend=gr2,cex=.6)
gr3 <- rownames(out2$xbar)[1:28][out2$xbar[1:28,1]> .3 &  out2$xbar[1:28,1]< .7 & out2$xbar[1:28,2]< -.4]
#legend(.5,-1.2,legend=gr3,cex=.6)

plot(x=gr.mean$D1,y=gr.mean$D2,type="n",xlim=c(-1.75,2),ylim=c(-2,2.5),
     bty="n",main="Budget votes: Council and EP",ylab="2nd dimension",xlab="1st dimension")
points(out2$xbar,pch=16,cex=.5,col="grey")
text(x=gr.mean$D1,y=gr.mean$D2+.2,labels=gr.mean$Group.1,cex=1.5)
text(out2$xbar[1:28,],labels=rownames(out2$xbar)[1:28],cex=1.1)


## ------------------------------------------------------------------------
discr1 <- t(apply(out2$beta[,,1],2,quantile,c(.1,.9)))
overlaps1 <-discr1[,1]<0 & discr1[,2]>0 
sum(overlaps1==FALSE)
sum(overlaps1==TRUE)
discr2 <- t(apply(out2$beta[,,2],2,quantile,c(.1,.9)))
overlaps2 <- discr2[,1]<0 & discr2[,2]>0
sum(overlaps2==FALSE)
sum(overlaps2==TRUE)
sum(overlaps1==TRUE & overlaps2==FALSE)
sum(overlaps1==FALSE & overlaps2==FALSE)

vot$vote.data[overlaps1==FALSE & overlaps2==TRUE,]# Pure 1 dimension votes
vot$vote.data[overlaps1==TRUE & overlaps2==FALSE,] # Pure 2 dimension, NONE 

