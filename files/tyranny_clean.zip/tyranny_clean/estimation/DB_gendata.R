###############################
## Clean Doing Business data ##
###############################
                                   
source("estimation/header.R")
Business <- read.csv(datafolder("DoingBusiness_081015.csv"),sep=",")

## convert all variables from "factor" to "numeric"
for (j in 3:dim(Business)[2]){
  Business[,j] <- as.numeric(as.character(Business[,j]))
}

## convert Economy from "factor" to "character"
Business$Economy <- as.character(Business$Economy)

## remove accents in country names
Business[Business$Economy=="C\223te d'Ivoire",][,1] <- "Cote d'Ivoire"
Business[Business$Economy=="S\306o Tom\202 and Principe",][,1] <- "Sao Tome and Principe"

## Turn around such that all measures are going the same way
Business$Credit_Legal <- 10-Business$Credit_Legal
Business$Credit_Info <- 6-Business$Credit_Info
Business$Credit_PublicCover <- 100-Business$Credit_PublicCover
Business$Credit_PrivateCover <- 100-Business$Credit_PrivateCover
Business$InvestProtect_Disclosure <- 10-Business$InvestProtect_Disclosure
Business$InvestProtect_DirLiability <- 10-Business$InvestProtect_DirLiability
Business$InvestProtect_Shareholder <- 10-Business$InvestProtect_Shareholder 
Business$InvestProtect_InvestProtect <- 10-Business$InvestProtect_InvestProtect
Business$Closing_Recovery <- 100-Business$Closing_Recovery

## DB sum these two vars, and use only the sum for rankings
Business$Credit_Sum <- Business$Credit_Legal+Business$Credit_Info

## DB replaces missing with max value
for (i in 1:dim(Business)[1]){
  for (j in 1:dim(Business)[2]) {
    if (is.na(Business[i,j])) {
      Business[i,j] <- max(Business[,j],na.rm=T)
    }
  }
}

## DB truncate firing costs at 8 weeks (see
## Simulator_English_2009.xls)
for (i in 1:dim(Business)[1]){
  if (Business[i,"Employ_CostFire"]<= 8) {
    Business[i,"Employ_CostFire"] <- 0
  }
}

## merge in World Bank classifications (note: only strictly valid for
## 2008-2009)
class <- read.csv(datafolder("classification_wb.csv"),sep=";")
Business <- merge(Business,class,by="Economy",all.x = T)

## create subdatasets for 2004 to 2009
for (i in 4:9) {
  name <- paste("b.0",i,"<- Business[Business$Year == 200",i,",]",sep="")
  eval(parse(text = name))	
}

rm(Business,i,j,name)

## rename current DB
DB_current <- b.09

## write data to file
write.csv(DB_current, file=datafolder("DB_clean.csv"), row.names = FALSE)
