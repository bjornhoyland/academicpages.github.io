## This file generates the figures and tables in
## Hoyland, Moene, Willumsen: "The Tyranny of International Index Rankings"
## Journal of Development Economics, forthcoming
## http://dx.doi.org/10.1016/j.jdeveco.2011.01.007

## See README for how to generate all the results from scratch

## SETUP AND READ IN DATA
## Source "headers" and libraries
source("estimation/header.R")
library(arm)
options(digits=5)                       # due to package arm

## The indexes used
indexes <- c("DB","FH","HDI")
no_chains <- 3

## Read in data from JAGS + read in cleaned data to get country names
for (i in indexes) {
  for (j in seq(no_chains)) {
    text <- paste(i,'_model_',j,' <- read.coda(output.file="',i,'_chain',j,'.txt",index.file="',i,'_index.txt")',sep="")
    eval(parse(text = text))
  }
  text <- paste(i,'_data <- read.csv(datafolder("',i,'_clean.csv"), as.is = TRUE)',sep="")
  eval(parse(text = text))
}

## Glue the chains together
HDI_model <- mcmc.list(HDI_model_1,HDI_model_2,HDI_model_3)
FH_model <- mcmc.list(FH_model_1,FH_model_2,FH_model_3)
DB_model <- mcmc.list(DB_model_1,DB_model_2,DB_model_3)

## Turn around DB (since scale opposite of the two other indexes)
for (j in seq(length(DB_model))) {
  DB_model[[j]] <- DB_model[[j]]*(-1)
}

## Clean up
rm(HDI_model_1,HDI_model_2,HDI_model_3,
   FH_model_1,FH_model_2,FH_model_3,
   DB_model_1,DB_model_2,DB_model_3,
   i,j)

## Create objects
HDI <- index_obj(HDI_model,HDI_data$country,HDI_data$rank,HDI_data,"Human Development Index","HDI")
FH <- index_obj(FH_model,FH_data$Country,"",FH_data,"Freedom House","FH")
DB <- index_obj(DB_model,DB_data$Economy,DB_data$Rank,DB_data,"Doing Business","DB")

## PLOTS
## Figures 1 (a), (b), (c): the indexes with uncertainty bands
pdf(file=figsfolder("HDI_score.pdf"),width=8,height=10)
indexplot(HDI)
dev.off()

pdf(file=figsfolder("FH_score.pdf"),width=8,height=10)
indexplot(FH)
dev.off()

pdf(file=figsfolder("DB_score.pdf"),width=8,height=10)
indexplot(DB)
dev.off()

## Figures 2 (a), (b), (c): the rankings with uncertainty bands
pdf(file=figsfolder("HDI_rank.pdf"),width=8,height=10)
rankingplot(HDI)
dev.off()

pdf(file=figsfolder("FH_rank.pdf"),width=8,height=10)
rankingplot(FH,
            title="Uncertainty in ranking based on Freedom House")
dev.off()

pdf(file=figsfolder("DB_rank.pdf"),width=8,height=10)
rankingplot(DB)
dev.off()

## Figures 3 and 4: Probability of bottom and top 10 for HDI and DB
btplot(HDI,top=TRUE,file=figsfolder("HDI_top.pdf"))
btplot(HDI,top=FALSE,file=figsfolder("HDI_bottom.pdf"))

btplot(DB,top=TRUE,file=figsfolder("DB_top.pdf"))
btplot(DB,top=FALSE,file=figsfolder("DB_bottom.pdf"))

## Figure 5: Ranking in the indexes vs. rankings from our estimation
pdf(file=figsfolder("HDI_rankvsrank.pdf"))
rankvsrankplot(HDI)
dev.off()

pdf(file=figsfolder("DB_rankvsrank.pdf"))
rankvsrankplot(DB)
dev.off()

## Figure 6: FH, probability of being free, partly free, and non-free
pdf(file=figsfolder("FH_class.pdf"),width=8,height=10)
fhgroupplot(FH)
dev.off()

## Table 1 and Appendix C: "Optimal" number of groups
## Generate results for the three indexes (Appendix C tables)
FH_groups <- groups(FH,file=tablesfolder("FH_groups.tex"))
DB_groups <- groups(DB,file=tablesfolder("DB_groups.tex"))
HDI_groups <- groups(HDI,file=tablesfolder("HDI_groups.tex"))

## Create Table 1
groupstab <- rbind(apply(DB_groups,2,max),apply(FH_groups,2,max),apply(HDI_groups,2,max))[,-1]
row.names(groupstab) <- c("Doing Business","Freedom House","Human Development Index")
groupstab <- xtable(groupstab,align="lrrrr")
print(groupstab,file=tablesfolder("groups.tex"),only.contents=TRUE)

## Various results mentioned in the text

## Pr(Iceland, Norway, Canada, and Australia) [commented on in the concl.]
# Get ID of the countries:
countries_id <- c(which(HDI$names=="Iceland"),
                  which(HDI$names=="Norway"),
                  which(HDI$names=="Canada"),
                  which(HDI$names=="Australia"))

inca <- function(ranking,countries_id) { # Pr(1.I,2.N,3.C,4.A)
  if (ranking[countries_id[1]]==1 & ranking[countries_id[2]]==2 &
      ranking[countries_id[3]]==3 & ranking[countries_id[4]]==4) {
    1
  }
  else {
    0
  }
}
inca2 <- function(ranking,countries_id) { # Pr(I > N > C > A)
  if (ranking[countries_id[1]] < ranking[countries_id[2]] &
      ranking[countries_id[2]] < ranking[countries_id[3]] & 
      ranking[countries_id[3]] < ranking[countries_id[4]]) {
    1
  }
  else {
    0
  }
}

## Pr(1.I, 2.N, 3.C, 4.A)
sum(apply(HDI$ranks,2,inca,countries_id=countries_id))/HDI$n.sims

## Pr(I > N > C > A)
sum(apply(HDI$ranks,2,inca2,countries_id=countries_id))/HDI$n.sims

## Confidence intervals for DB for Georgia, Saudi-Arabia and Mauritius
## [commented on in the conclusion]
DB$quantiles_ranks[59,]                 # CI for Georgia
DB$quantiles_ranks[137,]                # CI for Saudi-Arabia
DB$quantiles_ranks[104,]                # CI for Mauritius
