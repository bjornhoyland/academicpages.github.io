#############################
## Human Development Index ##
## Prepare and run JAGS    ##
#############################

source("estimation/header.R")

## Read in data
HDI <- read.csv(datafolder("HDI_clean.csv"))

## Choose variables
col.orig <- c("lifeexp","enrolment","literacy","gdp")
x.orig <- HDI[,col.orig]                # same results if we scale
x.orig[,"gdp"] <- log(x.orig[,"gdp"])   # HDI use log of gdp
x <- x.orig

## Clustered variables
group <- c(1,2,2,3)                     # grouping: schooling in same group
group.no <- max(group)                  # number of groups
group.pr <- c(0.00001,100,0.00001)      # allow variance for group 2

## Dimensions
total.dims <- dim(x)
n <- total.dims[1]
m <- total.dims[2]

## Initial values
initialf <- factanal(x,1,scores="Bartlett")
initialb <- matrix(rep(NA,m*2),m,2)
for (i in seq(m)) {
  initialb[i,] <- lm(x[,i] ~ initialf$score)$coefficients
}
inits1 <- function() {list (f=c(initialf$scores),
                            beta=initialb, 
                            delta=matrix(rep(0,n*group.no),n,group.no),
                            .RNG.seed=11683,
                            .RNG.name="base::Marsaglia-Multicarry")}

inits2 <- function() {list (f=c(initialf$scores),
                            beta=initialb, 
                            delta=matrix(rep(0,n*group.no),n,group.no),
                            .RNG.seed=42088,
                            .RNG.name="base::Super-Duper")}

inits3 <- function() {list (f=c(initialf$scores),
                            beta=initialb, 
                            delta=matrix(rep(0,n*group.no),n,group.no),
                            .RNG.seed=51262,
                            .RNG.name="base::Mersenne-Twister")}

## Write data file and inits for JAGS
x <- as.matrix(x)
dump(list = c("x","group","group.no","group.pr","n","m"), file = "HDI_dump.R")
dump_list(inits1(), file = "HDI_inits1.R")
dump_list(inits2(), file = "HDI_inits2.R")
dump_list(inits3(), file = "HDI_inits3.R")

## Call JAGS
system("jags HDI_jags.cmd")
