## This file contains the R-functions used by figures.R
## Hoyland, Moene, Willumsen: "The Tyranny of International Index Rankings"
## Journal of Development Economics, forthcoming
## http://dx.doi.org/10.1016/j.jdeveco.2011.01.007

clrs <- c("black","gray50","black")     # colors for the rankingplots

dump_list <- function(list, file) {
  for (i in seq(length(list))) {
    assign(x=names(list)[i],value=list[[i]])
  }
  dump(list=names(list), file = file)
}

extractFromCoda <- function(coda,vname,nofstar=FALSE){
  ## nofstar = TRUE returns number of fstars (i.e. number of countries)
  ## function originally created by Simon Jackman (?) at Stanford

  coda <- as.matrix(coda)
  dnames <- dimnames(coda)[[2]]
  theString <- paste("^",vname,sep="")
  theOnes <- grep(theString,
                  dnames)
  if (nofstar == FALSE)
    return(as.matrix(coda[,theOnes]))
  else if (nofstar == TRUE)
    return(length(theOnes))
}

index_obj <- function(mcmclist,countrynames,rank_orig,data_orig,indextitle,shortindextitle) {
  ## index_obj creates an object containing all the relevant info for
  ## an index
  
  n <- extractFromCoda(mcmclist,"fstar",nofstar = TRUE)
  
  draws_matrix <- as.matrix(mcmclist)[,1:n]
  ranks <- data.frame(apply(-draws_matrix,1,rank,ties.method="min"))
  quantiles_model <- quantiles(t(draws_matrix),countrynames)
  quantiles_ranks <- quantiles(ranks,countrynames)
  
  n.sims <- nrow(draws_matrix)

  X <- list(model=mcmclist,
            ranks=ranks,
            rank_orig=rank_orig,
            data_orig=data_orig,
            quantiles_model=quantiles_model,
            quantiles_ranks=quantiles_ranks,
            names=countrynames,
            n=n,
            n.sims=n.sims,
            title=indextitle,
            stitle=shortindextitle)

  class(X) <- "fred"
  return(X)
}

quantiles <- function(draws,countrynames) {
  ## quantiles returns the quantiles of draws with countrynames
  ## attached. used by index_obj
  
  draws <- data.frame(t(apply(draws,1,quantile,probs=c(0.025,0.25,0.5,0.75,0.975))))
  rownames(draws) <- countrynames
  colnames(draws) <- c("q025","q25","q50","q75","q975")
  return(draws)
}

error_obj <- function(index_obj) {
  tryCatch({
    if (class(index_obj) != "fred")
      stop("This function only accepts index objects (see index_obj)")
  })
}

error_obj_fh <- function(index_obj) {
  tryCatch({
    if (index_obj$stitle != "FH")
      stop("This function can only be applied to Freedom House")
  })
}

ciplot <- function(index_obj,rank) {
  ## ciplot plots country performance with confidence intervals from
  ## index_obj
  
  ## Get data from object
  n <- index_obj$n

  ## For ranks a low number is good, while for scores a low number is
  ## bad. Therefore index is n:1 in rank and n:1 in scores
  if (rank == TRUE) {
    unsorted_data <- index_obj$quantiles_rank
    sorted_data <- unsorted_data[order(unsorted_data$q50),]
    index <- n:1
    xlabel <- paste("Ranking",index_obj$stitle)
    names <- row.names(sorted_data)
    names <- rev(names)                 # since index is n:1
  } else if (rank == FALSE){
    unsorted_data <- index_obj$quantiles_model
    sorted_data <- unsorted_data[order(unsorted_data$q50),]
    index <- 1:n
    xlabel <- ""
    names <- row.names(sorted_data)
  }

  ## Number needed to set up the plot area
  xmax <- max(sorted_data)
  xmin <- min(sorted_data)
  xlimu <- xmax
  xlimb <- xmin-.6*(xmax-xmin)

  ## Main plotting function
  plot(sorted_data$q50,index,type="p",
       xlim=c(xlimb,xlimu),bty="n",yaxt="n",
       ylab="",xaxt="n",xlab=xlabel,col=clrs[1],
       pch=16)

  if (rank == TRUE) {
    axis(1,at=c(1,50,100,150))
  }
  
  ## Add confidence intervals
  for (i in 1:n){
    segments(x0=sorted_data$q025[i],y0=index[i],x1=sorted_data$q975[i],
             y1=index[i],lwd=1,col=clrs[2])
    segments(x0=sorted_data$q75[i],y0=index[i],x1=sorted_data$q25[i],
             y1=index[i],lwd=2,col=clrs[3])
  }
  
  ## Add country names
  odd <- seq(from=1,to=n,by=2)
  names_odd <- names[odd]
  text(x=xlimb,y=odd,labels=names_odd,cex=.5,adj=1,pos=2,offset=-6.5)
  even <- seq(from=2,to=n,by=2)
  names_even <- names[even]
  text(x=xlimb,pos=4,y=even,labels=names_even,cex=.5,adj=0,offset=6.7)
}

indexplot <- function(index_obj,title="",xlabel="",ylabel="") {
  ## indexplot plots country performance with confidence intervals

  ## Check that object is of correct type
  error_obj(index_obj)

  ## Plot using ciplot
  ciplot(index_obj,rank=FALSE)
  
  ## Get data from object to place legend with
  quantiles_model <- index_obj$quantiles_model
  quantiles_model <- quantiles_model[order(quantiles_model$q50),]
  n <- index_obj$n
  
  ## Set title of the figure
  if (title == "") {
    title <- index_obj$title
  }
  
  ## Add title and legend
  title(title)
  legend(min(quantiles_model[floor(n/1.7),]),floor(n/7),
         legend=c("95% Credibility Interval","50% Central Tendency"),
         lwd=c(1,3),cex=.75,bty="n",col=c(clrs[2],clrs[3]))
}

rankingplot <- function(index_obj,title="",xlab="") {
  ## rankingplot plots country performance in ranks with confidence
  ## intervals

  ## Check that object is of correct type
  error_obj(index_obj)
  
  ## Get data from object
  model <- index_obj$model
  names <- index_obj$names
  n <- index_obj$n
  ranks <- index_obj$ranks
  
  ## Set title of the figure
  if (title == "") {
    title <- paste("Uncertainty in the",index_obj$stitle,"ranking")
  }
  if (xlab == "") {
    xlab <- paste("Ranking",index_obj$stitle)
  }

  ## Plot using ciplot
  ciplot(index_obj,rank=TRUE)
  
  ## Add title and legend
  title(title)
  legend(40,23,legend=c("50% chance of being within the interval",
                 "95% chance of being within the interval"),lwd=1,
         col=c(clrs[3],clrs[2]),cex=.5,bty="n")
}

rankvsrankplot <- function(index_obj) {
  ## Check that object is of correct type
  error_obj(index_obj)

  ## Get data from object
  n <- index_obj$n
  rank_orig <- index_obj$rank_orig
  quantiles_ranks <- index_obj$quantiles_ranks
  stitle <- index_obj$stitle

  ## Title and labels
  xlabel <- paste("Ranking ", stitle, ", original",sep="")
  ylabel <- paste("Ranking ", stitle, ", re-estimated",sep="")

  ## Plot
  plot(rank_orig,quantiles_ranks$q50,type="p",pch=16,col=1,
       yaxt="n",xaxt="n",bty="n",
       xlab=xlabel,ylab=ylabel)
  axis(1,at=c(1,50,100,150))
  axis(2,at=c(1,50,100,150))
  
  ## Confidence intervals
  for (i in 1:n){
    segments(x0=rank_orig[i],y0=quantiles_ranks$q025[i],
             x1=rank_orig[i],y1=quantiles_ranks$q975[i],
             lwd=1,col=clrs[2])
    segments(x0=rank_orig[i],y0=quantiles_ranks$q25[i],
             x1=rank_orig[i],y1=quantiles_ranks$q75[i],
             col=clrs[1],lwd=2)
  }
  
  ## Correlation and legend
  rank_corr <- cor(rank_orig,quantiles_ranks$q50)
  text <- paste("Correlation b/w ",stitle,"'s rank and re-estimated ", stitle," rank: ", round(rank_corr,3),sep="")
  legend(-10,180,legend=c("50% chance of being within the interval",
                   "95% chance of being within the interval",text),
         col=c(clrs[1],clrs[2],"white"),lwd=1,cex=0.75,bty="n")
}

lessthan <- function(x,cutoff,top) {
  ## The function lessthan checks whether x is smaller than cutoff,
  ## and return TRUE/FALSE
  if (top==TRUE) {
    x < cutoff
  }
  else {
    x > cutoff
  }
}

btplot <- function(index_obj,top=TRUE,file="") {
  ## btplot generates a plot of the probability of being top / bottom
  ## ten. If the argument "file" is set, the figure is printed to
  ## "file"

  ## Check that object is of correct tyoe
  error_obj(index_obj)

  ## Get data from object
  ranks <- index_obj$ranks
  n <- index_obj$n
  n.sims <- index_obj$n.sims
  names <- index_obj$names
  stitle <- index_obj$stitle
  
  ## Set title
  if (top==TRUE) {
    title <- paste(stitle," - Probability of being among top 10")
  } else {
    title <- paste(stitle," - Probability of being among bottom 10")
  }
  
  ## Set cutoff for top or bottom
  cutoff <- 11            # since we are looking at top and bottom ten
  if (top==FALSE) {
    cutoff <- n-cutoff+1  # i.e. bottom ten
  }
  
  ## Identify the countries that have more than 5 % chance of being
  ## top / bottom ten
  ranks_ten <- apply(ranks,2,lessthan,cutoff=cutoff,top=top) # top / bottom
                                                             # ten or not?
  ranks_ten <- apply(ranks_ten,1,sum)/n.sims # relative no of times
                                             # top / bottom ten
  ranks_ten <- cbind(ranks_ten) 
  rownames(ranks_ten) <- names
  ranks_ten <- subset(ranks_ten,ranks_ten > 0.05) # countries that
                                                  # have above 5 per
                                                  # cent chance of
                                                  # being top / bottom
                                                  # 10
  ## Sort the countries for plotting
  if (top==TRUE){
    ranks_ten_sorted <- data.frame(ranks_ten[order(ranks_ten[,1]),])
  }
  else {
    ranks_ten_sorted <- data.frame(ranks_ten[order(-ranks_ten[,1]),])
  }
  
  ## Print figure to file
  if (file != "") {
    pdf(file=file,width=9.5,height=(2.5+0.06*dim(ranks_ten_sorted)[1]))
  }

  ## Main plot
  n_ten <- nrow(ranks_ten_sorted)       # no of countries to plot
  index <- 1:n_ten                      # index to plot against
  plot(ranks_ten_sorted[,1],index,type="p",
       xlim=c((min(ranks_ten_sorted))-0.3,max(ranks_ten_sorted)),bty="n",
       yaxt="n",ylab="",xaxt="n",xlab="",pch=20,
       main=title)
  
  ## Add country names
  odd <- seq(from=1,to=n_ten,by=2)
  names_odd <- row.names(ranks_ten_sorted)[odd]
  text(x=min(ranks_ten_sorted)-0.2,y=odd,labels=names_odd,cex=.5,adj=1)
  even <- seq(from=2,to=n_ten,by=2)
  names_even <- row.names(ranks_ten_sorted)[even]
  text(x=min(ranks_ten_sorted)-0.2,4,y=even,labels=names_even,cex=.5,adj=0)
  
  ## Add markers to plot
  lineticks <- c(.05,.25,.5,.75,.95,1)
  for (i in lineticks) {
    lines(c(i,i),c(2,n_ten-1),col="gray",lty="dashed")
    text(x=i,y=n_ten,label=paste(i),cex=.6)
  }
  
  ## Add text with no of countries in the plot
  no_countries <- paste("No. of countries: ",n_ten,sep="")
  mtext(no_countries,side=1,at=0,line=1,cex=.8)
  
  ## End print figure to file
  if (file != "") {
    dev.off()
  }
}

fhscore <- function(index_obj) {
  ## Calculate original scores FH scores and status

  ## Type checking: only accept FH
  error_obj_fh(index_obj)

  ## Get data from object
  FH <- index_obj$data_orig
  
  ## Functions for calculating scores
  PR <- function(x) {
    if (x %in% seq(36,40)) {
      return(1)
    } else if (x %in% seq(30,35)) {
      return(2)
    } else if (x %in% seq(24,29)) {
      return(3)
    } else if (x %in% seq(18,23)) {
      return(4)
    } else if (x %in% seq(12,17)) {
      return(5)
    } else if (x %in% seq(6,11)) {
      return(6)
    } else if (x %in% seq(0,5)) {
      return(7)
    }
  }
  CL <- function(x) {
    if (x %in% seq(53,60)) {
      return(1)
    } else if (x %in% seq(44,52)) {
      return(2)
    } else if (x %in% seq(35,43)) {
      return(3)
    } else if (x %in% seq(26,34)) {
      return(4)
    } else if (x %in% seq(17,25)) {
      return(5)
    } else if (x %in% seq(8,16)) {
      return(6)
    } else if (x %in% seq(0,7)) {
      return(7)
    }
  }

  ## Calculate the score
  PR_score <- FH$A + FH$B + FH$C
  CL_score <- FH$D + FH$E + FH$F + FH$G
  PR <- sapply(PR_score, function(i) PR(i))
  CL <- sapply(CL_score, function(i) CL(i))
  score <- (PR + CL)/2

  return(score)
}

fhstatus <- function(score) {
  FH_status <- function(score) {
    if (score >= 1 & score <= 2.5) { 
      status <- "F"
    } else if (score >= 3 & score <= 5) {
      status <- "PF"
    } else if (score >= 5.5 & score <=7) {
      status <- "NF"
    }
    return(status)
  }
  status <- sapply(score, function(i) FH_status(i))
}

fhgroupplot <- function(index_obj) {
  ## fhgroupplot plots probability of correct group for FH
  
  ## Type checking: only accept FH
  error_obj_fh(index_obj)
  
  ## Get data from object
  FH <- index_obj$data_orig
  model <- index_obj$model
  n <- index_obj$n
  n.sims <- index_obj$n.sims
  names <- index_obj$names
  
  ## Calculate FH scores and status
  FH$score <- fhscore(index_obj)
  FH$status <- fhstatus(FH$score)
  
  ## Find cutoffs, free and partly free
  FH$postmean <- summary(model)$stat[1:n,1]
  cutoff_F <- mean(subset(FH, score == 2.5 | score == 3, postmean))
  cutoff_PF <- mean(subset(FH, score == 5 | score == 5.5, postmean))
  
  ## Calculate probability of being in groups
  ranking_groups <- function(model,n,names,cutoff,top=TRUE) {
    model <- as.matrix(model)[,1:n]
    lessthan_TF <- apply(model,2,lessthan,cutoff=cutoff,top=top)
    lessthan_TF <- apply(lessthan_TF,2,sum)/n.sims
    lessthan_TF <- cbind(lessthan_TF)
    rownames(lessthan_TF) <- names
    return(lessthan_TF)
  }
  
  ## Pr(being in group)
  group.F <- ranking_groups(model,n,names,cutoff_F,top=FALSE)
  group.NF <- ranking_groups(model,n,names,cutoff_PF,top=TRUE)
  group.PF <- 1-group.F-group.NF
  group <- data.frame(c(group.F),c(group.PF),c(group.NF),FH[c("postmean","status")])
  rownames(group) <- names
  colnames(group) <- c("F","PF","NF","postmean","status")
  group <- group[order(group$F,group$PF,group$NF,group$postmean),]
  
  ## Plot
  index <- 1:n
  plot(group[,1],index,type="p", xlim=c(-0.5,1), bty="n",
       yaxt="n",ylab="",xaxt="n",xlab="",pch=20,col="white", main="")

  ## Add country names
  names <- sapply(seq(n),function(i) paste(row.names(group)[i]," (",group[i,"status"],")",sep=""))
  odd <- seq(from=1,to=n,by=2)
  names_odd <- names[odd]
  text(x=-0.3,y=odd,labels=names_odd,cex=.5,adj=1)
  even <- seq(from=2,to=n,by=2)
  names_even <- names[even]
  text(x=-0.3,4,y=even,labels=names_even,cex=.5,adj=0)
  
  points(group[,1][group[,1]>0],index[group[,1]>0],type="p",pch=20)
  points(group[,2][group[,2]>0],index[group[,2]>0],type="p",pch=21,cex=.75)
  points(group[,3][group[,3]>0],index[group[,3]>0],type="p",pch=4,cex=.75)

  ## Add markers to plot
  lineticks <- c(.05,.25,.5,.75,.95,1)
  for (i in lineticks) {
    lines(c(i,i),c(2,n-1),col="gray",lty="dashed")
    text(x=i,y=n,label=paste(i),cex=.6)
  }

  ## Add legend
  legend(0.5,15,legend=c("Pr(Free)","Pr(Partly Free)","Pr(Not Free)"),
         cex=.75,bty="n",pch=c(20,21,4))
}

groups <- function(index_obj,file="") {
  ## groups(index_obj,file) identifies groups according to the
  ## criterion that there are no significant differences within the
  ## group, and write the resulting group allocation to 'file'.

  ## Check that object is of correct type
  error_obj(index_obj)
  
  ## Get data from object
  nc <- index_obj$n
  names <- index_obj$names
  model <- index_obj$model

  ## Create functions needed 
  require(xtable)
  groups_cutoff <- function(dta,start,q) {
    ## groups_cutoff(dta,start,q) returns the index of the first
    ## country that is different from 'start' at level 'q' using
    ## dataset 'dta'
    n <- ncol(dta)
    nn <- nrow(dta)
    i <- start
    qhat <- 1
    while (i < n & qhat >= q) {
      i <- i + 1
      qhat <- sum(dta[,start] > dta[,i])/nn
    }
    if (qhat >= q) {
      return(i+1)      # return last element + 1 if no cutoff is found
    } else {
      return(i)     # the first i that is significantly different from
                    # start at q
    }
  }
  
  groups_numbers <- function(dta,q){
    ## groups_numbers(dta,q) returns a vector of index numbers where
    ## the index numbers represent the cutoff countries at level 'q'
    n <- ncol(dta)
    i <- 1
    g <- double(2)
    g[1] <- i
    j <- 2
    while (i < n) {
      g[j] <- groups_cutoff(dta,i,q)
      i <- g[j]
      j <- j + 1
    }
    return(g)
  }
  
  groups_table_add <- function(dtaset,ss,q) {
    g <- groups_numbers(ss,q)
    dtaset$q <- 0
    for (i in seq(length(g)-1)) {
      dtaset[dtaset$number %in% seq(g[i],g[i+1]-1),"q"] <- i
    }
    if (dtaset$q[length(dtaset$q)] == 0) {
      dtaset$q[length(dtaset$q)] <- i+1
    }
    return(dtaset$q)
  }
  
  ## Sort dataset by median
  ss <- as.matrix(model)[,1:nc]
  ss <- ss * (-1)
  colnames(ss) <- names
  ss.median <- apply(ss,2,median)
  ss <- ss[,names(sort(ss.median))]
  dataset <- data.frame(seq(1,nc))
  names(dataset) <- "number"
  dataset$Country <- colnames(ss)
  num <- c(0,.95,.99,.999)
  dataset$q1 <- groups_table_add(dataset,ss,1-num[1])
  dataset$q2 <- groups_table_add(dataset,ss,1-num[2])
  dataset$q3 <- groups_table_add(dataset,ss,1-num[3])
  dataset$q4 <- groups_table_add(dataset,ss,1-num[4])
  colnames(dataset) <- c("Rank","Country","N","q=.95","q=.99",
                         "q=.999")
  dataset <- dataset[-1]
  tab <- xtable(dataset,digits=0)

  ## print table to file
  if (file != "") {
    print(tab,tabular.environment='longtable',floating=FALSE,file=file)
  }
  return(dataset)
}
