rm(list = ls())
setwd("estimation/")

source("R_functions.R")

figsfold <- "../tables_figs/"
tablesfold <- "../tables_figs/"
datafold <- "../data/"

figsfolder <- function(filename,folder=figsfold) {
  paste(folder,filename,sep="")
}
tablesfolder <- function(filename,folder=tablesfold) {
  paste(folder,filename,sep="")
}
datafolder <- function(filename,folder=datafold) {
  paste(folder,filename,sep="")
}
