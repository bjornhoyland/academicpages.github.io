##########################
## Freedom House        ##
## Prepare and run JAGS ##
##########################

source("estimation/header.R")
library(MASS)

## Read in data
FH <- read.csv(datafolder("FH_clean.csv"))

## Choose variables
col.orig <- c("A","B","C","D","E","F","G")
x.orig <- FH[,col.orig]
x <- x.orig

## Avoid zeros
x <- x+1                                # to avoid zeros

## Maximum values for the ordered variables
maxcat <- apply(x,2,max)

## Dimensions
total.dims <- dim(x)
n <- total.dims[1]
m <- total.dims[2]

## Clustered variables
group <- c(1,1,1,2,2,2,2)               # grouping: the two cat's in FH
group.no <- max(group)                  # number of groups

## Initial values
initialf <- factanal(x,1,scores="Bartlett")
initiala <- matrix(NA,m,maxcat[2]-1)
initialb <- NA
for (i in seq(m)) {
  tmp <- summary(polr(as.ordered(x[,i]) ~ initialf$scores,Hess=TRUE))$coeff
  tmp_n <- dim(tmp)[1]
  initiala[i,1:(tmp_n-1)] <- tmp[2:tmp_n,1]
  initialb[i] <- tmp[1]
  rm(tmp,tmp_n)
}
inits1 <- function() {list (fstar=c(initialf$scores),
                            ## alpha = initiala,
                            beta = initialb,
                            delta = matrix(rep(0,n*2),n,2),
                            .RNG.seed=80160,
                            .RNG.name="base::Mersenne-Twister")}

inits2 <- function() {list (fstar=c(initialf$scores),
                            ## alpha = initiala,
                            beta = initialb,
                            delta = matrix(rep(0,n*2),n,2),
                            .RNG.seed=9478,
                            .RNG.name="base::Super-Duper")}

inits3 <- function() {list (fstar=c(initialf$scores),
                            ## alpha = initiala,
                            beta = initialb,
                            delta = matrix(rep(0,n*2),n,2),
                            .RNG.seed=72834,
                            .RNG.name="base::Wichmann-Hill")}

## Write data file and inits for JAGS
x <- as.matrix(x)
dump(list = c("x","group","group.no","maxcat","n","m"), file = "FH_dump.R")
dump_list(inits1(), file = "FH_inits1.R")
dump_list(inits2(), file = "FH_inits2.R")
dump_list(inits3(), file = "FH_inits3.R")

## Call JAGS
system("jags FH_jags.cmd")
