####################
## Clean HDI data ##
####################

source("estimation/header.R")

## read in data
HDI <- read.csv(datafolder("HDI.csv"))

## convert from "factor" to "numeric"
for (j in c("rank","hdi","lifeexp","literacy","enrolment","gdp","lifeexp_index",
            "education_index","gdp_index","gdp_hdi")){
  name <- paste("HDI$",j," <- as.numeric(as.character(HDI$",j,"))")
  eval(parse(text = name))
}

## convert from "factor" to "character"
for (i in c("country","f1","f3","f4","f5","f6")) {
  name <- paste("HDI$",i," <- as.character(HDI$",i,")")
  eval(parse(text = name))
}

## impute from f4 (footnote c)
for (i in 1:dim(HDI)[1]) {
  if (HDI$f4[i] == "c") {
    HDI$literacy[i] <- 99
  }
}

## impute from f5 (footnote g)
for (i in 1:dim(HDI)[1]) {
  if (HDI$f5[i]=="g") {
    HDI$enrolment[i] <- 100
  }
}

## footnote d
for (i in 1:dim(HDI)[1]) {
  if (any(grep("d",HDI$f6[i]))==TRUE) {
    HDI$gdp[i] <- 40000
  }
}

## footnote j
HDI$literacy[HDI$country=="Bahamas"] <- 95.8
HDI$literacy[HDI$country=="Barbados"] <- 99.7
HDI$literacy[HDI$country=="Djibouti"] <- 70.3
HDI$literacy[HDI$country=="Eritrea"] <- 60.5
HDI$literacy[HDI$country=="Fiji"] <- 94.4
HDI$literacy[HDI$country=="Gambia"] <- 42.5
HDI$literacy[HDI$country=="Guyana"] <- 99.0
HDI$literacy[HDI$country=="Hong Kong, China (SAR)"] <- 94.6
HDI$literacy[HDI$country=="Lebanon"] <- 88.3

## from 2007/2008 report
HDI$literacy[HDI$country=="Grenada"] <- 96.0

## footnote aa
HDI$gdp[HDI$country=="Occupied Palestinian Territories"] <- 2073

## Fixing up country names to merge with WB classification
HDI[HDI$country=="Bahamas",][,2] <- "Bahamas, the"
HDI[HDI$country=="Brunei Darussalam",][,2] <- "Brunei"
HDI[HDI$country=="Congo",][,2] <- "Congo, Rep."
HDI[HDI$country=="Congo (Democratic Republic of the)",][,2] <- "Congo, Dem. Rep."
HDI[HDI$country=="Cote d'Ivoire",][,2] <- "Cote d'Ivoire"
HDI[HDI$country=="Gambia",][,2] <- "Gambia, the"
HDI[HDI$country=="Hong Kong, China (SAR)",][,2] <- "Hong Kong, China"
HDI[HDI$country=="Iran (Islamic Republic of)",][,2] <- "Iran"
HDI[HDI$country=="Korea (Republic of)",][,2] <- "Korea"
HDI[HDI$country=="Kyrgyzstan",][,2] <- "Kyrgyz Republic"
HDI[HDI$country=="Lao People's Democratic Republic",][,2] <- "Lao PDR"
HDI[HDI$country=="Libyan Arab Jamahiriya",][,2] <- "Libya"
HDI[HDI$country=="Macedonia (TFYR)",][,2] <- "Macedonia, FYR"
HDI[HDI$country=="Saint Kitts and Nevis",][,2] <- "St. Kitts and Nevis"
HDI[HDI$country=="Saint Lucia",][,2] <- "St. Lucia"
HDI[HDI$country=="Saint Vincent and the Grenadines",][,2] <- "St. Vincent and the Grenadines"
HDI[HDI$country=="Syrian Arab Republic",][,2] <- "Syria"
HDI[HDI$country=="Tanzania (United Republic of)",][,2] <- "Tanzania"
HDI[HDI$country=="Venezuela (Bolivarian Republic of)",][,2] <- "Venezuela"
HDI[HDI$country=="Viet Nam",][,2] <- "Vietnam"

## Merge in classifications from WB
class <- read.csv(datafolder("classification_wb.csv"),sep=";")
HDI <- merge(HDI,class,by.x="country",by.y="Economy",all.x = T)

###########################
## CALCULATING THE INDEX ##
###########################

## Should have been calculated using these figures (Technical note 1)
#HDI$loggdp <- (log(HDI$gdp)-min(log(HDI$gdp)))/(max(log(HDI$gdp))-
#                                                min(log(HDI$gdp)))
#HDI$lifeexp2 <- (HDI$lifeexp - min(HDI$lifeexp))/(max(HDI$lifeexp)-
#                                                  min(HDI$lifeexp))

## But HDI use baseline values (Technical note 1)
HDI$gdpindex<- (log(HDI$gdp)-log(100))/(log(40000)-log(100))
HDI$lifeexpindex <- (HDI$lifeexp - 25)/(85-25)
HDI$enrolmentindex <- HDI$enrolment/100
HDI$literacyindex <- HDI$literacy/100
HDI$schoolingindex <- (1/3)*HDI$enrolmentindex+(2/3)*HDI$literacyindex
HDI$hdiindex <- (HDI$gdpindex+HDI$lifeexpindex+HDI$schoolingindex)/3
HDI[,c("country","hdi","hdiindex")]     # fits very well

rm(i,j,name,class)

## Write to file
HDI <- HDI[!names(HDI) %in% names(HDI[grep("^f",names(HDI))])] # remove notes
write.csv(HDI, file=datafolder("HDI_clean.csv"), row.names = FALSE)
