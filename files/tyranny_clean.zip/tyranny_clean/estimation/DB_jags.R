##########################
## Doing Business       ##
## Prepare and run JAGS ## 
##########################

source("estimation/header.R")

## Read in data
DB_current <- read.csv(datafolder("DB_clean.csv"), as.is = TRUE)

## Normalize some ordered variables
DB_current$Employ_DifficultFire <- DB_current$Employ_DifficultFire / 10
DB_current$Employ_RigidHours <- DB_current$Employ_RigidHours / 20
DB_current$Employ_Hire <- floor(DB_current$Employ_Hire / (11/2)) # see Simulator_English_2009.xls (we lack decimals since we downloaded the data from DB's web site)

## Identify the relevant distributions (same variables as DB use)
normal.db <- DB_current[,c("Start_Cost","Licence_Cost","Register_Cost",
                           "Taxes_Total","Trading_CostExp","Trading_CostImp",
                           "Enforcing_Cost","Closing_Recovery")]
count.db <- DB_current[,c("Start_Procedures","Start_Time","Licence_Procedures",
                          "Licence_Time","Register_Procedure","Register_Time",
                          "Taxes_Payments","Taxes_Time","Trading_DocsExp",
                          "Trading_TimeExp","Trading_DocsImp","Trading_TimeImp",
                          "Enforcing_Procedures","Enforcing_Time")]
order.db <- DB_current[,c("Employ_Hire","Employ_RigidHours",
                          "Employ_DifficultFire","Credit_Legal","Credit_Info",
                          "InvestProtect_Disclosure",
                          "InvestProtect_DirLiability",
                          "InvestProtect_Shareholder")]
trunc.db <- DB_current[,c("Start_Capital","Employ_CostFire")]
order.db <- order.db + 1              # avoid 0's
order.db$InvestProtect_DirLiability <- order.db$InvestProtect_DirLiability-1 # to start at 1

## Identify relevant distributions for all indicators (excluding those
## that are sum of other indicators)
normal.all <- DB_current[,c("Start_Cost","Licence_Cost","Register_Cost",
                            "Trading_CostExp","Trading_CostImp",
                            "Enforcing_Cost","Closing_Time","Closing_Cost",
                            "Closing_Recovery")]
count.all <- DB_current[,c("Start_Procedures","Start_Time","Licence_Procedures",
                           "Licence_Time","Register_Procedure","Register_Time",
                           "Taxes_Payments","Taxes_Time","Trading_DocsExp",
                           "Trading_TimeExp","Trading_DocsImp",
                           "Trading_TimeImp","Enforcing_Procedures",
                           "Enforcing_Time")]
order.all <- DB_current[,c("Credit_Legal","Credit_Info",
                           "InvestProtect_Disclosure",
                           "InvestProtect_DirLiability",
                           "InvestProtect_Shareholder","Employ_Hire",
                           "Employ_RigidHours",
                           "Employ_DifficultFire")]
trunc.all <- DB_current[,c("Start_Capital","Employ_CostFire",
                           "Credit_PublicCover","Credit_PrivateCover",
                           "Taxes_ProfitTax","Taxes_LaborTax","Taxes_Other")]
order.all <- order.all + 1              # avoid 0's
order.all["InvestProtect_DirLiability"] <- order.all["InvestProtect_DirLiability"] - 1 # to start at 1

## Choose whether to use all data or only DB selection (.db vs .all)
normal <- normal.all
count <- count.all
trunc <- trunc.all
order <- order.all

## Dimensions
norm.l <- c(1,dim(normal)[2])
count.l <- c((norm.l[2]+1),(dim(count)[2]+norm.l[2]))
trunc.l <- c((count.l[2]+1),(dim(trunc)[2]+count.l[2]))
order.l <- c((trunc.l[2]+1),(dim(order)[2]+trunc.l[2]))
total.dims <-c(dim(normal)[1],
               (dim(normal)[2]+dim(count)[2]+dim(trunc)[2]+dim(order)[2]))
x <- cbind(normal,count,trunc,order)
n <- total.dims[1]
m <- total.dims[2]

## Maximum values for the ordered variables
maxcat <- c(NA)                         # get the party started
maxcat[order.l[1]:order.l[2]] <- apply(order,2,max)

## Clustered variables
groupalloc <- function(x) {
  ## 1. Starting, 2. Licence, 3. Employment, 4. Register, 5. Credit,
  ## 6. Invest protect, 7. Taxes, 8. Trading, 9. Enforcing,
  ## 10. Closing.
  group <- NA
  for (i in seq(dim(x)[2])) {
    if (grepl("^Start",names(x[i]))) {
      group[i] <- 1
    } else if (grepl("^Licence",names(x[i]))) {
      group[i] <- 2
    } else if (grepl("^Employ",names(x[i]))) {
      group[i] <- 3
    } else if (grepl("^Register",names(x[i]))) {
      group[i] <- 4
    } else if (grepl("^Credit",names(x[i]))) {
      group[i] <- 5
    } else if (grepl("^InvestProtect",names(x[i]))) {
      group[i] <- 6
    } else if (grepl("^Taxes",names(x[i]))) {
      group[i] <- 7
    } else if (grepl("^Trading",names(x[i]))) {
      group[i] <- 8
    } else if (grepl("^Enforcing",names(x[i]))) {
      group[i] <- 9
    } else if (grepl("^Closing",names(x[i]))) {
      group[i] <- 10
    }
  }
  return(group)
}
group <- groupalloc(x)
group.no <- max(group)                  # number of groups

## Weight correlated shock by std of variables
std <- sd(x)

## Initial values 
initialf <- factanal(x,1,scores="Bartlett")
initialg <- matrix(NA,trunc.l[2],2)
for (i in c(norm.l[1]:norm.l[2],trunc.l[1]:trunc.l[2])) {
  initialg[i,] <- lm(x[,i] ~ initialf$scores)$coefficients
}
for (i in count.l[1]:count.l[2]) {
  initialg[i,] <- glm(x[,i] ~ initialf$scores,family=poisson)$coefficients
}

inits1 <- function() {list (fstar=c(initialf$scores),
                            gamma=initialg,
                            delta=matrix(0,n,group.no),
                            .RNG.seed=79938,
                            .RNG.name="base::Wichmann-Hill")}
inits2 <- function() {list (fstar=c(initialf$scores),
                            gamma=initialg,
                            delta=matrix(0,n,group.no),
                            .RNG.seed=20043,
                            .RNG.name="base::Super-Duper")}
inits3 <- function() {list (fstar=c(initialf$scores),
                            gamma=initialg,
                            delta=matrix(0,n,group.no),
                            .RNG.seed=62941,
                            .RNG.name="base::Wichmann-Hill")}

## Write data file and inits for JAGS
x <- as.matrix(x)
dump(list = c("x","norm.l","count.l","order.l","trunc.l","group","group.no","maxcat","n","std"), file = "DB_dump.R")
dump_list(inits1(), file = "DB_inits1.R")
dump_list(inits2(), file = "DB_inits2.R")
dump_list(inits3(), file = "DB_inits3.R")

## Call JAGS
system("jags DB_jags.cmd")
