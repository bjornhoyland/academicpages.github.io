##############################
## Clean Freedom House data ##
##############################

source("estimation/header.R")

## Clean up data set
FH_orig <- read.csv(datafolder("freedom_house/2008_scores.csv"),header=TRUE)
FH <- FH_orig[c("Country","A","B","C","D","E","F","G")]
FH$Country <- as.character(FH$Country)

## Fix country names to classify using WB
FH[FH$Country=="Antigua & Barbuda",][,1] <- "Antigua and Barbuda"
FH[FH$Country=="Bahamas",][,1] <- "Bahamas, the"
FH[FH$Country=="Bosnia-Herzegovina",][,1] <- "Bosnia and Herzegovina"
FH[FH$Country=="Burma",][,1] <- "Myanmar"
FH[FH$Country=="China (PRC)",][,1] <- "China"
FH[FH$Country=="Congo (Brazzaville)",][,1] <- "Congo, Rep."
FH[FH$Country=="Congo (Kinshasa)",][,1] <- "Congo, Dem. Rep."
FH[FH$Country=="Cote d'Ivoire",][,1] <- "Cote d'Ivoire"
FH[FH$Country=="Cyprus ",][,1] <- "Cyprus"
FH[FH$Country=="East Timor",][,1] <- "Timor-Leste"
FH[FH$Country=="The Gambia",][,1] <- "Gambia, the"
FH[FH$Country=="Kyrgyzstan",][,1] <- "Kyrgyz Republic"
FH[FH$Country=="Laos",][,1] <- "Lao PDR"
FH[FH$Country=="Macedonia",][,1] <- "Macedonia, FYR"
FH[FH$Country=="North Korea",][,1] <- "Korea, Dem. Rep."
FH[FH$Country=="Russia",][,1] <- "Russian Federation"
FH[FH$Country=="Sao Tome & Principe",][,1] <- "Sao Tome and Principe"
FH[FH$Country=="South Korea",][,1] <- "Korea"
FH[FH$Country=="St. Kitts & Nevis",][,1] <- "St. Kitts and Nevis"
FH[FH$Country=="St. Vincent & Grenadines",][,1] <- "St. Vincent and the Grenadines"
FH[FH$Country=="Trinidad & Tobago",][,1] <- "Trinidad and Tobago"
FH[FH$Country=="United States of America",][,1] <-"United States"

## Merge in classifications from WB
class <- read.csv(datafolder("classification_wb.csv"),sep=";")
FH <- merge(FH,class,by.x="Country",by.y="Economy",all.x = T)

rm(class,FH_orig)

write.csv(FH, file=datafolder("FH_clean.csv"), row.names = FALSE)
