##################
# Monte Carlo demo
# Selection model
##################
# 1) Generate true data
# 2) Run with true data
# 3) Introduce selection bias
# 4) Run with standard and selection models
# 5) Introduce random missing and repeat 4
rm(list=ls())
set.seed(12345)
# Generate positional data
outcome <- round(runif(500,0,1),0)
sq <- round(runif(500,0,1),0)
positions <- matrix(NA,500,15)
for (i in 1:15){
positions[,i] <- round(runif(500,0,1),0)
}

# Generating data matrix
votes <- matrix(NA,500,15)
new <- matrix(NA,500,15)
old <- matrix(NA,500,15)
pref <- matrix(NA,500,15)
error1 <- rnorm(500,0,.3)
error2 <- rnorm(500,0,.3)
for (i in 1:15){
  new[,i] <- abs(positions[,i] - outcome)
  old[,i] <- abs(positions[,i] - sq)
votes[,i] <- ifelse(old[,i]+error1 > new[,i]+error2,1,0)
pref[,i] <-  old[,i] - new[,i]
}
