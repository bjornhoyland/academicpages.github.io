# Results from montecarlo study
setwd("~/Dropbox/CouncilVoting/Estimation/MonteCarlo/Results")
library(coda)
resultsTrue <- read.coda("../MC/Standardchain1.txt","../MC/Standardindex.txt") # no selection, no missing

resultsNaiv1 <- read.coda("../MC/Naiv1chain1.txt","../MC/Naiv1index.txt") # 1 against, 5% missing 
resultsNaiv2 <- read.coda("../MC/Naiv2chain1.txt","../MC/Naiv2index.txt") # 2 against, 5% missing 
resultsNaiv3 <- read.coda("../MC/Naiv3chain1.txt","../MC/Naiv3index.txt") # 3 against, 5% missing 
resultsNaiv4 <- read.coda("../MC/Naiv4chain1.txt","../MC/Naiv4index.txt") # 4 against, 5% missing 
resultsNaiv5 <- read.coda("../MC/Naiv5chain1.txt","../MC/Naiv5index.txt") # 5 against, 5% missing 
resultsNaiv6 <- read.coda("../MC/Naiv6chain1.txt","../MC/Naiv6index.txt") # 6 against, 5% missing 

resultsSelection1 <- read.coda("../MC/Selection1chain1.txt","../MC/Selection1index.txt") # 1 against, 5% missing 
resultsSelection2 <- read.coda("../MC/Selection2chain1.txt","../MC/Selection2index.txt") # 2 against, 5% missing 
resultsSelection3 <- read.coda("../MC/Selection3chain1.txt","../MC/Selection3index.txt") # 3 against, 5% missing 
resultsSelection4 <- read.coda("../MC/Selection4chain1.txt","../MC/Selection4index.txt") # 4 against, 5% missing 
resultsSelection5 <- read.coda("../MC/Selection5chain1.txt","../MC/Selection5index.txt") # 5 against, 5% missing 
resultsSelection6 <- read.coda("../MC/Selection6chain1.txt","../MC/Selection6index.txt") # 6 against, 5% missing  

summary(resultsTrue)

summary(resultsNaiv1)
summary(resultsNaiv2)
summary(resultsNaiv3)
summary(resultsNaiv4)
summary(resultsNaiv5)
summary(resultsNaiv6)

summary(resultsSelection1)
summary(resultsSelection2)
summary(resultsSelection3)
summary(resultsSelection4)
summary(resultsSelection5)
summary(resultsSelection6)
