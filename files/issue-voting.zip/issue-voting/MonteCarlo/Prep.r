##################
# Monte Carlo demo
# Selection model
##################
# 1) Generate true data
rm(list=ls())
set.seed(12345)
# Generate positional data
outcome <- round(runif(500,0,100),0)
sq <- round(runif(500,0,100),0)
positions <- matrix(NA,500,15)
for (i in 1:15){
positions[,i] <- round(runif(500,0,100),0)
}

# Generating data matrix
votes <- matrix(NA,500,15)
new <- matrix(NA,500,15)
old <- matrix(NA,500,15)
pref <- matrix(NA,500,15)
error1 <- rnorm(500,0,15)
error2 <- rnorm(500,0,15)
for (i in 1:15){
  new[,i] <- abs(positions[,i] - outcome)
  old[,i] <- abs(positions[,i] - sq)
votes[,i] <- ifelse(old[,i]+error1 > new[,i]+error2,1,0)
pref[,i] <-  old[,i] - new[,i]
}
# True results
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Standard.R")   ## dump
foo
