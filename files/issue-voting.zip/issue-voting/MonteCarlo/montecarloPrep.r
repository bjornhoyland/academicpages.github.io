##################
# Monte Carlo demo
# Selection model
##################
# 1) Generate true data
# 2) Run with true data
# 3) Introduce selection bias
# 4) Run with standard and selection models
# 5) Introduce random missing and repeat 4
rm(list=ls())
set.seed(12345)
# Generate positional data
outcome <- round(runif(500,0,100),0)
sq <- round(runif(500,0,100),0)
positions <- matrix(NA,500,15)
for (i in 1:15){
positions[,i] <- round(runif(500,0,100),0)
}

# Generating data matrix
votes <- matrix(NA,500,15)
new <- matrix(NA,500,15)
old <- matrix(NA,500,15)
pref <- matrix(NA,500,15)
error1 <- rnorm(500,0,30)
error2 <- rnorm(500,0,30)
for (i in 1:15){
  new[,i] <- abs(positions[,i] - outcome)
  old[,i] <- abs(positions[,i] - sq)
votes[,i] <- ifelse(old[,i]+error1 > new[,i]+error2,1,0)
pref[,i] <-  old[,i] - new[,i]
}
# True results
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Standard.R")   ## dump
foo
######################

random <- runif(500,0,1)
test <- pref<0
sumtest <- apply(test,1,sum)
limit <- c(1,.05)
votesOld <- votes

votes <- votesOld
limit <- c(1,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA

# Naiv
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Naiv1.R")   ## dump

# data for selection bias model

votes <- votesOld
limit <- c(1,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA

if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
misses <- ifelse(is.na(y),1,0)
miss <- array(misses,dim=c(dim(votes)[1],dim(votes)[2]))
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
foo$miss <- miss
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Selection1.R")
######################

######################
# Selection bias
# If 2 of member states are against, 5% random
votes <- votesOld
limit <- c(2,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA

# Naiv
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Naiv2.R")   ## dump

# data for selection bias model
votes <- votesOld
limit <- c(2,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA

misses <- ifelse(is.na(y),1,0)
miss <- array(misses,dim=c(dim(votes)[1],dim(votes)[2]))
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
foo$miss <- miss
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Selection2.R")
######################
# Selection bias
# If 3 of member states are against, 5% random
votes <- votesOld
limit <- c(3,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA

# Naiv
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Naiv3.R")   ## dump

# data for selection bias model
votes <- votesOld
limit <- c(3,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA
misses <- ifelse(is.na(y),1,0)
miss <- array(misses,dim=c(dim(votes)[1],dim(votes)[2]))
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
foo$miss <- miss
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Selection3.R")


######################
# Selection bias
# If 4 or less of member states are against, 5% random
votes <- votesOld
limit <- c(4,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA

# Naiv
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Naiv4.R")   ## dump

# data for selection bias model
votes <- votesOld
limit <- c(4,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA
misses <- ifelse(is.na(y),1,0)
miss <- array(misses,dim=c(dim(votes)[1],dim(votes)[2]))
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
foo$miss <- miss
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Selection4.R")

######################
# Selection bias
# If 5 of fewer of the member states are against, 5% random
######################
votes <- votesOld
limit <- c(5,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA

# Naiv
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Naiv5.R")   ## dump

# data for selection bias model
votes <- votesOld
limit <- c(5,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA
misses <- ifelse(is.na(y),1,0)
miss <- array(misses,dim=c(dim(votes)[1],dim(votes)[2]))
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
foo$miss <- miss
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Selection5.R")

######################
# Selection bias
# If 6 of fewer of the member states are against, 5% random
######################
votes <- votesOld
limit <- c(6,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA

# Naiv
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Naiv6.R")   ## dump

# data for selection bias model
votes <- votesOld
limit <- c(6,.05)
votes[sumtest<limit[1],] <- NA
votes[random<limit[2],] <- NA
misses <- ifelse(is.na(y),1,0)
miss <- array(misses,dim=c(dim(votes)[1],dim(votes)[2]))
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- dim(votes)[2]
foo$m <- dim(votes)[1]
y <- c(votes,recursive=TRUE)
prefs <- c(pref, recursive=TRUE)
foo$y <- array(y,dim=c(dim(votes)[1],dim(votes)[2]))
foo$pref <- array(prefs,dim=c(dim(votes)[1],dim(votes)[2]))
foo$miss <- miss
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Data/Selection6.R")
