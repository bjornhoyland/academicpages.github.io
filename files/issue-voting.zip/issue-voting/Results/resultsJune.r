####################
# Reported results #
# Council voting   #
####################
rm(list=ls())
setwd("/Users/bjorn/Dropbox/CouncilVoting/Estimation/Results")
library(coda)
######
Simple <- mcmc.list(read.coda(output.file="../Samples/Simplechain1.txt",index.file="../Samples/Simpleindex.txt"))
SimpleSal <- mcmc.list(read.coda(output.file="../Samples/SimpleSalchain1.txt",index.file="../Samples/SimpleSalindex.txt"))
Standard <- mcmc.list(read.coda(output.file="../Samples/Standardchain1.txt",index.file="../Samples/Standardindex.txt"))
StandardSal <- mcmc.list(read.coda(output.file="../Samples/StandardSalchain1.txt",index.file="../Samples/StandardSalindex.txt"))
SelectSimple <- mcmc.list(read.coda(output.file="../Samples/SelectionSimplechain1.txt",index.file="../Samples/SelectionSimpleindex.txt"))
SelectSimpleSal <- mcmc.list(read.coda(output.file="../Samples/SelectSimpleSalchain1.txt",index.file="../Samples/SelectSimpleSalindex.txt"))
Selection <- mcmc.list(read.coda(output.file="../Samples/Selectionchain1.txt",index.file="../Samples/Selectionindex.txt"))
SelectionSal <- mcmc.list(read.coda(output.file="../Samples/SelectSalchain1.txt",index.file="../Samples/SelectSalindex.txt"))

SelectionFull <- mcmc.list(read.coda(output.file="../Samples/SelectionFullchain1.txt",index.file="../Samples/SelectionFullindex.txt"))
summary(SelectionFull)

SelectionFullSal <- mcmc.list(read.coda(output.file="../Samples/SelectFullSalchain1.txt",index.file="../Samples/SelectFullSalindex.txt"))
summary(SelectionFullSal)
####
simple <- as.matrix(Simple)
res.simple <- simple[,1:2]
summary(res.simple)

simpleSal <- as.matrix(SimpleSal)
res.simpleSal <- simpleSal[,1:2]
summary(res.simpleSal)

standard <- as.matrix(Standard)
res.standard <- standard[,1:4]
summary(res.standard)

standardSal <- as.matrix(StandardSal)
res.standardSal <- standardSal[,1:4]
summary(res.standardSal)

selectionSimple <- as.matrix(SelectSimple)
res.selectionSimple <- selectionSimple[,1:4]
summary(res.selectionSimple)

selectionSimpleSal <- as.matrix(SelectSimpleSal)
res.selectionSimpleSal <- selectionSimpleSal[,1:4]
summary(res.selectionSimpleSal)

selection <- as.matrix(Selection)
res.selection <- selection[,1:6]
summary(res.selection)

selectionSal <- as.matrix(SelectionFullSal)
res.selectionSal <- selectionSal[,1:6]
summary(res.selectionSal)

quantile(res.simple[,2],probs=c(.025,.25,.5,.75,.975))
quantile(res.simpleSal[,2],probs=c(.025,.25,.5,.75,.975))
quantile(res.standard[,2],probs=c(.025,.25,.5,.75,.975))
quantile(res.standardSal[,2],probs=c(.025,.25,.5,.75,.975))

quantile(res.selectionSimple[,2],probs=c(.025,.25,.5,.75,.975))
quantile(res.selectionSimpleSal[,2],probs=c(.025,.25,.5,.75,.975))
quantile(res.selection[,2],probs=c(.025,.25,.5,.75,.975))
quantile(res.selectionSal[,2],probs=c(.025,.25,.5,.75,.975))

pnorm(1.53)
for (i in 1:4){
plot(res.selectionSal[,i])
}




