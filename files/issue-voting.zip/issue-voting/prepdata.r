#################
# Revision      #
#Council voting #
# selection 
#################
rm(list=ls())
Votes <- read.table("Data/Votes.txt",header=T)
dim(Votes)
head(Votes)
Votes <- Votes[-7,] # Dublicate
missingVotes <- rep(NA,15)
missing <- data.frame(array(rep(missingVotes,25),dim=c(25,15))) # missing votes on 25 cases
names(missing) <- colnames(Votes[3:17])
AllVotes <- rbind(Votes[,3:17],missing)
dim(AllVotes)
summary(AllVotes)
positions <- read.csv2("Data/Thomsonallmedpresidency.csv", header=T)
# 3 cases agreed with Luxembourg holding the presidency in 2005 are taken out
head(positions)
dim(positions)
summary(positions)
Positions <- positions[,]
withoutvotes <- read.csv2("Data/Thomsonutenvotescouncilagreement.csv", header=T)
head(withoutvotes)
dim(withoutvotes)

Positions <- rbind(positions,withoutvotes)
names(Positions)
issues <- unique(cbind(Positions$Directive,Positions$start,Positions$stopped))
issues
pos <- c(Positions[,5:19], recursive=TRUE)
names(pos) <- NULL
pos <- array(pos,dim=c(dim(Positions)[1],15))
pos <- pos*.01
sq <- c(Positions[,20], recursive=TRUE)
sq <- sq*.01
outcome <-  c(Positions[,21], recursive=TRUE)
outcome <- outcome*.01

sal <- c(Positions[,26:40],recursive=TRUE)
names(sal) <- NULL
sal <- array(sal,dim=c(dim(Positions)[1],15))
sal <- sal *.01
austria <- ifelse(Positions$Presidency=="Austria",1,0)*Positions[,5]
belgium <- ifelse(Positions$Presidency=="Belgium",1,0)*Positions[,6]
finland <- ifelse(Positions$Presidency=="Finland",1,0)*Positions[,8]
france <- ifelse(Positions$Presidency=="France",1,0)*Positions[,9]
germany <- ifelse(Positions$Presidency=="Germany",1,0)*Positions[,10]
portugal <- ifelse(Positions$Presidency=="Portugal",1,0)*Positions[,16]
netherlands <- ifelse(Positions$Presidency=="Netherlands",1,0)*Positions[,15]
sweden <- ifelse(Positions$Presidency=="Sweden",1,0)*Positions[,18]
uk <- ifelse(Positions$Presidency=="UK",1,0)*Positions[,19]
pres <- ifelse(austria==0,0,austria)
pres <- ifelse(belgium==0,pres,belgium)
pres <- ifelse(finland==0,pres,finland)
pres <- ifelse(france==0,pres,france)
pres <- ifelse(germany==0,pres,germany)
pres <- ifelse(netherlands==0,pres,netherlands)
pres <- ifelse(portugal==0,pres,portugal)
pres <- ifelse(sweden==0,pres,sweden)
pres <- ifelse(uk==0,pres,uk)
pres <- pres*.01
#############################
# Salience presidency
austriaS <- ifelse(Positions$Presidency=="Austria",1,0)*Positions[,26]
belgiumS <- ifelse(Positions$Presidency=="Belgium",1,0)*Positions[,27]
finlandS <- ifelse(Positions$Presidency=="Finland",1,0)*Positions[,29]
franceS <- ifelse(Positions$Presidency=="France",1,0)*Positions[,30]
germanyS <- ifelse(Positions$Presidency=="Germany",1,0)*Positions[,31]
portugalS <- ifelse(Positions$Presidency=="Portugal",1,0)*Positions[,37]
netherlandsS <- ifelse(Positions$Presidency=="Netherlands",1,0)*Positions[,36]
swedenS <- ifelse(Positions$Presidency=="Sweden",1,0)*Positions[,39]
ukS <- ifelse(Positions$Presidency=="UK",1,0)*Positions[,40]
pressal <- ifelse(austria==0,0,austriaS)
pressal <- ifelse(belgium==0,pressal,belgiumS)
pressal <- ifelse(finland==0,pressal,finlandS)
pressal <- ifelse(france==0,pressal,franceS)
pressal <- ifelse(germany==0,pressal,germanyS)
pressal <- ifelse(netherlands==0,pressal,netherlandsS)
pressal <- ifelse(portugal==0,pressal,portugalS)
pressal <- ifelse(sweden==0,pressal,swedenS)
pressal <- ifelse(uk==0,pressal,ukS)
pressal <- pressal*.01
# Generate the datasets for the analysis
# Simple models and models with presidency plus B-item
# With and without salience
# Standard and selection
#############
# Prepare JAGS data for simple model without saliency
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(AllVotes)[1]
y <- c(AllVotes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(AllVotes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/Simple.R")   ## dump
foo

###############################################
# Prepare JAGS data, with saliency
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(AllVotes)[1]
y <- c(AllVotes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(AllVotes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$sal <- sal
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/SimpleSal.R")   ## dump
foo

# Prepare JAGS data for standard model without saliency
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(AllVotes)[1]
y <- c(AllVotes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(AllVotes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$pres <- pres
foo$bItem <- Positions$A_Bitem
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/Standard.R")   ## dump
foo

###############################################
# Prepare JAGS data, standard model with salience model
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(AllVotes)[1]
y <- c(AllVotes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(AllVotes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$sal <- sal
foo$pres <- pres
foo$pressal <- pressal
foo$bItem <- Positions$A_Bitem
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/StandardSal.R")   ## dump
foo

########################
# Selection models
########################


# Prepare JAGS data for simple model without saliency
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(AllVotes)[1]
y <- c(AllVotes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(AllVotes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
#foo$pres <- pres
#foo$bItem <- Positions$A_Bitem
miss <- ifelse(is.na(y),1,0)
names(miss) <- NULL
foo$miss <- array(miss,dim=c(dim(AllVotes)[1],15))
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/SelectSimple.R")   ## dump
foo

###############################################
# Prepare JAGS data, selection simple with salience
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(AllVotes)[1]
y <- c(AllVotes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(AllVotes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$sal <- sal
#foo$pres <- pres
#foo$bItem <- Positions$A_Bitem
miss <- ifelse(is.na(y),1,0)
names(miss) <- NULL
foo$miss <- array(miss,dim=c(dim(AllVotes)[1],15))
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/SelectSalSimple.R")   ## dump
foo

# Prepare JAGS data for selection model without saliency
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(AllVotes)[1]
y <- c(AllVotes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(AllVotes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$pres <- pres
foo$bItem <- Positions$A_Bitem
miss <- ifelse(is.na(y),1,0)
names(miss) <- NULL
foo$miss <- array(miss,dim=c(dim(AllVotes)[1],15))
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/Select.R")   ## dump
foo

###############################################
# Prepare JAGS data, selection with salience
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(AllVotes)[1]
y <- c(AllVotes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(AllVotes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$sal <- sal
foo$pres <- pres
foo$pressal <- pressal
foo$bItem <- Positions$A_Bitem
miss <- ifelse(is.na(y),1,0)
names(miss) <- NULL
foo$miss <- array(miss,dim=c(dim(AllVotes)[1],15))
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/SelectSal.R")   ## dump
foo

####################################
# Listwise deletion models
Votes <- Votes[,3:17]
Positions <- rbind(positions)
names(Positions)
issues <- unique(cbind(Positions$Directive,Positions$start,Positions$stopped))
issues
pos <- c(Positions[,5:19], recursive=TRUE)
names(pos) <- NULL
pos <- array(pos,dim=c(dim(Positions)[1],15))
pos <- pos
sq <- c(Positions[,20], recursive=TRUE)
outcome <-  c(Positions[,21], recursive=TRUE)

sal <- c(Positions[,26:40],recursive=TRUE)
names(sal) <- NULL
sal <- array(sal,dim=c(dim(Positions)[1],15))
sal <- sal *.01
austria <- ifelse(Positions$Presidency=="Austria",1,0)*Positions[,5]
belgium <- ifelse(Positions$Presidency=="Belgium",1,0)*Positions[,6]
finland <- ifelse(Positions$Presidency=="Finland",1,0)*Positions[,8]
france <- ifelse(Positions$Presidency=="France",1,0)*Positions[,9]
germany <- ifelse(Positions$Presidency=="Germany",1,0)*Positions[,10]
portugal <- ifelse(Positions$Presidency=="Portugal",1,0)*Positions[,16]
netherlands <- ifelse(Positions$Presidency=="Netherlands",1,0)*Positions[,15]
sweden <- ifelse(Positions$Presidency=="Sweden",1,0)*Positions[,18]
uk <- ifelse(Positions$Presidency=="UK",1,0)*Positions[,19]
pres <- ifelse(austria==0,0,austria)
pres <- ifelse(belgium==0,pres,belgium)
pres <- ifelse(finland==0,pres,finland)
pres <- ifelse(france==0,pres,france)
pres <- ifelse(germany==0,pres,germany)
pres <- ifelse(netherlands==0,pres,netherlands)
pres <- ifelse(portugal==0,pres,portugal)
pres <- ifelse(sweden==0,pres,sweden)
pres <- ifelse(uk==0,pres,uk)
#############################
# Salience presidency
austriaS <- ifelse(Positions$Presidency=="Austria",1,0)*Positions[,26]
belgiumS <- ifelse(Positions$Presidency=="Belgium",1,0)*Positions[,27]
finlandS <- ifelse(Positions$Presidency=="Finland",1,0)*Positions[,29]
franceS <- ifelse(Positions$Presidency=="France",1,0)*Positions[,30]
germanyS <- ifelse(Positions$Presidency=="Germany",1,0)*Positions[,31]
portugalS <- ifelse(Positions$Presidency=="Portugal",1,0)*Positions[,37]
netherlandsS <- ifelse(Positions$Presidency=="Netherlands",1,0)*Positions[,36]
swedenS <- ifelse(Positions$Presidency=="Sweden",1,0)*Positions[,39]
ukS <- ifelse(Positions$Presidency=="UK",1,0)*Positions[,40]
pressal <- ifelse(austria==0,0,austriaS)
pressal <- ifelse(belgium==0,pressal,belgiumS)
pressal <- ifelse(finland==0,pressal,finlandS)
pressal <- ifelse(france==0,pressal,franceS)
pressal <- ifelse(germany==0,pressal,germanyS)
pressal <- ifelse(netherlands==0,pressal,netherlandsS)
pressal <- ifelse(portugal==0,pressal,portugalS)
pressal <- ifelse(sweden==0,pressal,swedenS)
pressal <- ifelse(uk==0,pressal,ukS)
pressal <- pressal*.01
# Generate the datasets for the analysis
# Simple models and models with presidency plus B-item
# With and without salience
# Standard and selection
#############
# Simple, listwise deletion, only data with complete voting records
###############################################
# Prepare JAGS data for simple model without saliency
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(Votes)[1]
y <- c(Votes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(Votes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/ListSimple.R")   ## dump
foo

###############################################
# Prepare JAGS data, with saliency
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(Votes)[1]
y <- c(Votes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(Votes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$sal <- sal
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/ListSimpleSal.R")   ## dump
foo

# Prepare JAGS data for standard model without saliency
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(Votes)[1]
y <- c(Votes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(Votes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$pres <- pres
foo$bItem <- Positions$A_Bitem
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/ListStandard.R")   ## dump
foo

###############################################
# Prepare JAGS data, standard model with salience model
if(exists("foo"))
  rm(foo)
foo <- list()
foo$n <- 15
foo$m <- dim(Positions)[1]
foo$no.votes <- dim(Votes)[1]
y <- c(Votes,recursive=TRUE)
names(y) <- NULL
foo$y <- array(y,dim=c(dim(Votes)[1],15))
foo$pos <- pos
foo$sq <- sq
foo$outcome <- outcome
foo$sal <- sal
foo$pres <- pres
foo$pressal <- pressal
foo$bItem <- Positions$A_Bitem
foo$start.issue <- issues[,1]
foo$stop.issue <- issues[,2]
for(i in 1:length(foo))
  assign(x=names(foo)[i],
         value=foo[[i]])
dump(list=names(foo),file="Start/ListStandardSal.R")   ## dump
foo
