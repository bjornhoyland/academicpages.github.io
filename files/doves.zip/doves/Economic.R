##############
# Economic   #
# conditions #
##############
ranking <- data.frame(rep(NA,25))
for (i in 1:dim(robust[,(dim(robust)[2]-24):dim(robust)[2]])[1]) {
    ranking[,i] <- rank(robust[i,(dim(robust)[2]-24):dim(robust)[2]])
}
Ranks <- t(ranking)
colnames(Ranks) <- rownames(MPCvotes)
medianrank <- 1
rank5 <- 1
rank25 <- 1
rank75 <- 1
rank95 <- 1
for (i in 1:25) {
    medianrank[i] <- median(Ranks[,i])
    rank5[i] <- quantile(Ranks[,i],probs=0.05)
    rank25[i] <- quantile(Ranks[,i],probs=0.25)
    rank75[i] <- quantile(Ranks[,i],probs=0.75)
    rank95[i] <- quantile(Ranks[,i],probs=0.95)
}
Ranks <- cbind(rank5, rank25,medianrank,rank75,rank95)


rownames(Ranks) <- rownames(ourdata)
OrdRanks <- Ranks[order(-Ranks[,3]),]

#Development in median voter
Members1<-rbind(George,King,Buiter,Goodhart,Plenderleith,Davies)
Members3<-rbind(George,King,Buiter,Goodhart,Plenderleith)
Members4<-rbind(George,King,Buiter,Goodhart,Plenderleith,Julius,Clementi)
Members7<-rbind(George,King,Buiter,Goodhart,Plenderleith,Julius,Clementi,Budd)
Members14<-rbind(George,King,Buiter,Goodhart,Plenderleith,Julius,Clementi,Budd,Vickers)
Members28<-rbind(George,King,Buiter,Goodhart,Plenderleith,Julius,Clementi,Vickers,Wadhwani)
Members40<-rbind(George,King,Plenderleith,Julius,Clementi,Vickers,Wadhwani,Nickell,Allsopp)
Members44<-rbind(George,King,Plenderleith,Julius,Clementi,Wadhwani,Nickell,Allsopp,Bean)
Members52<-rbind(George,King,Plenderleith,Clementi,Wadhwani,Nickell,Allsopp,Bean,Barker)
Members65<-rbind(George,King,Clementi,Nickell,Allsopp,Bean,Barker,Tucker)
Members66<-rbind(George,King,Clementi,Nickell,Allsopp,Bean,Barker,Tucker,Bell)
Members68<-rbind(George,King,Nickell,Allsopp,Bean,Barker,Tucker,Bell)
Members69<-rbind(George,King,Nickell,Allsopp,Bean,Barker,Tucker,Bell,Large)
Members77<-rbind(George,King,Nickell,Bean,Barker,Tucker,Bell,Large,Lambert)
Members78<-rbind(King,Nickell,Bean,Barker,Tucker,Bell,Large,Lambert,Lomax)
Members102<-rbind(King,Nickell,Bean,Barker,Tucker,Large,Lambert,Lomax,Walton)
Members109<-rbind(King,Nickell,Bean,Barker,Tucker,Lambert,Lomax,Walton,Gieve)
Members111<-rbind(King,Nickell,Bean,Barker,Tucker,Lomax,Walton,Gieve)
Members114<-rbind(King,Bean,Barker,Tucker,Lomax,Walton,Gieve,Blanchflower)
Members115<-rbind(King,Bean,Barker,Tucker,Lomax,Gieve,Blanchflower)
Members117<-rbind(King,Bean,Barker,Tucker,Lomax,Gieve,Blanchflower,Besley)
Members118<-rbind(King,Bean,Barker,Tucker,Lomax,Gieve,Blanchflower,Besley,Sentance)
##

Committee<- list(Members1,Members3,Members4,Members7,Members14,Members28,Members40,Members44,Members52,
                Members65,Members66,Members68,Members69,Members77,Members78,Members102,Members109,
                Members111,Members114,Members115,Members117,Members118)
summary(Committee)
Committee1<-data.frame(Committee[1])
Committee1<-t(Committee1)
committee<-matrix(5000,1)
CommitteeT<-NA
Committees<-NA
for (j in 1:22){
  CommitteeT<-data.frame(Committee[j])
  CommitteeT<-t(CommitteeT)
for (i in 1:5000) {
    committee[i] <-median(CommitteeT[i,])
}
  Committees[j]<-data.frame(committee)
}
ComMedians<-data.frame(Committees)
names(ComMedians)<-c('mem1','mem3','mem4','mem7','mem14',
                     'mem28','mem40','mem44','mem52','mem65'
                     ,'mem66','mem68','mem69','mem77','mem78'
                     ,'mem102','mem109','mem111','mem114'
                     ,'mem115','mem117','mem118')
test <- NA
te <- NA
for (i in 2:dim(ComMedians)[2]){
te <- ComMedians[,i] - ComMedians[,i-1]
test <- cbind(test,te)
}
diffs <- NA
diff <- NA
for (i in 2:22){
diffs <- quantile(test[,i],probs=c(.025,.5,.975))
diff <- cbind(diff,diffs)
}
colnames(diff)<-c('mem1','mem3','mem4','mem7','mem14',
                     'mem28','mem40','mem44','mem52','mem65'
                     ,'mem66','mem68','mem69','mem77','mem78'
                     ,'mem102','mem109','mem111','mem114'
                     ,'mem115','mem117','mem118')
Change <- diff[,2:22]




med<-summary(ComMedians)

index<-seq(1:121)
replacements<-c(1,3,4,7,13,26,38,42,50,63,66,67,75,76,100,107,109,111,112,114,115)
test<- seq(-.7,1.3,by=.1)
pdf("AppointmentExp.pdf",height=9,width=14)
par(mar=c(4,4,2,4))
plot(replacements,test,type="n",ylim=c(-.5,.5),xlim=c(0,122),ylab="",bty="n",
xlab="",col=1,pch=16,main="MPC Appointments and Public Expenditure ",xaxt="n",)
mtext("Median Banker Location on Dove - Hawk dimension",side=2,line=2)
for (i in 1:21){
segments(y0=quantile(ComMedians[,i],probs=.25),x0=replacements[i],
         y1=quantile(ComMedians[,i],probs=.75),x1=replacements[i])}
for (j in 1:21){
points(y=mean(ComMedians[,j]),x=replacements[j],col=1,pch=16)}
legend(75,-.1,legend="Median",pch=16,bty="n",cex=1.25)
legend(75,-.15,legend="50% Central tendency",lty=1,bty="n",cex=1.25)
legend(75,-.2,legend="Public expenditure", lty=1,bty="n",lwd=2,cex=1.25)
legend(75,-.25,legend="General elections",lty=3,lwd=3,col=1,bty="n",cex=1.25)
abline(v=53,col=1,lwd=3,lty=3)
abline(v=101,col=1,lwd=3,lty=3)
gdp<-c(38.5,37,36,35.2,35.8,36.2,37,37.7,38.4,39.1,39)
year<-c(1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007)
par(new=TRUE)
plot(year,gdp,bty="n",xlab="Year",ylab="Public expenditure % GDP"
     ,ylim=c(35,40),xlim=c(1997,2007),type="l",lwd=2,axes=F,ann=FALSE)
mtext("Public expenditure % GDP", side=4,line=2)
axis(4)
axis(1)
dev.off()

invbalance<-c('21.7','1.1','-10.3','-21','-23.6','-12.4','11.1','17.4',
              '18.5','14.1','4.4')
adjusted <- c('2.3','0.0','-1.1','-2.0','-1.9','-0.9','0.6','1.2',
              '1.5','1.0','-0.5')
replacements<-c(1,3,4,7,13,26,38,42,50,63,66,67,75,76,100,107,109,111,112,114,115)
test<- seq(-.7,1.3,by=.1)
pdf("AppointmentsCyc.pdf",height=9,width=14)
par(mar=c(4,4,2,4))
plot(replacements,test,type="n",ylim=c(-.5,.5),xlim=c(0,122),ylab="",bty="n",
xlab="",col=1,pch=16,main="MPC Appointments and Budget balance ",xaxt="n",)
mtext("Median Banker Location on Dove - Hawk dimension",side=2,line=2)
for (i in 1:21){
segments(y0=quantile(ComMedians[,i],probs=.25),x0=replacements[i],
         y1=quantile(ComMedians[,i],probs=.75),x1=replacements[i])}
for (j in 1:21){
points(y=mean(ComMedians[,j]),x=replacements[j],col=1,pch=16)}
legend(65,-.1,legend="Median",pch=16,bty="n",cex=1.25)
legend(65,-.15,legend="50% Central tendency",lty=1,bty="n",cex=1.25)
legend(65,-.2,legend="Budget balance", lty=1,bty="n",lwd=2,cex=1.25)
legend(65,-.25,legend="General elections",lty=3,lwd=3,col=1,bty="n",cex=1.25)
abline(v=53,col=1,lwd=3,lty=3)
abline(v=101,col=1,lwd=3,lty=3)
par(new=TRUE)
  plot(adjusted,year, bty="n",xlab="Year",ylab="",ylim=c(-2.5,2.5)
    ,xlim=c(1997,2007)
       ,type="n",axes=F,ann=FALSE)
mtext("Cyclical adjusted budget defict, % of GDP", side=4,line=2)
lines(year,adjusted,lty=1,lwd=2,col=1)
axis(4)
axis(1)
dev.off()
