###############
# Simulations #
###############
library(MCMCpack)
robust <- MCMCirtKd(MPCvotes, dimensions=1,
                                    item.constraints=item.con1, 
                                    burnin=500000,
                                    mcmc=500000, thin=50, 
                                    alphabeta.start=NA,
                                    b0=priors, B0=.25, 
                                    store.item=TRUE,
                                    store.ability=TRUE, 
                                    drop.constant=TRUE,
                                    verbose=5e2,seed=12345)
                                    ##all discrim constrained positive
save.image("Jan09500Standard.RData")
