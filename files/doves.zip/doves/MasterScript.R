############################
# Hix, Hoyland, and Vivyan #
# From Doves to Hawks      #
############################
rm(list=ls())
#setwd("Research/Data/Projects/BankofEngland") # set to your directory
#source("Prepare.R") # Prepare the data for simulation
#source("Simulations2.R") # Runs simulations, saved as Jan09500Standard.Rdata
load("Jan09500Standard.RData")

source("Convergence.R") # Test for convergence
source("IdealPlot.R") # Makes the ideal point figures
#source("Rankings.R") # Rank the committee members
source("FTBatting.R") # Compares with FT and Batting averages
#source("Replacements.R") #Investigates the effect of replacements
source("MedianDifference.R") # Plots change in median at different time periods
source("Economic.R") # Compare replaments with economic indicators
