##################
# FT scores      #
#Batting average #
##################

votes <- read.csv("mpcvotesdiffSep08_NxT.csv",
                    na.strings="n/a",header=TRUE,
                    row.names=1,
                    nrows=26)
votes <- votes[1:25,1:132]
N <- dim(votes)[1]
T <- dim(votes)[2]          

#Batting average scores
BAvotes <- ifelse(votes[1:N,1:T]>0,1,0)
BAscore <- apply(BAvotes,1,mean,na.rm=TRUE)

#FT scores
FTvotes <- array(,dim=dim(votes))
maj <- lapply(votes,median,na.rm=TRUE)
for(i in 1:N){
    FTvotes[i,] <- as.numeric(votes[i,]>=maj) + 
                    as.numeric(votes[i,]>maj)
              }   
FTscore <- apply(FTvotes,1,mean,na.rm=TRUE)              

Score <- cbind(BAscore,FTscore)

test<-summary(robust[,(dim(robust)[2]-24):dim(robust)[2]])
med<-test$quantiles[,3]
lower<-test$quantiles[,1]
higher<-test$quantiles[,5]
low25<-test$quantiles[,2]
high75<-test$quantiles[,4]
ourdata<-cbind(med,lower,higher,low25,high75)
row.names(ourdata)<- c("George","King","Lomax","Large","Tucker","Bean",
                    "Barker","Nickell","Allsopp","Bell","Lambert","Budd",
                    "Buiter","Goodhart","Vickers","Julius","Wadhwani",
                    "Plenderleith","Davies","Clementi","Walton","Gieve",
                    "Blanchflower","Besley","Sentance")

Compare <- data.frame(Score,ourdata)

labelpos1 <- c(2,4,4,2,2,2,4,2,2,2,4,2,2,2,2,4,2,2,2,2,2,2,2,2,4)
labelpos2 <- c(2,4,4,2,2,2,2,2,2,2,4,2,2,4,2,4,2,2,2,3,3,4,2,2,4)
size <- 1.35

pdf("BattingFT1.pdf",height=9.5,width=15)
plot(Compare$med,Compare$BAscore,xlim=c(-2.7,2.5),
main="",ylab="Batting average",xlab="Ideal Points",pch=16,cex=1) 
abline(lm(Compare$BAscore~Compare$med),col=1)
text(Compare$med,Compare$BAscore,label=row.names(Compare),
cex=size,pos=labelpos1)
dev.off()
pdf("BattingFT2.pdf",height=9.5,width=15)
plot(Compare$med,Compare$FTscore,xlim=c(-2.7,2.5),
main="",ylab=toupper("FT score"),xlab=toupper("Ideal Points"),pch=16,cex=1) 
abline(lm(Compare$FTscore~Compare$med),col=1)
text(Compare$med,Compare$FTscore,label=row.names(Compare),
cex=size,pos=labelpos2)
par(mfrow=c(1,1))
dev.off()
