#############################################
## Code to get plot of change in MPC       ##
## medians between key points in electoral ##
## cycle                                   ##
#############################################


# pull out simulations for bankers only.
medianBanker<-robust[,(dim(robust)[2]-24):dim(robust)[2]]
George<-medianBanker[,1]
King<-medianBanker[,2]
Lomax<-medianBanker[,3]
Large<-medianBanker[,4]
Tucker<-medianBanker[,5]
Bean<-medianBanker[,6]
Barker<-medianBanker[,7]
Nickell<-medianBanker[,8]
Allsopp<-medianBanker[,9]
Bell<-medianBanker[,10]
Lambert<-medianBanker[,11]
Budd<-medianBanker[,12]
Buiter<-medianBanker[,13]
Goodhart<-medianBanker[,14]
Vickers<-medianBanker[,15]
Julius<-medianBanker[,16]
Wadhwani<-medianBanker[,17]
Plenderleith<-medianBanker[,18]
Davies<-medianBanker[,19]
Clementi<-medianBanker[,20]
Walton<-medianBanker[,21]
Gieve<-medianBanker[,22]
Blanchflower<-medianBanker[,23]
Besley<-medianBanker[,24]
Sentance<-medianBanker[,25]

#Development in median voter
Members1<-rbind(George,King,Buiter,Goodhart,Plenderleith,Davies)
Members3<-rbind(George,King,Buiter,Goodhart,Plenderleith)
Members4<-rbind(George,King,Buiter,Goodhart,Plenderleith,Julius,Clementi)
Members7<-rbind(George,King,Buiter,Goodhart,Plenderleith,Julius,Clementi,Budd)
Members14<-rbind(George,King,Buiter,Goodhart,Plenderleith,Julius,Clementi,Budd,Vickers)
Members28<-rbind(George,King,Buiter,Goodhart,Plenderleith,Julius,Clementi,Vickers,Wadhwani)
Members40<-rbind(George,King,Plenderleith,Julius,Clementi,Vickers,Wadhwani,Nickell,Allsopp)
Members44<-rbind(George,King,Plenderleith,Julius,Clementi,Wadhwani,Nickell,Allsopp,Bean)
Members52<-rbind(George,King,Plenderleith,Clementi,Wadhwani,Nickell,Allsopp,Bean,Barker)
Members65<-rbind(George,King,Clementi,Nickell,Allsopp,Bean,Barker,Tucker)
Members66<-rbind(George,King,Clementi,Nickell,Allsopp,Bean,Barker,Tucker,Bell)
Members68<-rbind(George,King,Nickell,Allsopp,Bean,Barker,Tucker,Bell)
Members69<-rbind(George,King,Nickell,Allsopp,Bean,Barker,Tucker,Bell,Large)
Members77<-rbind(George,King,Nickell,Bean,Barker,Tucker,Bell,Large,Lambert)
Members78<-rbind(King,Nickell,Bean,Barker,Tucker,Bell,Large,Lambert,Lomax)
Members102<-rbind(King,Nickell,Bean,Barker,Tucker,Large,Lambert,Lomax,Walton)
Members109<-rbind(King,Nickell,Bean,Barker,Tucker,Lambert,Lomax,Walton,Gieve)
Members111<-rbind(King,Nickell,Bean,Barker,Tucker,Lomax,Walton,Gieve)
Members114<-rbind(King,Bean,Barker,Tucker,Lomax,Walton,Gieve,Blanchflower)
Members115<-rbind(King,Bean,Barker,Tucker,Lomax,Gieve,Blanchflower)
Members117<-rbind(King,Bean,Barker,Tucker,Lomax,Gieve,Blanchflower,Besley)
Members118<-rbind(King,Bean,Barker,Tucker,Lomax,Gieve,Blanchflower,Besley,Sentance)
##

#######################
## Look at changes in median at key points in electoral cycle

Committee3 <- list(Members28,Members44,Members69,
                Members78,Members118)
summary(Committee3)

committee3<-matrix(10000,1)
Committee3T<-NA
Committees3<-NA
for (j in 1:5){
  Committee3T<-data.frame(Committee3[j])
  Committee3T<-t(Committee3T)
for (i in 1:10000) {
    committee3[i] <-median(Committee3T[i,])
}
  Committees3[j]<-data.frame(committee3)
}
ComMedians3<-data.frame(Committees3)
names(ComMedians3)<-c('June 1999','Jan 2001','May 2003',
                      'Dec 2004','April 2008')

test3 <- NA
te3 <- NA
for (i in 2:dim(ComMedians3)[2]){
      te3 <- ComMedians3[,i] - ComMedians3[,i-1]
      test3 <- cbind(test3,te3)
          }


diffs3 <- NA
diff3 <- NA
for (i in 2:5){
diffs3 <- quantile(test3[,i],probs=c(.025,.5,.975))
diff3 <- cbind(diff3,diffs3)
}
colnames(diff3)<-c('NA',
                  'June 1999 -> Jan 2001',
                  'Jan 2001 -> May2003',
                  'May 2003 -> Dec 2004',
                  'Dec 2004 -> April 2008')
Change3 <- diff3[,2:5]


#plot differences in median at key points in cycle
sublabel <- c('(Non-election -> Pre-election)',
              '(Pre-election -> Non-election)',
              '(Non-election -> Pre-election)',
              '(Pre-election -> Non-election)')

index<-4:1
index2<-c(3.8,2.8,1.8,.8)
foo <- cbind(index,as.vector(colnames(diff3)[2:5]))
foo2 <- cbind(index,as.vector(sublabel))
pdf("MedKeyPts.pdf")
plot(Change3[2,],index,type="p",xlim=c(-1.35,.5),ylim=c(.5,4),
      bty="n",yaxt="n",ylab="",
      xlab="                                                                  Change in MPC Median",
      col=1,pch=16,
      xaxp=c(-.5,.5,2),
      main="Changes in MPC median between key points in electoral cycle"
      )
for (i in 1:4){
segments(x0=Change3[1,i],y0=index[i],
          x1=Change3[3,i],y1=index[i],
          lwd=2)
          }
text(x=-1.0,y=index,labels=foo[,2],cex=1)
text(x=-1.0,y=index2,labels=foo2[,2],cex=1)
abline(v=0, lty="dashed")
dev.off()







