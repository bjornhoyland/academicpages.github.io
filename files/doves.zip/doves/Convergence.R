############################
# Covergence               #
############################
library(MCMCpack)
#load("Jan09500Standard.RData") 
par(mfrow = c(5,6))
traceplot(robust)
par(mfrow = c(1,1))
print(geweke.diag(robust))
print(autocorr.diag(robust))
print(heidel.diag(robust))
print(effectiveSize(robust))