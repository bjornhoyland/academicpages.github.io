#####################
# Ideal point plots #
#####################
library(MCMCpack)
load("Jan09500Standard.RData") 
#############
test<-summary(robust[,(dim(robust)[2]-24):dim(robust)[2]])
med<-test$quantiles[,3]
lower<-test$quantiles[,1]
higher<-test$quantiles[,5]
low25<-test$quantiles[,2]
high75<-test$quantiles[,4]
ourdata<-cbind(med,lower,higher,low25,high75)
row.names(ourdata)<- c("George","King","Lomax","Large","Tucker","Bean",
                    "Barker","Nickell","Allsopp","Bell","Lambert","Budd",
                    "Buiter","Goodhart","Vickers","Julius","Wadhwani",
                    "Plenderleith","Davies","Clementi","Walton","Gieve",
                    "Blanchflower","Besley","Sentance")
OurdataSort<-data.frame(ourdata[order(-med),])
index<-25:1
pdf("Bankers.pdf")
plot(OurdataSort$med,index,type="p",xlim=c(-5.5,4),bty="n",yaxt="n",ylab="",
xlab="Dove - Hawk",col=1,pch=16,main="Revealed Preferences in the MPC")
for (i in 1:25){
segments(x0=OurdataSort$lower[i],y0=index[i],x1=OurdataSort$higher[i],y1=index[i])}
for (j in 1:25){
segments(x0=OurdataSort$low25[j],y0=index[j],x1=OurdataSort$high75[j],y1=index[j],lwd=3)}
text(x=-5,y=index,labels=row.names(OurdataSort))
legend(-4,23,legend=c("95% credibility interval",
"50% credibility interval"),lwd=c(1,3),cex=.8,bty="n")
dev.off()
print(OurdataSort)
